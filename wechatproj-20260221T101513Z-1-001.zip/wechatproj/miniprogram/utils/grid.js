function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

function boothCenterToCell(center, cellSizePx) {
  const col = Math.floor((center.x || 0) / cellSizePx);
  const row = Math.floor((center.y || 0) / cellSizePx);
  return { row, col };
}

function buildGridFromBooths({ booths, imageWidth, imageHeight, cellSizePx }) {
  // imageWidth/Height 若未知，先用 booths bbox 推估最小尺寸（MVP）
  let w = Number(imageWidth || 0);
  let h = Number(imageHeight || 0);
  if (!w || !h) {
    let maxX = 0;
    let maxY = 0;
    for (const b of booths || []) {
      const bb = b.bbox;
      if (!bb) continue;
      maxX = Math.max(maxX, bb.x2 || 0);
      maxY = Math.max(maxY, bb.y2 || 0);
    }
    w = maxX || 1024;
    h = maxY || 1024;
  }

  const cols = Math.max(1, Math.ceil(w / cellSizePx));
  const rows = Math.max(1, Math.ceil(h / cellSizePx));

  // 0: 可走, 1: 障礙
  const cells = new Array(rows);
  for (let r = 0; r < rows; r++) cells[r] = new Uint8Array(cols);

  // 將攤位 bbox 視為障礙（MVP）。更通用的牆/走道分割可在雲端加 segmentation/線稿向量化後輸入。
  for (const booth of booths || []) {
    const bb = booth.bbox;
    if (!bb) continue;
    const r1 = clamp(Math.floor(bb.y1 / cellSizePx), 0, rows - 1);
    const r2 = clamp(Math.floor(bb.y2 / cellSizePx), 0, rows - 1);
    const c1 = clamp(Math.floor(bb.x1 / cellSizePx), 0, cols - 1);
    const c2 = clamp(Math.floor(bb.x2 / cellSizePx), 0, cols - 1);
    for (let r = r1; r <= r2; r++) {
      for (let c = c1; c <= c2; c++) {
        cells[r][c] = 1;
      }
    }
  }

  return { rows, cols, cellSizePx, cells };
}

function isWalkable(grid, cell) {
  const { row, col } = cell;
  return row >= 0 && row < grid.rows && col >= 0 && col < grid.cols && grid.cells[row][col] === 0;
}

function findNearestWalkable(grid, cell, maxRadius = 12) {
  if (isWalkable(grid, cell)) return cell;
  // 以菱形/方形擴散找最近可走格
  for (let r = 1; r <= maxRadius; r++) {
    for (let dr = -r; dr <= r; dr++) {
      const dc = r - Math.abs(dr);
      const candidates = [
        { row: cell.row + dr, col: cell.col + dc },
        { row: cell.row + dr, col: cell.col - dc },
      ];
      for (const cand of candidates) {
        if (isWalkable(grid, cand)) return cand;
      }
    }
  }
  return cell; // 找不到就回原本（後續 A* 可能失敗）
}

module.exports = {
  buildGridFromBooths,
  boothCenterToCell,
  findNearestWalkable,
};





