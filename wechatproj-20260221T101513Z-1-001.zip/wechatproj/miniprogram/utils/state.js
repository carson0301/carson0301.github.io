const KEY = "FLOORPLAN_STATE_V1";

function saveFloorplanState(state) {
  try {
    wx.setStorageSync(KEY, state);
  } catch (e) {
    console.warn("saveFloorplanState 失敗", e);
  }
}

function loadFloorplanState() {
  try {
    return wx.getStorageSync(KEY) || null;
  } catch (e) {
    console.warn("loadFloorplanState 失敗", e);
    return null;
  }
}

function clearFloorplanState() {
  try {
    wx.removeStorageSync(KEY);
  } catch (e) {
    console.warn("clearFloorplanState 失敗", e);
  }
}

module.exports = {
  saveFloorplanState,
  loadFloorplanState,
  clearFloorplanState,
};




