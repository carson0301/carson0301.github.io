function drawPath(ctx, { pathCells, gridCellPx, viewWidth, viewHeight, imageWidth, imageHeight }) {
  if (!pathCells?.length) return;

  // 將「原圖像素座標」映射到 image( aspectFit ) 在 view 中的實際渲染區域
  const imgW = Number(imageWidth || 0);
  const imgH = Number(imageHeight || 0);
  const vw = Number(viewWidth || 0);
  const vh = Number(viewHeight || 0);
  const canMap = imgW > 0 && imgH > 0 && vw > 0 && vh > 0;

  const scale = canMap ? Math.min(vw / imgW, vh / imgH) : 1;
  const renderW = canMap ? imgW * scale : vw;
  const renderH = canMap ? imgH * scale : vh;
  const offsetX = canMap ? (vw - renderW) / 2 : 0;
  const offsetY = canMap ? (vh - renderH) / 2 : 0;

  ctx.save();
  ctx.lineWidth = 4;
  ctx.strokeStyle = "rgba(0, 255, 120, 0.95)";
  ctx.shadowColor = "rgba(0,0,0,0.3)";
  ctx.shadowBlur = 6;
  ctx.lineJoin = "round";
  ctx.lineCap = "round";

  ctx.beginPath();
  for (let i = 0; i < pathCells.length; i++) {
    const cell = pathCells[i];
    const xImg = (cell.col + 0.5) * gridCellPx;
    const yImg = (cell.row + 0.5) * gridCellPx;
    const x = offsetX + xImg * scale;
    const y = offsetY + yImg * scale;
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();

  // 起終點點位
  const start = pathCells[0];
  const end = pathCells[pathCells.length - 1];
  drawDot(
    ctx,
    offsetX + (start.col + 0.5) * gridCellPx * scale,
    offsetY + (start.row + 0.5) * gridCellPx * scale,
    "rgba(0, 200, 255, 0.95)"
  );
  drawDot(
    ctx,
    offsetX + (end.col + 0.5) * gridCellPx * scale,
    offsetY + (end.row + 0.5) * gridCellPx * scale,
    "rgba(255, 80, 80, 0.95)"
  );

  ctx.restore();
}

function drawDot(ctx, x, y, color) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.arc(x, y, 7, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

module.exports = {
  drawPath,
  drawOcrItems,
  drawBoothMarkers,
};

function drawOcrItems(
  ctx,
  { items, viewWidth, viewHeight, imageWidth, imageHeight, minScore = 0.85, maxTextLen = 10, maxItems = 800, showText = true }
) {
  const imgW = Number(imageWidth || 0);
  const imgH = Number(imageHeight || 0);
  const vw = Number(viewWidth || 0);
  const vh = Number(viewHeight || 0);
  const canMap = imgW > 0 && imgH > 0 && vw > 0 && vh > 0;

  const scale = canMap ? Math.min(vw / imgW, vh / imgH) : 1;
  const renderW = canMap ? imgW * scale : vw;
  const renderH = canMap ? imgH * scale : vh;
  const offsetX = canMap ? (vw - renderW) / 2 : 0;
  const offsetY = canMap ? (vh - renderH) / 2 : 0;

  ctx.save();
  ctx.lineWidth = 1;
  ctx.strokeStyle = "rgba(0, 180, 255, 0.55)";
  ctx.fillStyle = "rgba(0, 180, 255, 0.9)";
  ctx.font = "10px sans-serif";

  const eligible = [];
  for (const it of items || []) {
    const score = Number(it.score ?? 0);
    if (isFinite(score) && score < minScore) continue;
    const text = String(it.text || "").trim();
    if (!text) continue;
    if (text.length > maxTextLen) continue;
    const bb = it.bbox;
    if (!bb) continue;
    eligible.push(it);
  }

  const picked = pickItemsByVerticalBands({
    items: eligible,
    maxItems: Math.max(1, Number(maxItems || 0)),
    imageHeight: imgH,
    bands: 8,
  });

  let drawn = 0;
  for (const it of picked) {
    if (drawn >= maxItems) break;
    const bb = it.bbox;
    const text = String(it.text || "").trim();
    const x1 = offsetX + Number(bb.x1 || 0) * scale;
    const y1 = offsetY + Number(bb.y1 || 0) * scale;
    const x2 = offsetX + Number(bb.x2 || 0) * scale;
    const y2 = offsetY + Number(bb.y2 || 0) * scale;

    const w = Math.max(1, x2 - x1);
    const h = Math.max(1, y2 - y1);
    ctx.strokeRect(x1, y1, w, h);
    if (showText) ctx.fillText(text, x1, Math.max(10, y1 - 2));
    drawn++;
  }

  ctx.restore();
}

function pickItemsByVerticalBands({ items, maxItems, imageHeight, bands = 8 }) {
  const list = Array.isArray(items) ? items : [];
  if (!list.length || maxItems <= 0) return [];
  if (list.length <= maxItems) return list;

  const h = Number(imageHeight || 0);
  const bandN = Math.max(3, Math.min(12, Number(bands || 8)));
  if (!(h > 0)) return list.slice(0, maxItems);

  const buckets = Array.from({ length: bandN }, () => []);
  for (const it of list) {
    const bb = it?.bbox;
    const cy = bb ? (Number(bb.y1 || 0) + Number(bb.y2 || 0)) / 2 : 0;
    let bi = Math.floor((cy / h) * bandN);
    if (!isFinite(bi)) bi = 0;
    bi = Math.max(0, Math.min(bandN - 1, bi));
    buckets[bi].push(it);
  }
  for (const arr of buckets) arr.sort((a, b) => Number(b?.score || 0) - Number(a?.score || 0));

  const out = [];
  const used = new Set();
  // 第一輪：每帶至少拿一些，避免下半部完全沒框
  const perBandBase = Math.max(1, Math.floor(maxItems / bandN));
  for (let b = 0; b < bandN; b++) {
    const arr = buckets[b];
    const take = Math.min(arr.length, perBandBase);
    for (let i = 0; i < take && out.length < maxItems; i++) {
      const it = arr[i];
      if (used.has(it)) continue;
      used.add(it);
      out.push(it);
    }
  }
  // 第二輪：把剩餘名額按分數補滿
  if (out.length < maxItems) {
    const tail = [];
    for (const arr of buckets) {
      for (const it of arr) {
        if (!used.has(it)) tail.push(it);
      }
    }
    tail.sort((a, b) => Number(b?.score || 0) - Number(a?.score || 0));
    for (const it of tail) {
      if (out.length >= maxItems) break;
      out.push(it);
    }
  }
  return out;
}

function aspectFitTransform({ viewWidth, viewHeight, imageWidth, imageHeight }) {
  const imgW = Number(imageWidth || 0);
  const imgH = Number(imageHeight || 0);
  const vw = Number(viewWidth || 0);
  const vh = Number(viewHeight || 0);
  const canMap = imgW > 0 && imgH > 0 && vw > 0 && vh > 0;
  const scale = canMap ? Math.min(vw / imgW, vh / imgH) : 1;
  const renderW = canMap ? imgW * scale : vw;
  const renderH = canMap ? imgH * scale : vh;
  const offsetX = canMap ? (vw - renderW) / 2 : 0;
  const offsetY = canMap ? (vh - renderH) / 2 : 0;
  return { canMap, scale, offsetX, offsetY };
}

function mapPoint(xImg, yImg, tf) {
  return { x: tf.offsetX + xImg * tf.scale, y: tf.offsetY + yImg * tf.scale };
}

function drawPin(ctx, { x, y, color, label }) {
  ctx.save();
  ctx.fillStyle = color;
  ctx.strokeStyle = "rgba(0,0,0,0.25)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(x, y, 8, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  if (label) {
    ctx.font = "12px sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.fillText(label, x + 10, y - 10);
  }
  ctx.restore();
}

function drawBoothMarkers(ctx, { startBooth, endBooth, viewWidth, viewHeight, imageWidth, imageHeight }) {
  const tf = aspectFitTransform({ viewWidth, viewHeight, imageWidth, imageHeight });
  const getCenter = (b) => {
    const bb = b?.bbox;
    if (!bb) return null;
    const cx = (Number(bb.x1 || 0) + Number(bb.x2 || 0)) / 2;
    const cy = (Number(bb.y1 || 0) + Number(bb.y2 || 0)) / 2;
    return mapPoint(cx, cy, tf);
  };

  const s = getCenter(startBooth);
  const e = getCenter(endBooth);

  if (s) drawPin(ctx, { x: s.x, y: s.y, color: "rgba(0, 200, 255, 0.95)", label: "起點" });
  if (e) drawPin(ctx, { x: e.x, y: e.y, color: "rgba(255, 80, 80, 0.95)", label: "目的" });
}


