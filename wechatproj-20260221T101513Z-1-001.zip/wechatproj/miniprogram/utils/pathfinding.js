function keyOf(cell) {
  return `${cell.row},${cell.col}`;
}

function heuristic(a, b) {
  // Manhattan distance
  return Math.abs(a.row - b.row) + Math.abs(a.col - b.col);
}

function neighbors4(grid, cell) {
  const res = [];
  const dirs = [
    { dr: -1, dc: 0 },
    { dr: 1, dc: 0 },
    { dr: 0, dc: -1 },
    { dr: 0, dc: 1 },
  ];
  for (const d of dirs) {
    const r = cell.row + d.dr;
    const c = cell.col + d.dc;
    if (r < 0 || r >= grid.rows || c < 0 || c >= grid.cols) continue;
    if (grid.cells[r][c] !== 0) continue;
    res.push({ row: r, col: c });
  }
  return res;
}

// 簡潔 A*：回傳 cell 陣列（含起點與終點），找不到則 []
function astar(grid, start, goal) {
  if (!start || !goal) return [];
  if (start.row === goal.row && start.col === goal.col) return [start];
  if (grid.cells?.[start.row]?.[start.col] !== 0) return [];
  if (grid.cells?.[goal.row]?.[goal.col] !== 0) return [];

  const open = new Map(); // key -> {cell, f, g}
  const cameFrom = new Map(); // key -> prevKey
  const gScore = new Map(); // key -> g

  const startKey = keyOf(start);
  open.set(startKey, { cell: start, g: 0, f: heuristic(start, goal) });
  gScore.set(startKey, 0);

  while (open.size) {
    // 找 f 最小的節點（MVP：線性掃描；大量格子時可換成 binary heap）
    let currentKey = null;
    let current = null;
    for (const [k, v] of open.entries()) {
      if (!current || v.f < current.f) {
        current = v;
        currentKey = k;
      }
    }

    if (!current) break;
    const curCell = current.cell;
    if (curCell.row === goal.row && curCell.col === goal.col) {
      return reconstructPath(cameFrom, currentKey, startKey);
    }

    open.delete(currentKey);

    for (const nb of neighbors4(grid, curCell)) {
      const nbKey = keyOf(nb);
      const tentativeG = (gScore.get(currentKey) ?? Infinity) + 1;
      if (tentativeG < (gScore.get(nbKey) ?? Infinity)) {
        cameFrom.set(nbKey, currentKey);
        gScore.set(nbKey, tentativeG);
        const f = tentativeG + heuristic(nb, goal);
        open.set(nbKey, { cell: nb, g: tentativeG, f });
      }
    }
  }

  return [];
}

function reconstructPath(cameFrom, currentKey, startKey) {
  const path = [];
  let k = currentKey;
  while (k && k !== startKey) {
    const [row, col] = k.split(",").map((x) => Number(x));
    path.push({ row, col });
    k = cameFrom.get(k);
  }
  const [sr, sc] = startKey.split(",").map((x) => Number(x));
  path.push({ row: sr, col: sc });
  path.reverse();
  return path;
}

module.exports = {
  astar,
};





