function base64ToUint8Array(b64) {
  const bin = wx.base64ToArrayBuffer(b64);
  return new Uint8Array(bin);
}

function getBit(bytes, idx) {
  return (bytes[idx >> 3] >> (idx & 7)) & 1;
}

function bitsetToGridCells({ obstacleBitsetB64, rows, cols }) {
  const bytes = base64ToUint8Array(obstacleBitsetB64);
  const cells = new Array(rows);
  for (let r = 0; r < rows; r++) {
    const row = new Uint8Array(cols);
    for (let c = 0; c < cols; c++) {
      const i = r * cols + c;
      row[c] = getBit(bytes, i) ? 1 : 0;
    }
    cells[r] = row;
  }
  return cells;
}

module.exports = {
  bitsetToGridCells,
};



