async function getTempFileUrl(fileID) {
  if (!fileID) return "";
  const res = await wx.cloud.getTempFileURL({ fileList: [fileID] });
  const url = res.fileList?.[0]?.tempFileURL || "";
  return url;
}

module.exports = {
  getTempFileUrl,
};





