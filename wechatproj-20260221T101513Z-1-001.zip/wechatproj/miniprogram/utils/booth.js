function normalizeBoothId(input) {
  const t = String(input || "")
    .trim()
    .toUpperCase()
    .replace(/[\s\-_]/g, "");
  if (!t) return null;
  // 允許：A12 / B103 / 101，並把分隔符移除後回傳
  const m = t.match(/^[A-Z]?\d{1,3}$/);
  if (m) return t;
  // 從長字串中抓第一個符合的 token
  const m2 = t.match(/[A-Z]?\d{1,3}/);
  if (m2) return String(m2[0]).toUpperCase().replace(/[\s\-_]/g, "");
  return null;
}

function boothIdFromQrResult(qrResult) {
  const raw = typeof qrResult === "string" ? qrResult : qrResult?.result;
  const s = String(raw || "").trim();
  if (!s) return null;
  if ((s.startsWith("{") && s.endsWith("}")) || (s.startsWith("[") && s.endsWith("]"))) {
    try {
      const obj = JSON.parse(s);
      const cand = obj?.boothId || obj?.booth || obj?.id || obj?.value;
      const norm = normalizeBoothId(cand);
      if (norm) return norm;
    } catch (e) {
      // ignore
    }
  }
  return normalizeBoothId(s);
}

module.exports = {
  normalizeBoothId,
  boothIdFromQrResult,
};


