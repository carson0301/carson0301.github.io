App({
  onLaunch() {
    if (!wx.cloud) {
      console.error("請使用 2.2.3 或以上基礎庫以使用雲能力");
      return;
    }
    wx.cloud.init({
      // 不指定 env：使用微信開發者工具/雲開發面板目前選擇的環境
      // 若你想固定環境，可改成：env: "<你的 envId>"
      traceUser: true,
    });
  },
});



