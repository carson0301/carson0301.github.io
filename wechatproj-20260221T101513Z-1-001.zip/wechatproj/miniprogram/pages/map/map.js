const { getTempFileUrl } = require("../../utils/cloud");
const { buildGridFromBooths, boothCenterToCell, findNearestWalkable } = require("../../utils/grid");
const { astar } = require("../../utils/pathfinding");
const { drawPath, drawOcrItems } = require("../../utils/render");
const { loadFloorplanState } = require("../../utils/state");
const { normalizeBoothId, boothIdFromQrResult } = require("../../utils/booth");
const { bitsetToGridCells } = require("../../utils/bitset");

Page({
  data: {
    fileID: "",
    imgUrl: "",
    booths: [],
    boothIndex: [],
    boothCells: null,
    // 相容舊命名（後續可移除）
    boothRegions: null,
    ocrItems: [],
    grid: null,
    boothIds: [],
    imageMeta: null,
    coordSpace: null,
    cellStats: null,
    boothIndexStats: null,
    rowNumberMap: null,
    selectedCell: null,
    startIndex: -1,
    endIndex: -1,
    currentInput: "",
    destInput: "",
    planStatus: "尚未規劃",
    path: [],
    canPlan: false,
    gridCellPx: 16,
    showOcr: true,
    scale: 1,
    tapMode: "start", // "start" | "end"
    disableTapSelect: true,
    showDebug: false,
    parseDebug: null,
    lookupDebug: null,
    frontDirOptions: ["上方是正前方", "右方是正前方", "下方是正前方", "左方是正前方"],
    frontDirShort: ["上", "右", "下", "左"],
    frontDirIndex: 0,
    mapRotationDeg: 0,
  },

  async onLoad(query) {
    const fileID = decodeURIComponent(query.fileID || "");
    if (fileID) this.setData({ fileID });

    try {
      const eventChannel = this.getOpenerEventChannel?.();
      eventChannel?.on?.(
        "floorplanData",
        ({ booths, boothIndex, boothCells, boothRegions, imageMeta, ocrItems, gridCellPx, grid, parseDebug, coordSpace, cellStats, boothIndexStats, rowNumberMap }) => {
        const mergedCells = boothCells || boothRegions || [];
        const normalizedBoothIndex = this._normalizeBoothIndex(boothIndex || [], booths || [], mergedCells);
        const boothIds = normalizedBoothIndex.filter((x) => x.status !== "unresolved").map((x) => x.idCanonical);
        this.setData({
          booths: booths || [],
          boothIndex: normalizedBoothIndex,
          boothCells: boothCells || boothRegions || null,
          boothRegions: boothRegions || null,
          ocrItems: ocrItems || [],
          grid: grid || null,
          boothIds,
          imageMeta: imageMeta || null,
          coordSpace: coordSpace || null,
          cellStats: cellStats || null,
          boothIndexStats: boothIndexStats || null,
          rowNumberMap: rowNumberMap || null,
          selectedCell: null,
          parseDebug: parseDebug || null,
          startIndex: -1,
          endIndex: -1,
          gridCellPx: Number(gridCellPx || 16),
          currentInput: "",
          destInput: "",
        });
        this._syncBoothLookup(normalizedBoothIndex, boothIds);
        this._refreshCanPlan();
      }
      );
    } catch (e) {
      // redirectTo 進來時可能沒有 opener eventChannel，忽略
    }

    await this._restoreFromStorageIfNeeded();
    await this._ensureImgUrl();
  },

  onNav(e) {
    const to = e.detail?.to;
    if (to === "home") {
      wx.redirectTo({ url: "/pages/index/index" });
    }
  },

  setTapModeStart() {
    this.setData({ tapMode: "start" });
  },

  setTapModeEnd() {
    this.setData({ tapMode: "end" });
  },

  async onMapTap(e) {
    try {
      if (this.data.disableTapSelect) {
        wx.showToast({ title: "請改用輸入/掃碼設定起終點", icon: "none" });
        return;
      }
      if (!this.data.fileID) return;
      if (!this.data.booths?.length) return;
      // 重要：頁面可能捲動/重排，boundingClientRect 會變；每次點擊都刷新一次避免座標整體偏移
      await this._measureArea();
      if (!this._areaRect) return;

      // 1) 點擊在 movable-area 的本地座標（view coords）
      // 注意：不同機型/基礎庫版本下，tap 的 e.detail.x/y、touch.x/y、clientX/pageX 可能是「元件內」或「頁面/視窗」座標。
      // 我們不只用「是否落在 mapArea 寬高內」，還用「離最近 cell 的距離」來挑最佳候選，避免候選落在範圍內但仍被錯誤解讀。
      let localX = NaN;
      let localY = NaN;
      let src = "none";
      const rectLeft = Number(this._areaRect.left || 0);
      const rectTop = Number(this._areaRect.top || 0);
      const rectW = Number(this._areaRect.width || 0);
      const rectH = Number(this._areaRect.height || 0);
      const inRect = (pt) =>
        pt &&
        isFinite(pt.x) &&
        isFinite(pt.y) &&
        pt.x >= 0 &&
        pt.y >= 0 &&
        (!rectW || pt.x <= rectW) &&
        (!rectH || pt.y <= rectH);

      const t = e.changedTouches?.[0] || e.touches?.[0] || null;

      const tf = this._getAspectFitTf();
      const rawList = [
        { name: "touchxy", x: t?.x, y: t?.y },
        { name: "detail", x: e?.detail?.x, y: e?.detail?.y },
        { name: "client", x: t?.clientX, y: t?.clientY },
        { name: "page", x: t?.pageX, y: t?.pageY },
      ];

      const candidates = [];
      for (const r of rawList) {
        const rx = Number(r.x);
        const ry = Number(r.y);
        if (!isFinite(rx) || !isFinite(ry)) continue;
        const c1 = { x: rx, y: ry, src: `${r.name}-local` };
        const c2 = { x: rx - rectLeft, y: ry - rectTop, src: `${r.name}-page` };
        if (inRect(c1)) candidates.push(c1);
        if (inRect(c2)) candidates.push(c2);
      }
      if (!candidates.length) return;

      // 用 cellNear 距離挑最合理候選；若沒有 boothCells，就退回第一個候選
      let best = candidates[0];
      if (tf && (this.data.boothCells?.length || this.data.boothRegions?.length)) {
        let bestScore = Infinity;
        for (const c of candidates) {
          const near = this._nearestCellByTapView({ x: c.x, y: c.y }, tf);
          const score = near?.distPx != null ? Number(near.distPx) : Infinity;
          if (score < bestScore) {
            bestScore = score;
            best = c;
          }
        }
      }
      localX = best.x;
      localY = best.y;
      src = best.src;

      // 改用「正向映射」找攤位：把每個攤位 bbox 映射到螢幕座標後用 localX/localY 命中或找最近
      const pick = this._pickBoothByTap({ x: localX, y: localY });
      // tapImg 只保留給 debug（反算在不同機型可能不準），實際命中改用「正向映射」的 cellHit/cellNear
      const tapImg = tf ? this._mapViewToImg({ x: localX, y: localY }, tf) : null;
      const imgPickIdx = tapImg ? this._findBoothByPoint(tapImg) : -1;
      const regionHit = tf ? this._findCellByTapView({ x: localX, y: localY }, tf) : null;
      const regionNear = tf ? this._nearestCellByTapView({ x: localX, y: localY }, tf) : null;
      const regionIdx = regionHit?.labelId ? this._findBoothIndex(regionHit.labelId) : -1;
      if (regionHit) this.setData({ selectedCell: regionHit });

      // 計算「被選攤位中心」在螢幕座標的位置（用來對照十字是否離很遠）
      let pickedCenterView = null;
      const pickedIdx = regionIdx >= 0 ? regionIdx : (pick?.idx ?? -1);
      const pickedId = regionHit?.labelId || (pickedIdx >= 0 ? this.data.boothIds?.[pickedIdx] : null);
      if (pickedIdx >= 0 && tf) {
        const b = this.data.booths?.[pickedIdx];
        const bb = b?.bbox;
        const c = b?.center;
        if (bb || c) {
          const cxImg = c?.x ?? (bb.x1 + bb.x2) / 2;
          const cyImg = c?.y ?? (bb.y1 + bb.y2) / 2;
          pickedCenterView = this._applyMovableTf(this._mapImgToView({ x: cxImg, y: cyImg }, tf));
        }
      }

      this._lastTapDebug = {
        viewX: localX,
        viewY: localY,
        picked: pick?.idx ?? -1,
        pickedId,
        reason: pick?.reason || null,
        distPx: pick?.distPx ?? null,
        thresholdPx: pick?.thresholdPx ?? null,
        src,
        rect: this._areaRect
          ? {
              left: Number(this._areaRect.left || 0),
              top: Number(this._areaRect.top || 0),
              width: Number(this._areaRect.width || 0),
              height: Number(this._areaRect.height || 0),
            }
          : null,
        tapImg: tapImg ? { x: tapImg.x, y: tapImg.y } : null,
        imgPickIdx,
        regionIdx,
        regionHit,
        regionNear,
        pickedCenterView,
      };
      let boothIdx = pickedIdx;
      if (regionHit?.labelId) {
        boothIdx = this._findBoothIndex(regionHit.labelId);
      } else if (regionHit && !regionHit.labelId) {
        wx.showToast({ title: "此格未辨識到攤位編號", icon: "none" });
        this._redraw();
        return;
      }
      if (boothIdx < 0) {
        wx.showToast({ title: "此處找不到攤位", icon: "none" });
        this._redraw();
        return;
      }

      const id = regionHit?.labelId || pickedId || this.data.boothIds[boothIdx];
      if (this.data.tapMode === "start") {
        this._lastTapSet = { ...(this._lastTapSet || {}), start: { x: localX, y: localY } };
        this.setData({ currentInput: id, tapMode: "end" });
        this.onSetCurrent();
      } else {
        this._lastTapSet = { ...(this._lastTapSet || {}), end: { x: localX, y: localY } };
        this.setData({ destInput: id, tapMode: "start" });
        this.onSetDest();
      }
      this._redraw();
    } catch (err) {
      console.error(err);
    }
  },

  onPickEnd(e) {
    const endIndex = Number(e.detail.value || 0);
    this.setData({ endIndex, destInput: this.data.boothIds[endIndex] || this.data.destInput });
    this._refreshCanPlan();
    if (this.data.path?.length) this.onPlan();
  },

  onClear() {
    this.setData({ path: [], planStatus: "已清除" });
    this._redraw();
  },

  onInputCurrent(e) {
    this.setData({ currentInput: e.detail.value });
  },

  onInputDest(e) {
    this.setData({ destInput: e.detail.value });
  },

  onSetCurrent() {
    const id = normalizeBoothId(this.data.currentInput);
    if (!id) {
      wx.showToast({ title: "攤位號格式不正確", icon: "none" });
      return;
    }
    const resolved = this._resolveBoothIndexByInput(id);
    this._setLookupDebug("current", id, resolved);
    const idx = resolved.idx;
    if (idx < 0) {
      if (resolved.reason === "ambiguous_num") {
        wx.showToast({ title: `同號多列：${resolved.candidates.join("/")}`, icon: "none" });
        return;
      }
      wx.showToast({ title: "找不到此攤位", icon: "none" });
      return;
    }
    this.setData({ startIndex: idx, currentInput: id });
    const ent = this._boothUiEntries?.[idx];
    if (ent?.status === "inferred") wx.showToast({ title: "此攤位為推斷結果", icon: "none" });
    this._refreshCanPlan();
    this._redraw(); // 起點標記要立即同步
    // 若已有路徑，立即重算
    if (this.data.path?.length) this.onPlan();
  },

  async onScanCurrent() {
    try {
      const scan = await wx.scanCode({ scanType: ["qrCode"] });
      const id = boothIdFromQrResult(scan);
      if (!id) {
        wx.showToast({ title: "QR 未包含攤位號", icon: "none" });
        return;
      }
      this.setData({ currentInput: id });
      this.onSetCurrent();
    } catch (e) {
      console.error(e);
      wx.showToast({ title: "掃描失敗", icon: "error" });
    }
  },

  onSetDest() {
    const id = normalizeBoothId(this.data.destInput);
    if (!id) {
      wx.showToast({ title: "攤位號格式不正確", icon: "none" });
      return;
    }
    const resolved = this._resolveBoothIndexByInput(id);
    this._setLookupDebug("dest", id, resolved);
    const idx = resolved.idx;
    if (idx < 0) {
      if (resolved.reason === "ambiguous_num") {
        wx.showToast({ title: `同號多列：${resolved.candidates.join("/")}`, icon: "none" });
        return;
      }
      wx.showToast({ title: "找不到此攤位", icon: "none" });
      return;
    }
    this.setData({ endIndex: idx, destInput: id });
    const ent = this._boothUiEntries?.[idx];
    if (ent?.status === "inferred") wx.showToast({ title: "此攤位為推斷結果", icon: "none" });
    this._refreshCanPlan();
    this._redraw();
    if (this.data.path?.length) this.onPlan();
  },

  async onScanDest() {
    try {
      const scan = await wx.scanCode({ scanType: ["qrCode"] });
      const id = boothIdFromQrResult(scan);
      if (!id) {
        wx.showToast({ title: "QR 未包含攤位號", icon: "none" });
        return;
      }
      this.setData({ destInput: id });
      this.onSetDest();
    } catch (e) {
      console.error(e);
      wx.showToast({ title: "掃描失敗", icon: "error" });
    }
  },

  onToggleOcr(e) {
    this.setData({ showOcr: !!e.detail.value });
    this._redraw();
  },

  onToggleDebug(e) {
    this.setData({ showDebug: !!e.detail.value });
    this._redraw();
  },

  _rotationDegByFrontIndex(idx) {
    // 使用者面向「右方」代表地圖需逆時針 90 度，讓前方回到上方
    const i = Number(idx || 0);
    if (i === 1) return 270;
    if (i === 2) return 180;
    if (i === 3) return 90;
    return 0;
  },

  _setFrontDirIndex(idx) {
    const i = Number(idx || 0);
    const safe = Math.max(0, Math.min(3, i));
    const deg = this._rotationDegByFrontIndex(safe);
    this.setData({ frontDirIndex: safe, mapRotationDeg: deg });
    this._scheduleRedraw();
  },

  onFrontDirChange(e) {
    const idx = Number(e?.detail?.value || 0);
    this._setFrontDirIndex(idx);
  },

  setFrontTop() {
    this._setFrontDirIndex(0);
  },

  setFrontRight() {
    this._setFrontDirIndex(1);
  },

  setFrontBottom() {
    this._setFrontDirIndex(2);
  },

  setFrontLeft() {
    this._setFrontDirIndex(3);
  },

  _applyMapRotation(ctx) {
    const deg = Number(this.data.mapRotationDeg || 0);
    if (!deg) return;
    const cx = (this._cssW || 0) / 2;
    const cy = (this._cssH || 0) / 2;
    ctx.translate(cx, cy);
    ctx.rotate((deg * Math.PI) / 180);
    ctx.translate(-cx, -cy);
  },

  _rotatePointAroundCenter(pt, deg) {
    const x = Number(pt?.x);
    const y = Number(pt?.y);
    if (!isFinite(x) || !isFinite(y)) return null;
    const d = Number(deg || 0);
    if (!d) return { x, y };
    const cx = (this._cssW || 0) / 2;
    const cy = (this._cssH || 0) / 2;
    const rad = (d * Math.PI) / 180;
    const dx = x - cx;
    const dy = y - cy;
    const rx = dx * Math.cos(rad) - dy * Math.sin(rad);
    const ry = dx * Math.sin(rad) + dy * Math.cos(rad);
    return { x: cx + rx, y: cy + ry };
  },

  _inverseRotatePointAroundCenter(pt, deg) {
    return this._rotatePointAroundCenter(pt, -Number(deg || 0));
  },

  _toRotatedView(pt) {
    return this._rotatePointAroundCenter(pt, Number(this.data.mapRotationDeg || 0));
  },

  _fromRotatedView(pt) {
    return this._inverseRotatePointAroundCenter(pt, Number(this.data.mapRotationDeg || 0));
  },

  _mapImgToScreen(ptImg, tf) {
    if (!ptImg || !tf) return null;
    const p0 = this._mapImgToView(ptImg, tf);
    const p1 = this._toRotatedView(p0);
    return this._applyMovableTf(p1);
  },

  _drawMarkerOnScreen(ctx, pt, color, label) {
    if (!pt) return;
    ctx.save();
    ctx.fillStyle = color;
    ctx.strokeStyle = "rgba(0,0,0,0.25)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, 10, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    if (label) {
      ctx.font = "12px sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.95)";
      ctx.fillText(label, pt.x + 12, pt.y - 10);
    }
    ctx.restore();
  },

  onScale(e) {
    // 已改用 onMoveScale/onMoveChange 以同步 canvas transform
  },

  onZoomIn() {
    const s = Math.min(8, (this.data.scale || 1) + 0.4);
    this.setData({ scale: s });
    this._mvScale = s;
    this._lastInteractAt = Date.now();
    this._programmaticScaleUntil = Date.now() + 220;
    this._scheduleRedraw();
  },

  onZoomOut() {
    const s = Math.max(0.5, (this.data.scale || 1) - 0.4);
    this.setData({ scale: s });
    this._mvScale = s;
    this._lastInteractAt = Date.now();
    this._programmaticScaleUntil = Date.now() + 220;
    this._scheduleRedraw();
  },

  onMoveChange(e) {
    // 追蹤平移（x/y）
    const x = Number(e.detail.x || 0);
    const y = Number(e.detail.y || 0);
    this._mvX = isFinite(x) ? x : 0;
    this._mvY = isFinite(y) ? y : 0;
    this._lastInteractAt = Date.now();
    this._scheduleRedraw();
  },

  onMoveScale(e) {
    // 追蹤縮放，並節流更新 data.scale（避免 feedback loop 抖動）
    const s = Number(e.detail.scale || 1);
    if (isFinite(s)) this._mvScale = s;
    // 關鍵：部分機型在縮放時 x/y 只出現在 bindscale，不會即時出現在 bindchange。
    // 若不同步，會出現「放大偏移、拖一下才回正」。
    const x = Number(e?.detail?.x);
    const y = Number(e?.detail?.y);
    if (isFinite(x)) this._mvX = x;
    if (isFinite(y)) this._mvY = y;
    this._lastInteractAt = Date.now();
    const now = Date.now();
    // 若剛用按鈕觸發縮放，短時間內不要讓 bindscale 把 data.scale 回寫成舊值（避免縮放回彈）
    if (this._programmaticScaleUntil && now < this._programmaticScaleUntil) {
      this._scheduleRedraw();
      return;
    }
    if (!this._lastScaleSet || now - this._lastScaleSet > 120) {
      this._lastScaleSet = now;
      const cur = Number(this.data.scale || 1);
      if (Math.abs(cur - s) > 0.05) this.setData({ scale: s });
    }
    this._scheduleRedraw();
  },

  async onPlan() {
    try {
      const { booths, boothIds, startIndex, endIndex, gridCellPx, imageMeta, grid } = this.data;
      if (!boothIds.length) return;
      if (startIndex < 0) {
        wx.showToast({ title: "請先設定目前位置", icon: "none" });
        return;
      }
      if (startIndex === endIndex) {
        wx.showToast({ title: "起終點不可相同", icon: "none" });
        return;
      }
      this.setData({ planStatus: "建構網格中…" });
      wx.showLoading({ title: "規劃中" });

      const navGrid = this._buildNavGrid({ booths, imageMeta, gridCellPx, serverGrid: grid });

      const startBooth = this._boothUiEntries?.[startIndex] || null;
      const endBooth = this._boothUiEntries?.[endIndex] || null;
      if (!startBooth?.center || !endBooth?.center) {
        wx.hideLoading();
        wx.showToast({ title: "起終點缺少定位資料", icon: "none" });
        this.setData({ planStatus: "起終點缺少定位資料" });
        return;
      }

      const startCellRaw = boothCenterToCell(startBooth.center, navGrid.cellSizePx);
      const endCellRaw = boothCenterToCell(endBooth.center, navGrid.cellSizePx);

      const startCell = findNearestWalkable(navGrid, startCellRaw);
      const endCell = findNearestWalkable(navGrid, endCellRaw);

      this.setData({ planStatus: "A* 計算最短路徑中…" });
      const path = astar(navGrid, startCell, endCell);

      if (!path.length) {
        wx.hideLoading();
        wx.showToast({ title: "找不到可行路徑", icon: "none" });
        this.setData({ planStatus: "無可行路徑", path: [] });
        this._redraw();
        return;
      }

      this.setData({ planStatus: `完成（步數 ${path.length}）`, path });
      wx.hideLoading();
      this._redraw();
    } catch (e) {
      console.error(e);
      wx.hideLoading();
      wx.showToast({ title: "規劃失敗", icon: "error" });
      this.setData({ planStatus: "規劃失敗（請重試）" });
    }
  },

  async onImgLoad(e) {
    // 保底：以 image 元件實際載入到的原始寬高作為 imageMeta（避免 storage/雲端缺失導致座標映射失準）
    const w = Number(e?.detail?.width || 0);
    const h = Number(e?.detail?.height || 0);
    if (w > 0 && h > 0) {
      this._loadedImgW = w;
      this._loadedImgH = h;
    }
    if (w > 0 && h > 0) {
      const cisW = Number(this.data.coordSpace?.width || 0);
      const cisH = Number(this.data.coordSpace?.height || 0);
      if (cisW > 0 && cisH > 0) {
        this._imgMetaMismatch = Math.abs(cisW - w) > 1 || Math.abs(cisH - h) > 1;
      }
      const curW = Number(this.data.imageMeta?.width || 0);
      const curH = Number(this.data.imageMeta?.height || 0);
      // 若雲端已提供 CIS 尺寸，避免 bindload 尺寸覆蓋業務座標空間
      if (!(curW === w && curH === h) && !(cisW > 0 && cisH > 0)) {
        this.setData({ imageMeta: { ...(this.data.imageMeta || {}), width: w, height: h } });
      }
    }
    await this._initCanvas();
    this._redraw();
  },

  _buildNavGrid({ booths, imageMeta, gridCellPx, serverGrid }) {
    // 優先使用雲端回傳的走道 occupancy grid，確保路徑只在走道上
    if (serverGrid?.rows && serverGrid?.cols && serverGrid?.obstacleBitsetB64) {
      this._lastGridSource = "server";
      const cells = bitsetToGridCells({
        obstacleBitsetB64: serverGrid.obstacleBitsetB64,
        rows: serverGrid.rows,
        cols: serverGrid.cols,
      });
      return {
        rows: serverGrid.rows,
        cols: serverGrid.cols,
        cellSizePx: Number(serverGrid.cellSizePx || gridCellPx || 16),
        cells,
      };
    }
    this._lastGridSource = "booth-only";
    // fallback：舊版 booth-only grid
    return buildGridFromBooths({
      booths,
      imageWidth: imageMeta?.width,
      imageHeight: imageMeta?.height,
      cellSizePx: gridCellPx,
    });
  },

  async _restoreFromStorageIfNeeded() {
    // 若沒有從 eventChannel 帶入資料，就從 storage 取回
    if (this.data.booths?.length) return;
    const st = loadFloorplanState();
    if (!st?.fileID) return;
    const mergedCells = st.boothCells || st.boothRegions || [];
    const normalizedBoothIndex = this._normalizeBoothIndex(st.boothIndex || [], st.booths || [], mergedCells);
    const boothIds = normalizedBoothIndex.filter((x) => x.status !== "unresolved").map((x) => x.idCanonical);
    this.setData({
      fileID: this.data.fileID || st.fileID,
      booths: st.booths || [],
      boothIndex: normalizedBoothIndex,
      boothCells: st.boothCells || st.boothRegions || null,
      boothRegions: st.boothRegions || null,
      ocrItems: st.ocrItems || [],
      grid: st.grid || null,
      boothIds,
      imageMeta: st.imageMeta || null,
      coordSpace: st.coordSpace || null,
      cellStats: st.cellStats || null,
      boothIndexStats: st.boothIndexStats || null,
      rowNumberMap: st.rowNumberMap || null,
      selectedCell: null,
      parseDebug: st.parseDebug || null,
      gridCellPx: st.gridCellPx || this.data.gridCellPx,
      startIndex: -1,
      endIndex: -1,
      currentInput: "",
      destInput: "",
    });
    this._syncBoothLookup(normalizedBoothIndex, boothIds);
    this._refreshCanPlan();
  },

  async _ensureImgUrl() {
    if (this.data.imgUrl) return;
    if (!this.data.fileID) return;
    const imgUrl = await getTempFileUrl(this.data.fileID);
    this.setData({ imgUrl });
  },

  _normIdKey(id) {
    return String(id || "")
      .trim()
      .toUpperCase()
      .replace(/[\s\-_]/g, "");
  },

  _normalizeBoothIndex(rawIndex, booths, cells) {
    const raw = Array.isArray(rawIndex) ? rawIndex : [];
    const boothList = Array.isArray(booths) ? booths : [];
    const cellList = Array.isArray(cells) ? cells : [];
    const byCell = new Map();
    for (const c of cellList) if (c?.key) byCell.set(String(c.key), c);
    const byBoothId = new Map();
    for (const b of boothList) {
      const k = this._normIdKey(b?.id);
      if (k) byBoothId.set(k, b);
    }

    const outMap = new Map();
    const buildLocalAliases = (idCanonical) => {
      const s = this._normIdKey(idCanonical);
      const m = s.match(/^([A-Z]?)(\d{1,3})$/);
      if (!m) return [s];
      const p = m[1] || "";
      const nRaw = m[2];
      const nNum = String(Number(nRaw));
      const out = new Set([`${p}${nRaw}`, `${p}${nNum}`, `${p}-${nRaw}`, `${p}_${nRaw}`, `${p} ${nRaw}`]);
      if (p === "I") {
        out.add(`1${nRaw}`);
        out.add(`1${nNum}`);
      }
      return Array.from(out);
    };

    const upsert = (e) => {
      const id = this._normIdKey(e?.idCanonical || e?.id);
      if (!id) return;
      const prev = outMap.get(id);
      const conf = Number(e?.confidence || 0);
      const rankOf = (x) => {
        const ev = String(x?.evidence || "").toLowerCase();
        const hasCell = !!x?.cellId;
        const hasRowCol = isFinite(x?.row) && isFinite(x?.col);
        const hasGeom = !!x?.bbox && !!x?.center;
        let s = 0;
        if (hasCell) s += 6;
        if (hasRowCol) s += 4;
        if (hasGeom) s += 2;
        if (ev.includes("cell_label")) s += 3;
        if (ev.includes("row_interp") || ev.includes("row_gap")) s += 2;
        if (ev.includes("runtime")) s += 1;
        if (ev.includes("ocr_booth")) s -= 1;
        return s;
      };
      const nextRank = rankOf(e);
      const prevRank = rankOf(prev);
      if (!prev || nextRank > prevRank || (nextRank === prevRank && conf >= Number(prev.confidence || 0))) {
        outMap.set(id, {
          idCanonical: id,
          status: e?.status || prev?.status || "confirmed",
          confidence: conf,
          evidence: e?.evidence || prev?.evidence || "unknown",
          aliases: Array.from(new Set([...(prev?.aliases || []), ...(e?.aliases || []), ...buildLocalAliases(id)])),
          cellId: e?.cellId || prev?.cellId || null,
          bbox: e?.bbox || prev?.bbox || null,
          center: e?.center || prev?.center || null,
          row: isFinite(e?.row) ? Number(e.row) : prev?.row ?? null,
          col: isFinite(e?.col) ? Number(e.col) : prev?.col ?? null,
        });
      }
    };

    for (const e of raw) upsert(e);
    if (!outMap.size) {
      for (const b of boothList) {
        const id = this._normIdKey(b?.id);
        if (!id) continue;
        upsert({
          idCanonical: id,
          status: "confirmed",
          confidence: Number(b?.score ?? 0.6),
          evidence: "ocr_booth",
          aliases: [id],
          bbox: b?.bbox || null,
          center: b?.center || null,
        });
      }
    }

    for (const [id, e] of outMap.entries()) {
      if ((!e.bbox || !e.center) && e.cellId && byCell.has(String(e.cellId))) {
        const c = byCell.get(String(e.cellId));
        e.bbox = e.bbox || c?.bbox || null;
        e.center = e.center || c?.center || null;
      }
      if ((!e.bbox || !e.center) && byBoothId.has(id)) {
        const b = byBoothId.get(id);
        e.bbox = e.bbox || b?.bbox || null;
        e.center = e.center || b?.center || null;
      }
      outMap.set(id, e);
    }
    return Array.from(outMap.values()).sort((a, b) => String(a.idCanonical).localeCompare(String(b.idCanonical)));
  },

  _syncBoothLookup(boothIndex, boothIds) {
    const list = Array.isArray(boothIndex) ? boothIndex : [];
    const ids = Array.isArray(boothIds) ? boothIds : [];
    this._boothUiEntries = ids
      .map((id) => list.find((x) => this._normIdKey(x?.idCanonical) === this._normIdKey(id)))
      .filter(Boolean);
    const m = new Map();
    for (let i = 0; i < this._boothUiEntries.length; i++) {
      const e = this._boothUiEntries[i];
      const aliases = Array.from(new Set([e.idCanonical, ...(e.aliases || [])]));
      for (const a of aliases) {
        const k = this._normIdKey(a);
        if (k && !m.has(k)) m.set(k, i);
      }
    }
    this._boothAliasToUiIdx = m;

    const listAK = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
    const counts = {};
    for (const r of listAK) counts[r] = 0;
    for (const e of list) {
      const p = this._parseBoothParts(e?.idCanonical);
      if (!p?.prefix) continue;
      if (!listAK.includes(p.prefix)) continue;
      if (e?.status === "unresolved") continue;
      if (!isFinite(e?.col)) continue;
      counts[p.prefix] += 1;
    }
    const weak = listAK.filter((r) => (counts[r] || 0) < 2);
    this._anchorCoverage = {
      counts,
      weakRows: weak,
      summary: listAK.map((r) => `${r}:${counts[r] || 0}`).join(" "),
    };
  },

  _parseBoothParts(id) {
    const s = this._normIdKey(id);
    if (!s) return null;
    const m = s.match(/^([A-Z]?)(\d{1,3})$/);
    if (!m) return null;
    return { prefix: m[1] || "", num: Number(m[2]), rawNum: m[2] };
  },

  _setLookupDebug(slot, inputId, resolved) {
    const cur = this.data.lookupDebug || {};
    const next = {
      ...cur,
      [slot]: {
        query: inputId || "",
        path: resolved?.matchPath || resolved?.reason || "not_found",
        matchedId: resolved?.matchedId || "",
        prefix: resolved?.matchedPrefix || "",
        reason: resolved?.reason || "",
      },
    };
    this.setData({ lookupDebug: next });
  },

  _collectCandidatesByNumber(num) {
    const n = Number(num);
    if (!isFinite(n)) return [];
    return (this._boothUiEntries || []).filter((e) => {
      const p = this._parseBoothParts(e?.idCanonical);
      if (!p || !p.prefix) return false;
      return Number(p.num) === n;
    });
  },

  _resolveBoothIndexByInput(inputId) {
    const p = this._parseBoothParts(inputId);
    if (!p) return { idx: -1, reason: "invalid", matchPath: "fallback", matchedId: "", matchedPrefix: "", candidates: [] };
    if (p.prefix) {
      const exact = `${p.prefix}${p.rawNum}`;
      const entriesForExpect = Array.isArray(this.data.boothIndex) ? this.data.boothIndex : [];
      const prefixGroupsForExpect = new Map();
      for (const e of entriesForExpect) {
        const ep = this._parseBoothParts(e?.idCanonical);
        if (!ep) continue;
        const arr = prefixGroupsForExpect.get(ep.prefix) || [];
        arr.push({ p: ep });
        prefixGroupsForExpect.set(ep.prefix, arr);
      }
      const expectExists = this._shouldExpectPrefixNumber(p, prefixGroupsForExpect);
      const locked = this._findBoothIndexWithRoute(exact, { prefixLock: p.prefix });
      if (locked.idx >= 0) {
        const ent = this._boothUiEntries?.[locked.idx];
        if (this._isLowTrustExactPrefixHit(ent, p)) {
          const refined = this._tryInferRuntimeBoothWithOptions(exact, { expectExists: true });
          if (refined >= 0) {
            const re = this._boothUiEntries?.[refined];
            const rp = this._parseBoothParts(re?.idCanonical);
            return {
              idx: refined,
              reason: "exact_refined",
              matchPath: "inferred",
              matchedId: re?.idCanonical || exact,
              matchedPrefix: rp?.prefix || p.prefix,
              candidates: [],
            };
          }
        }
        return {
          idx: locked.idx,
          reason: locked.route === "alias" ? "alias_row" : "exact_row",
          matchPath: locked.route,
          matchedId: locked.idCanonical || exact,
          matchedPrefix: p.prefix,
          candidates: [],
        };
      }
      let idx = -1;
      idx = this._tryInferRuntimeBoothWithOptions(exact, { expectExists });
      if (idx >= 0) {
        const ent = this._boothUiEntries?.[idx];
        const ep = this._parseBoothParts(ent?.idCanonical);
        return {
          idx,
          reason: "runtime_infer",
          matchPath: "inferred",
          matchedId: ent?.idCanonical || exact,
          matchedPrefix: ep?.prefix || p.prefix,
          candidates: [],
        };
      }
      // fallback：同列近號（避免嚴格推斷時全部失敗）
      const near = (this._boothUiEntries || [])
        .map((e, i) => ({ e, i, p: this._parseBoothParts(e?.idCanonical) }))
        .filter((x) => x.p && x.p.prefix === p.prefix)
        .sort((a, b) => Math.abs(Number(a.p.num) - Number(p.num)) - Math.abs(Number(b.p.num) - Number(p.num)));
      if (near.length && Math.abs(Number(near[0].p.num) - Number(p.num)) <= 1) {
        return {
          idx: near[0].i,
          reason: "near_num_fallback",
          matchPath: "fallback",
          matchedId: near[0].e.idCanonical,
          matchedPrefix: p.prefix,
          candidates: [near[0].e.idCanonical],
        };
      }
      return { idx: -1, reason: "not_found_row", matchPath: "fallback", matchedId: "", matchedPrefix: p.prefix, candidates: [] };
    }
    const loose = this._findBoothIndexWithRoute(`${p.rawNum}`);
    if (loose.idx >= 0) {
      const ep = this._parseBoothParts(loose.idCanonical);
      return {
        idx: loose.idx,
        reason: loose.route === "alias" ? "alias_num" : "exact_num",
        matchPath: loose.route,
        matchedId: loose.idCanonical || "",
        matchedPrefix: ep?.prefix || "",
        candidates: [],
      };
    }
    const cands = this._collectCandidatesByNumber(p.num).map((e) => e.idCanonical);
    if (!cands.length) return { idx: -1, reason: "not_found_num", matchPath: "fallback", matchedId: "", matchedPrefix: "", candidates: [] };
    if (cands.length === 1) {
      const idx = this._findBoothIndex(cands[0]);
      const ep = this._parseBoothParts(cands[0]);
      return {
        idx,
        reason: "single_num",
        matchPath: "fallback",
        matchedId: cands[0],
        matchedPrefix: ep?.prefix || "",
        candidates: [],
      };
    }
    return { idx: -1, reason: "ambiguous_num", matchPath: "fallback", matchedId: "", matchedPrefix: "", candidates: cands.slice(0, 8) };
  },

  _letterRank(ch) {
    const s = String(ch || "").toUpperCase();
    if (!/^[A-Z]$/.test(s)) return -1;
    return s.charCodeAt(0) - 65;
  },

  _estimateColByAnchors(anchors, targetNum) {
    const arr = (anchors || [])
      .filter((x) => isFinite(x?.num) && isFinite(x?.col))
      .slice()
      .sort((a, b) => Number(a.num) - Number(b.num));
    if (arr.length < 2 || !isFinite(targetNum)) return null;
    let left = null;
    let right = null;
    for (const a of arr) {
      if (Number(a.num) <= targetNum) left = a;
      if (Number(a.num) > targetNum) {
        right = a;
        break;
      }
    }
    if (!left) left = arr[0];
    if (!right) right = arr[arr.length - 1];
    if (!left || !right || left === right) return null;
    const n1 = Number(left.num);
    const n2 = Number(right.num);
    const c1 = Number(left.col);
    const c2 = Number(right.col);
    const y1 = Number(left.cy ?? 0);
    const y2 = Number(right.cy ?? 0);
    const x1 = Number(left.cx ?? 0);
    const x2 = Number(right.cx ?? 0);
    if (!(n2 > n1 && isFinite(c1) && isFinite(c2))) return null;
    // 避免用跨大段號碼做線性推估（例如 20 直接連到 52）
    if (n2 - n1 > 14) return null;
    const t = (targetNum - n1) / Math.max(1, n2 - n1);
    return {
      col: c1 + (c2 - c1) * t,
      cx: isFinite(x1) && isFinite(x2) ? x1 + (x2 - x1) * t : null,
      cy: isFinite(y1) && isFinite(y2) ? y1 + (y2 - y1) * t : null,
    };
  },

  _estimateColByPrefixLinearAnchors(anchors, targetNum) {
    const arr = (anchors || [])
      .filter((x) => isFinite(x?.p?.num) && isFinite(x?.col))
      .map((x) => ({
        num: Number(x.p.num),
        col: Number(x.col),
        cx: Number(x.cx),
        cy: Number(x.cy),
      }));
    if (arr.length < 2 || !isFinite(targetNum)) return null;
    const n = arr.length;
    let sumN = 0;
    let sumC = 0;
    let sumNN = 0;
    let sumNC = 0;
    for (const a of arr) {
      sumN += a.num;
      sumC += a.col;
      sumNN += a.num * a.num;
      sumNC += a.num * a.col;
    }
    const den = n * sumNN - sumN * sumN;
    if (Math.abs(den) < 1e-6) return null;
    const k = (n * sumNC - sumN * sumC) / den;
    const b = (sumC - k * sumN) / n;
    if (!isFinite(k) || !isFinite(b)) return null;
    // 斜率方向防呆：攤位號遞增時欄位通常遞增
    if (k <= 0) return null;
    const col = k * Number(targetNum) + b;
    if (!isFinite(col)) return null;
    return { col };
  },

  _estimateByNeighborRowsSameNum(prefixGroups, qPrefix, targetNum) {
    const qRank = this._letterRank(qPrefix);
    if (qRank < 0 || !isFinite(targetNum)) return null;
    let wSum = 0;
    let colAcc = 0;
    let xAcc = 0;
    let yAcc = 0;
    let hasXY = false;
    for (const [prefix, arr] of prefixGroups.entries()) {
      const pr = this._letterRank(prefix);
      if (pr < 0) continue;
      const dRank = Math.abs(pr - qRank);
      if (dRank === 0 || dRank > 4) continue; // 擴至 A-Z 較遠鄰列以提高召回
      let best = null;
      let bestDN = Infinity;
      for (const a of arr) {
        const dn = Math.abs(Number(a.p?.num) - Number(targetNum));
        if (dn < bestDN) {
          bestDN = dn;
          best = a;
        }
      }
      if (!best || bestDN > 2 || !isFinite(best.col)) continue; // 放寬到同號或差2號
      const w = 1 / (1 + dRank * 1.4 + bestDN * 2.2);
      colAcc += Number(best.col) * w;
      if (isFinite(best.cx) && isFinite(best.cy)) {
        xAcc += Number(best.cx) * w;
        yAcc += Number(best.cy) * w;
        hasXY = true;
      }
      wSum += w;
    }
    if (wSum <= 0) return null;
    return {
      col: colAcc / wSum,
      cx: hasXY ? xAcc / wSum : null,
      cy: hasXY ? yAcc / wSum : null,
    };
  },

  _estimateByGlobalNumTrend(resolved, targetNum) {
    const t = Number(targetNum);
    if (!Array.isArray(resolved) || !resolved.length || !isFinite(t)) return null;
    let wSum = 0;
    let colAcc = 0;
    let xAcc = 0;
    let yAcc = 0;
    let hasXY = false;
    for (const r of resolved) {
      const n = Number(r?.p?.num);
      const c = Number(r?.col);
      if (!isFinite(n) || !isFinite(c)) continue;
      const dn = Math.abs(n - t);
      if (dn > 6) continue;
      const w = 1 / (1 + dn * 1.4);
      wSum += w;
      colAcc += c * w;
      if (isFinite(r?.cx) && isFinite(r?.cy)) {
        xAcc += Number(r.cx) * w;
        yAcc += Number(r.cy) * w;
        hasXY = true;
      }
    }
    if (wSum <= 0) return null;
    return {
      col: colAcc / wSum,
      cx: hasXY ? xAcc / wSum : null,
      cy: hasXY ? yAcc / wSum : null,
    };
  },

  _estimateColByPrefixAdjustedGlobalModel(resolved, qPrefix, targetNum) {
    const arr = (resolved || [])
      .map((r) => ({
        prefix: String(r?.p?.prefix || "").toUpperCase(),
        num: Number(r?.p?.num),
        col: Number(r?.col),
      }))
      .filter((x) => x.prefix && isFinite(x.num) && isFinite(x.col));
    if (arr.length < 12) return null;

    // 全域線性：col = a*num + b
    const n = arr.length;
    let sumN = 0;
    let sumC = 0;
    let sumNN = 0;
    let sumNC = 0;
    for (const x of arr) {
      sumN += x.num;
      sumC += x.col;
      sumNN += x.num * x.num;
      sumNC += x.num * x.col;
    }
    const den = n * sumNN - sumN * sumN;
    if (Math.abs(den) < 1e-6) return null;
    const a = (n * sumNC - sumN * sumC) / den;
    const b = (sumC - a * sumN) / n;
    if (!isFinite(a) || !isFinite(b)) return null;

    const byPrefix = new Map();
    for (const x of arr) {
      const pred = a * x.num + b;
      const d = x.col - pred;
      const list = byPrefix.get(x.prefix) || [];
      list.push(d);
      byPrefix.set(x.prefix, list);
    }
    const median = (vals) => {
      const v = (vals || []).filter((x) => isFinite(x)).slice().sort((x, y) => x - y);
      if (!v.length) return null;
      const m = Math.floor(v.length / 2);
      return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2;
    };
    const offByPrefix = new Map();
    for (const [k, vals] of byPrefix.entries()) {
      const m = median(vals);
      if (isFinite(m)) offByPrefix.set(k, Number(m));
    }
    if (!offByPrefix.size) return null;

    const qp = String(qPrefix || "").toUpperCase();
    const qRank = this._letterRank(qp);
    let off = offByPrefix.get(qp);
    if (!isFinite(off)) {
      // 以鄰近列殘差做加權估計（修正 W 行同列錯位）
      let wSum = 0;
      let acc = 0;
      for (const [pk, pv] of offByPrefix.entries()) {
        const pr = this._letterRank(pk);
        if (pr < 0 || qRank < 0) continue;
        const d = Math.abs(pr - qRank);
        if (d > 5) continue;
        const w = 1 / (1 + d * 1.8);
        wSum += w;
        acc += Number(pv) * w;
      }
      if (wSum > 0) off = acc / wSum;
    }
    if (!isFinite(off)) off = 0;
    const col = a * Number(targetNum) + b + off;
    return isFinite(col) ? { col } : null;
  },

  _estimateTargetRowByParseAnchors(prefix) {
    const p = String(prefix || "").toUpperCase();
    if (!/^[A-Z]$/.test(p)) return null;
    const bands = this.data.parseDebug?.rowLetterAnchors || [];
    if (!Array.isArray(bands) || !bands.length) return null;
    let targetBand = null;
    for (const b of bands) {
      const letters = Array.isArray(b?.letters) ? b.letters.map((x) => String(x || "").toUpperCase()) : [];
      if (letters.includes(p)) {
        targetBand = b;
        break;
      }
    }
    if (!targetBand || !isFinite(targetBand?.cy)) return null;
    const cells = this.data.boothCells || this.data.boothRegions || [];
    if (!Array.isArray(cells) || !cells.length) return null;
    const cy = Number(targetBand.cy);
    const withDist = cells
      .map((c) => {
        const cc = c?.center;
        if (!cc || !isFinite(cc.y) || !isFinite(c?.row)) return null;
        return { row: Number(c.row), dy: Math.abs(Number(cc.y) - cy) };
      })
      .filter(Boolean)
      .sort((a, b) => a.dy - b.dy);
    if (!withDist.length) return null;
    const top = withDist.slice(0, Math.min(30, withDist.length));
    const rows = top.map((x) => x.row).sort((a, b) => a - b);
    return rows[Math.floor(rows.length / 2)];
  },

  _isLowTrustExactPrefixHit(entry, queryParts) {
    if (!entry || !queryParts?.prefix) return false;
    const ev = String(entry?.evidence || "").toLowerCase();
    const weakRows = this._anchorCoverage?.weakRows || [];
    const isWeakPrefix = weakRows.includes(queryParts.prefix);
    const noCell = !entry?.cellId;
    const noGridCoord = !isFinite(entry?.row) || !isFinite(entry?.col);
    if (isWeakPrefix && (noCell || noGridCoord)) return true;
    if (ev.includes("ocr_booth") && (noCell || noGridCoord)) return true;
    const estRow = this._estimateTargetRowByParseAnchors(queryParts.prefix);
    if (isFinite(estRow) && isFinite(entry?.row) && Math.abs(Number(entry.row) - Number(estRow)) >= 3) return true;
    if (isFinite(estRow) && !isFinite(entry?.row)) return true;
    return false;
  },

  _shouldExpectPrefixNumber(queryParts, prefixGroups) {
    const p = queryParts;
    if (!p?.prefix) return false;
    const inRowMap = Array.isArray(this.data.rowNumberMap?.[p.prefix])
      ? this.data.rowNumberMap[p.prefix].some((x) => Number(x) === Number(p.num))
      : false;
    if (inRowMap) return true;
    const bands = this.data.parseDebug?.rowLetterAnchors || [];
    const hasPrefixAnchor = Array.isArray(bands)
      ? bands.some((b) => Array.isArray(b?.letters) && b.letters.map((x) => String(x || "").toUpperCase()).includes(p.prefix))
      : false;
    if (hasPrefixAnchor) return true;
    const same = (prefixGroups?.get(p.prefix) || []).map((x) => Number(x?.p?.num)).filter((n) => isFinite(n));
    if (same.length >= 2) {
      const minN = Math.min(...same);
      const maxN = Math.max(...same);
      if (Number(p.num) >= minN - 2 && Number(p.num) <= maxN + 2) return true;
    }
    return false;
  },

  _estimateTargetRowByPrefix(prefixRows, qPrefix) {
    const qRank = this._letterRank(qPrefix);
    if (qRank < 0) return null;
    const pts = [];
    for (const [prefix, rows] of prefixRows.entries()) {
      const pr = this._letterRank(prefix);
      if (pr < 0) continue;
      const arr = (rows || []).filter((v) => isFinite(v)).slice().sort((a, b) => a - b);
      if (!arr.length) continue;
      const med = arr[Math.floor(arr.length / 2)];
      if (!isFinite(med)) continue;
      pts.push({ rank: pr, row: Number(med) });
    }
    if (!pts.length) return null;
    if (pts.length === 1) return Math.round(pts[0].row);
    const nearest = pts.slice().sort((a, b) => Math.abs(a.rank - qRank) - Math.abs(b.rank - qRank));
    if (nearest.length >= 2) {
      const p1 = nearest[0];
      const p2 = nearest[1];
      if (p1.rank !== p2.rank) {
        const t = (qRank - p1.rank) / (p2.rank - p1.rank);
        return Math.round(p1.row + (p2.row - p1.row) * t);
      }
    }
    // 退路：全部已知前綴做線性擬合 row = a*rank + b
    const n = pts.length;
    let sumX = 0;
    let sumY = 0;
    let sumXX = 0;
    let sumXY = 0;
    for (const p of pts) {
      sumX += p.rank;
      sumY += p.row;
      sumXX += p.rank * p.rank;
      sumXY += p.rank * p.row;
    }
    const den = n * sumXX - sumX * sumX;
    if (Math.abs(den) < 1e-6) return null;
    const a = (n * sumXY - sumX * sumY) / den;
    const b = (sumY - a * sumX) / n;
    const pred = a * qRank + b;
    return isFinite(pred) ? Math.round(pred) : null;
  },

  _tryInferRuntimeBooth(inputId) {
    return this._tryInferRuntimeBoothWithOptions(inputId, { expectExists: false });
  },

  _tryInferRuntimeBoothWithOptions(inputId, { expectExists = false } = {}) {
    const q = this._parseBoothParts(inputId);
    if (!q || !q.prefix) return -1;
    const entries = Array.isArray(this.data.boothIndex) ? this.data.boothIndex : [];
    const resolved = entries
      .map((e) => {
        const p = this._parseBoothParts(e?.idCanonical);
        if (!p) return null;
        return { e, p, row: Number(e?.row), col: Number(e?.col), cx: Number(e?.center?.x), cy: Number(e?.center?.y) };
      })
      .filter((x) => x && x.e?.status !== "unresolved" && isFinite(x.col));
    if (!resolved.length) return -1;

    const prefixGroups = new Map();
    const prefixRows = new Map();
    for (const r of resolved) {
      const arr = prefixGroups.get(r.p.prefix) || [];
      arr.push(r);
      prefixGroups.set(r.p.prefix, arr);
      if (isFinite(r.row)) {
        const rows = prefixRows.get(r.p.prefix) || [];
        rows.push(Number(r.row));
        prefixRows.set(r.p.prefix, rows);
      }
    }
    const targetRowsRaw = prefixRows.get(q.prefix) || [];
    const parseAnchorRow = this._estimateTargetRowByParseAnchors(q.prefix);
    let targetRow =
      targetRowsRaw.length > 0
        ? Math.round(targetRowsRaw.sort((a, b) => a - b)[Math.floor(targetRowsRaw.length / 2)])
        : parseAnchorRow ?? this._estimateTargetRowByPrefix(prefixRows, q.prefix);
    if (isFinite(parseAnchorRow) && isFinite(targetRow) && Math.abs(Number(parseAnchorRow) - Number(targetRow)) >= 3) {
      targetRow = Number(parseAnchorRow);
    }

    let targetCol = null;
    let targetX = null;
    let targetY = null;

    const samePrefixAnchors = (prefixGroups.get(q.prefix) || []).sort((a, b) => a.p.num - b.p.num);
    // 優先使用「夾住目標號碼」的左右近鄰錨點；若沒有，後續仍可退回較寬鬆估計
    let leftAnchor = null;
    let rightAnchor = null;
    for (const a of samePrefixAnchors) {
      if (Number(a.p?.num) <= Number(q.num)) leftAnchor = a;
      if (Number(a.p?.num) > Number(q.num)) {
        rightAnchor = a;
        break;
      }
    }
    const hasTightPair = !!(leftAnchor && rightAnchor);
    let sameEst = null;
    if (hasTightPair) {
      const localGap = Number(rightAnchor.p?.num) - Number(leftAnchor.p?.num);
      if (localGap >= 1 && localGap <= 10) {
        if (Math.abs(Number(q.num) - Number(leftAnchor.p?.num)) <= 7 && Math.abs(Number(rightAnchor.p?.num) - Number(q.num)) <= 7) {
          sameEst = this._estimateColByAnchors(samePrefixAnchors, q.num);
        }
      }
    }
    if (!sameEst && samePrefixAnchors.length >= 2) {
      // 寬鬆退路：用最近兩個同列錨點做估計，避免全部找不到
      const nearest = samePrefixAnchors
        .slice()
        .sort((a, b) => Math.abs(Number(a.p?.num) - Number(q.num)) - Math.abs(Number(b.p?.num) - Number(q.num)))
        .slice(0, 2)
        .sort((a, b) => Number(a.p?.num) - Number(b.p?.num));
      if (nearest.length === 2) {
        const n1 = Number(nearest[0].p?.num);
        const n2 = Number(nearest[1].p?.num);
        if (n2 > n1) {
          const t = (Number(q.num) - n1) / Math.max(1, n2 - n1);
          sameEst = {
            col: Number(nearest[0].col) + (Number(nearest[1].col) - Number(nearest[0].col)) * t,
            cx: Number(nearest[0].cx) + (Number(nearest[1].cx) - Number(nearest[0].cx)) * t,
            cy: Number(nearest[0].cy) + (Number(nearest[1].cy) - Number(nearest[0].cy)) * t,
          };
        }
      }
    }
    const neighborNumEst = this._estimateByNeighborRowsSameNum(prefixGroups, q.prefix, q.num);
    const prefixLinearEst = this._estimateColByPrefixLinearAnchors(samePrefixAnchors, q.num);
    const globalNumEst = this._estimateByGlobalNumTrend(resolved, q.num);
    const prefixAdjGlobalEst = this._estimateColByPrefixAdjustedGlobalModel(resolved, q.prefix, q.num);
    if (sameEst && neighborNumEst) {
      // 同列 + 鄰列同號融合，減少單列偏移
      targetCol = sameEst.col * 0.65 + neighborNumEst.col * 0.35;
      targetX = isFinite(sameEst.cx) && isFinite(neighborNumEst.cx) ? sameEst.cx * 0.65 + neighborNumEst.cx * 0.35 : sameEst.cx ?? neighborNumEst.cx;
      targetY = isFinite(sameEst.cy) && isFinite(neighborNumEst.cy) ? sameEst.cy * 0.65 + neighborNumEst.cy * 0.35 : sameEst.cy ?? neighborNumEst.cy;
    } else if (sameEst) {
      targetCol = sameEst.col;
      targetX = sameEst.cx;
      targetY = sameEst.cy;
    } else if (neighborNumEst) {
      targetCol = neighborNumEst.col;
      targetX = neighborNumEst.cx;
      targetY = neighborNumEst.cy;
    } else if (prefixLinearEst) {
      targetCol = prefixLinearEst.col;
    } else if (prefixAdjGlobalEst) {
      targetCol = prefixAdjGlobalEst.col;
    } else if (globalNumEst) {
      targetCol = globalNumEst.col;
      targetX = globalNumEst.cx;
      targetY = globalNumEst.cy;
    } else {
      // 同列錨點不足時，回退用鄰列（A-K）估計目標欄位
      const qRank = this._letterRank(q.prefix);
      let wSum = 0;
      let colAcc = 0;
      let xAcc = 0;
      let yAcc = 0;
      let hasXY = false;
      for (const [prefix, anchors] of prefixGroups.entries()) {
        const est = this._estimateColByAnchors(anchors, q.num);
        if (!est) continue;
        const pr = this._letterRank(prefix);
        const dRank = qRank >= 0 && pr >= 0 ? Math.abs(pr - qRank) : 3;
        if (dRank > 3) continue; // 只信任鄰近列
        let dRow = 1;
        const rows = prefixRows.get(prefix) || [];
        if (rows.length && isFinite(targetRow)) {
          const med = rows.sort((a, b) => a - b)[Math.floor(rows.length / 2)];
          dRow = Math.max(1, Math.abs(Number(med) - Number(targetRow)));
        }
        const w = 1 / (1 + dRank * 1.2 + dRow * 0.15);
        colAcc += est.col * w;
        if (isFinite(est.cx) && isFinite(est.cy)) {
          xAcc += est.cx * w;
          yAcc += est.cy * w;
          hasXY = true;
        }
        wSum += w;
      }
      if (wSum > 0) {
        targetCol = colAcc / wSum;
        if (hasXY) {
          targetX = xAcc / wSum;
          targetY = yAcc / wSum;
        }
      }
    }
    if (!isFinite(targetCol)) return -1;
    // 缺少該 prefix 任何錨點且沒有可用列位估計時，避免把多個查詢吸到同一中心格
    if (!isFinite(targetRow) && samePrefixAnchors.length === 0 && !neighborNumEst && !prefixLinearEst && !expectExists) return -1;

    const unresolved = entries.filter((e) => e?.status === "unresolved" && isFinite(e?.col) && e?.center);
    if (!unresolved.length) return -1;
    const occupiedCellIds = new Set(
      entries
        .filter((e) => e?.status !== "unresolved")
        .map((e) => String(e?.cellId || ""))
        .filter(Boolean)
    );
    const unresolvedPool = unresolved.filter((u) => !occupiedCellIds.has(String(u?.cellId || "")));
    const rowTol = isFinite(parseAnchorRow) ? 1 : expectExists ? 2 : 1;
    const unresolvedCandidates = isFinite(targetRow)
      ? unresolvedPool.filter((u) => Math.abs(Number(u?.row) - Number(targetRow)) <= rowTol)
      : unresolvedPool;
    // 有 targetRow 時不要回退到全域池，避免錯列吸附
    const candidatePool = unresolvedCandidates.length ? unresolvedCandidates : !isFinite(targetRow) && expectExists ? unresolvedPool : [];
    if (!candidatePool.length) return -1;
    let best = null;
    let bestScore = Infinity;
    for (const u of candidatePool) {
      const dCol = Math.abs(Number(u.col) - targetCol);
      const dx = isFinite(targetX) ? Number(u.center?.x || 0) - targetX : 0;
      const dy = isFinite(targetY) ? Number(u.center?.y || 0) - targetY : 0;
      const d = isFinite(targetX) && isFinite(targetY) ? Math.sqrt(dx * dx + dy * dy) : 0;
      const dRow = isFinite(targetRow) ? Math.abs(Number(u?.row) - Number(targetRow)) : 0;
      const score = dCol * 28 + dRow * 42 + d * 0.2;
      if (score < bestScore) {
        bestScore = score;
        best = u;
      }
    }
    if (!best) return -1;
    // 推斷結果品質檢查：過差則拒絕推斷，避免把展位導到錯誤固定位置
    const bestRowDelta = isFinite(targetRow) ? Math.abs(Number(best?.row) - Number(targetRow)) : 0;
    const bestColDelta = Math.abs(Number(best?.col) - Number(targetCol || 0));
    if (bestScore > (expectExists ? 380 : 320) || bestRowDelta > (expectExists ? 2 : 1) || bestColDelta > (expectExists ? 4.2 : 3.6)) return -1;
    const inferredId = `${q.prefix}${q.rawNum}`;
    const newEntry = {
      ...best,
      idCanonical: inferredId,
      aliases: [inferredId, inferredId.toLowerCase(), `${q.prefix}${q.num}`],
      status: "inferred",
      confidence: 0.45,
      evidence: "runtime_interp",
    };
    const nextIndex = [...entries.filter((e) => this._normIdKey(e?.idCanonical) !== this._normIdKey(inferredId)), newEntry];
    const nextIds = nextIndex.filter((x) => x.status !== "unresolved").map((x) => x.idCanonical);
    this.setData({
      boothIndex: nextIndex,
      boothIds: nextIds,
    });
    this._syncBoothLookup(nextIndex, nextIds);
    const idx = this._findBoothIndex(inferredId);
    if (idx >= 0) wx.showToast({ title: "已用鄰近規則推斷定位", icon: "none" });
    return idx;
  },

  _findBoothIndexWithRoute(id, { prefixLock } = {}) {
    const k = this._normIdKey(id);
    if (!k) return { idx: -1, route: "fallback", idCanonical: null };
    const targetPrefix = prefixLock ? String(prefixLock).toUpperCase() : "";
    const entries = this._boothUiEntries || [];
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      const ep = this._parseBoothParts(e?.idCanonical);
      if (targetPrefix && ep?.prefix !== targetPrefix) continue;
      if (this._normIdKey(e?.idCanonical) === k) {
        return { idx: i, route: "exact", idCanonical: e?.idCanonical || null };
      }
    }
    for (let i = 0; i < entries.length; i++) {
      const e = entries[i];
      const ep = this._parseBoothParts(e?.idCanonical);
      if (targetPrefix && ep?.prefix !== targetPrefix) continue;
      const aliases = Array.from(new Set([e?.idCanonical, ...(e?.aliases || [])]));
      const hit = aliases.some((a) => this._normIdKey(a) === k);
      if (hit) return { idx: i, route: "alias", idCanonical: e?.idCanonical || null };
    }
    return { idx: -1, route: "fallback", idCanonical: null };
  },

  _findBoothIndex(id) {
    return this._findBoothIndexWithRoute(id).idx;
  },

  _findCellByTapView(ptView, tf) {
    // 用「正向映射」在螢幕座標命中 boothCells，避免 movable-view 反算造成上下顛倒
    const x = Number(ptView?.x);
    const y = Number(ptView?.y);
    if (!isFinite(x) || !isFinite(y) || !tf) return null;
    const cells = this.data.boothCells || this.data.boothRegions || [];
    if (!cells.length) return null;
    let best = null;
    let bestArea = Infinity;
    for (const c of cells) {
      const bb = c?.bbox;
      if (!bb) continue;
      const vb = this._mapImgBboxToViewAfterMovable(bb, tf);
      if (x >= vb.x1 && x <= vb.x2 && y >= vb.y1 && y <= vb.y2) {
        const area = vb.w * vb.h;
        if (area < bestArea) {
          bestArea = area;
          best = {
            key: c?.key || null,
            labelId: c?.labelId || c?.id || null,
            bbox: bb,
            areaPx2: area,
          };
        }
      }
    }
    return best;
  },

  _nearestCellByTapView(ptView, tf) {
    const x = Number(ptView?.x);
    const y = Number(ptView?.y);
    if (!isFinite(x) || !isFinite(y) || !tf) return null;
    const cells = this.data.boothCells || this.data.boothRegions || [];
    if (!cells.length) return null;
    let best = null;
    let bestD2 = Infinity;
    for (const c of cells) {
      const bb = c?.bbox;
      const cc = c?.center;
      if (!bb && !cc) continue;
      const cxImg = cc?.x ?? (bb.x1 + bb.x2) / 2;
      const cyImg = cc?.y ?? (bb.y1 + bb.y2) / 2;
      const pv = this._applyMovableTf(this._mapImgToView({ x: cxImg, y: cyImg }, tf));
      const dx = pv.x - x;
      const dy = pv.y - y;
      const d2 = dx * dx + dy * dy;
      if (d2 < bestD2) {
        bestD2 = d2;
        best = {
          key: c?.key || null,
          labelId: c?.labelId || c?.id || null,
          bbox: bb || null,
          distPx: Math.sqrt(d2),
        };
      }
    }
    return best;
  },

  _findBoothByPoint(ptImg) {
    const x = Number(ptImg?.x);
    const y = Number(ptImg?.y);
    if (!isFinite(x) || !isFinite(y)) return -1;
    const booths = this.data.booths || [];

    // 先找是否落在 bbox 內（最準）
    let bestIdx = -1;
    let bestArea = Infinity;
    for (let i = 0; i < booths.length; i++) {
      const bb = booths[i]?.bbox;
      if (!bb) continue;
      if (x >= bb.x1 && x <= bb.x2 && y >= bb.y1 && y <= bb.y2) {
        const area = Math.max(1, (bb.x2 - bb.x1) * (bb.y2 - bb.y1));
        if (area < bestArea) {
          bestArea = area;
          bestIdx = i;
        }
      }
    }
    if (bestIdx >= 0) return bestIdx;

    // 再找最近中心點（避免點在空白但接近攤位）
    let nearIdx = -1;
    let bestD2 = Infinity;
    for (let i = 0; i < booths.length; i++) {
      const c = booths[i]?.center;
      if (!c) continue;
      const dx = Number(c.x) - x;
      const dy = Number(c.y) - y;
      const d2 = dx * dx + dy * dy;
      if (d2 < bestD2) {
        bestD2 = d2;
        nearIdx = i;
      }
    }
    return bestD2 <= 120 * 120 ? nearIdx : -1;
  },

  _getAspectFitTf() {
    const dims = this._getImageDimsForMapping();
    const imgW = Number(dims.width || 0);
    const imgH = Number(dims.height || 0);
    const vw = Number(this._cssW || 0);
    const vh = Number(this._cssH || 0);
    if (!(imgW > 0 && imgH > 0 && vw > 0 && vh > 0)) return null;
    const scale = Math.min(vw / imgW, vh / imgH);
    const offsetX = (vw - imgW * scale) / 2;
    const offsetY = (vh - imgH * scale) / 2;
    return { imgW, imgH, vw, vh, scale, offsetX, offsetY };
  },

  _getImageDimsForMapping() {
    const cand = [];
    const lw = Number(this._loadedImgW || 0);
    const lh = Number(this._loadedImgH || 0);
    if (lw > 0 && lh > 0) cand.push({ width: lw, height: lh, source: "imgLoad" });
    const cw = Number(this.data.coordSpace?.width || 0);
    const ch = Number(this.data.coordSpace?.height || 0);
    if (cw > 0 && ch > 0) cand.push({ width: cw, height: ch, source: "coordSpace" });
    const iw = Number(this.data.imageMeta?.width || 0);
    const ih = Number(this.data.imageMeta?.height || 0);
    if (iw > 0 && ih > 0) cand.push({ width: iw, height: ih, source: "imageMeta" });
    if (!cand.length) return { width: 0, height: 0, source: "none" };

    const range = this.data.parseDebug?.ocrRange;
    const overflowScore = (r, w, h) => {
      if (!r || !(w > 0 && h > 0)) return Infinity;
      const left = Math.max(0, 0 - Number(r.minX || 0));
      const top = Math.max(0, 0 - Number(r.minY || 0));
      const right = Math.max(0, Number(r.maxX || 0) - w);
      const bottom = Math.max(0, Number(r.maxY || 0) - h);
      return left + top + right + bottom;
    };
    cand.sort((a, b) => {
      const oa = overflowScore(range, a.width, a.height);
      const ob = overflowScore(range, b.width, b.height);
      if (oa !== ob) return oa - ob;
      // 平手時偏好雲端座標空間
      const pa = a.source === "coordSpace" ? 0 : a.source === "imgLoad" ? 1 : 2;
      const pb = b.source === "coordSpace" ? 0 : b.source === "imgLoad" ? 1 : 2;
      return pa - pb;
    });
    return cand[0];
  },

  _applyMovableTf(pt) {
    const s = Number(this._mvScale || 1) || 1;
    const x = Number(this._mvX || 0);
    const y = Number(this._mvY || 0);
    const px = pt.x * s + x;
    const py = pt.y * s + y;
    return { x: px, y: py };
  },

  _invertMovableTf(pt) {
    const s = Number(this._mvScale || 1) || 1;
    const x = Number(this._mvX || 0);
    const y = Number(this._mvY || 0);
    // forward: p*s + (x,y)
    // inverse: (p-(x,y))/s
    const px = (pt.x - x) / s;
    const py = (pt.y - y) / s;
    return { x: px, y: py };
  },

  _mapImgToView(ptImg, tf) {
    return { x: tf.offsetX + ptImg.x * tf.scale, y: tf.offsetY + ptImg.y * tf.scale };
  },

  _mapViewToImg(ptView, tf) {
    // ptView: in movable-area local coords (after movable transform)
    const p = this._invertMovableTf(ptView);
    return { x: (p.x - tf.offsetX) / tf.scale, y: (p.y - tf.offsetY) / tf.scale };
  },

  _mapImgBboxToViewAfterMovable(bb, tf) {
    // 將「影像座標 bbox」映射到 movable-area 的螢幕座標（包含 movable-view 平移/縮放）
    const p1 = this._applyMovableTf(this._mapImgToView({ x: bb.x1, y: bb.y1 }, tf));
    const p2 = this._applyMovableTf(this._mapImgToView({ x: bb.x2, y: bb.y2 }, tf));
    const x1 = Math.min(p1.x, p2.x);
    const y1 = Math.min(p1.y, p2.y);
    const x2 = Math.max(p1.x, p2.x);
    const y2 = Math.max(p1.y, p2.y);
    return { x1, y1, x2, y2, w: Math.max(1, x2 - x1), h: Math.max(1, y2 - y1) };
  },

  _pickBoothByTap(ptView) {
    const tf = this._getAspectFitTf();
    if (!tf) return { idx: -1, reason: "no_image_meta" };
    const booths = this.data.booths || [];
    const vw = Number(this._cssW || 0);
    const vh = Number(this._cssH || 0);
    const mvScale = Number(this._mvScale || 1) || 1;
    const base = Math.max(1, Number(this.data.gridCellPx || 16)) * tf.scale * mvScale;
    // 點選通常點在攤位格子，而非文字框；縮放很小時 base 會很小，pad 需要有較大的下限
    const padPx = Math.max(28, Math.min(140, base * 10.0));

    const mapBboxToView = (bb) => {
      return this._mapImgBboxToViewAfterMovable(bb, tf);
    };

    // 先做 bbox 命中（兩階段：先排除「過大的框」避免列標籤/大區塊吃掉點擊）
    const maxAreaStrict = Math.max(3200, vw * vh * 0.08);
    const tryHit = (strict) => {
      let hitIdx = -1;
      let bestArea = Infinity;
      for (let i = 0; i < booths.length; i++) {
        const bb = booths[i]?.bbox;
        if (!bb) continue;
        const vb = mapBboxToView(bb);
        const area = vb.w * vb.h;
        if (strict) {
          if (area > maxAreaStrict) continue;
          if (vb.w > vw * 0.85) continue;
          if (vb.h > vh * 0.6) continue;
        }
        if (ptView.x >= vb.x1 - padPx && ptView.x <= vb.x2 + padPx && ptView.y >= vb.y1 - padPx && ptView.y <= vb.y2 + padPx) {
          if (area < bestArea) {
            bestArea = area;
            hitIdx = i;
          }
        }
      }
      return hitIdx >= 0 ? hitIdx : -1;
    };

    const hitStrict = tryHit(true);
    if (hitStrict >= 0) return { idx: hitStrict, reason: "bbox_hit_strict", distPx: 0, thresholdPx: null };
    const hitLoose = tryHit(false);
    if (hitLoose >= 0) return { idx: hitLoose, reason: "bbox_hit_loose", distPx: 0, thresholdPx: null };

    // 再找最近中心點（螢幕座標距離）
    let nearIdx = -1;
    let bestD2 = Infinity;
    for (let i = 0; i < booths.length; i++) {
      const b = booths[i];
      const c = b?.center;
      const bb = b?.bbox;
      if (!c && !bb) continue;
      const cxImg = c?.x ?? (bb.x1 + bb.x2) / 2;
      const cyImg = c?.y ?? (bb.y1 + bb.y2) / 2;
      const pv = this._applyMovableTf(this._mapImgToView({ x: cxImg, y: cyImg }, tf));
      const dx = pv.x - ptView.x;
      const dy = pv.y - ptView.y;
      const d2 = dx * dx + dy * dy;
      if (d2 < bestD2) {
        bestD2 = d2;
        nearIdx = i;
      }
    }
    // 閾值：以「gridCellPx 映射到螢幕的大小」動態調整，縮放越大可命中半徑也越大
    // 縮放很小（整張圖縮到很小）時，仍需較大下限，否則永遠 too_far
    const thresholdPx = Math.max(90, Math.min(280, base * 12.0));
    if (bestD2 <= thresholdPx * thresholdPx) {
      return { idx: nearIdx, reason: "nearest_center", distPx: Math.sqrt(bestD2), thresholdPx };
    }
    return { idx: -1, reason: "too_far", distPx: Math.sqrt(bestD2), thresholdPx };
  },

  _refreshCanPlan() {
    const ok = this.data.boothIds.length >= 2 && this.data.startIndex >= 0 && this.data.endIndex >= 0 && this.data.startIndex !== this.data.endIndex;
    this.setData({ canPlan: ok });
  },

  async _measureArea() {
    const query = wx.createSelectorQuery().in(this);
    const rect = await new Promise((resolve) => {
      query.select("#mapArea").boundingClientRect().exec((res) => resolve(res?.[0]));
    });
    if (rect) this._areaRect = rect;
  },

  async _initCanvas() {
    const query = wx.createSelectorQuery().in(this);
    const canvasNode = await new Promise((resolve) => {
      query.select("#overlay").fields({ node: true, size: true }).exec((res) => resolve(res?.[0]));
    });
    if (!canvasNode?.node) return;

    this._canvas = canvasNode.node;
    this._ctx = this._canvas.getContext("2d");
    this._cssW = canvasNode.width;
    this._cssH = canvasNode.height;
    this._mvX = 0;
    this._mvY = 0;
    this._mvScale = Number(this.data.scale || 1);
    await this._measureArea();

    const dpr = wx.getSystemInfoSync().pixelRatio || 1;
    this._canvas.width = canvasNode.width * dpr;
    this._canvas.height = canvasNode.height * dpr;
    this._ctx.scale(dpr, dpr);
  },

  _scheduleRedraw() {
    if (this._rafPending) return;
    this._rafPending = true;
    const now = Date.now();
    const last = Number(this._lastInteractAt || 0);
    const interacting = now - last < 180;
    const delay = interacting ? 33 : 16;
    setTimeout(() => {
      this._rafPending = false;
      this._redraw();
    }, delay);
  },

  _redraw() {
    if (!this._ctx || !this._canvas) return;
    const { path, showOcr, ocrItems, showDebug } = this.data;
    const ctx = this._ctx;
    const now = Date.now();
    const interacting = now - Number(this._lastInteractAt || 0) < 180;
    const currentScale = Number(this._mvScale || 1) || 1;
    const heavyZoom = currentScale >= 2.8;
    ctx.clearRect(0, 0, this._cssW || 0, this._cssH || 0);
    const common = {
      viewWidth: this._cssW,
      viewHeight: this._cssH,
      imageWidth: this._getImageDimsForMapping().width,
      imageHeight: this._getImageDimsForMapping().height,
    };

    // 外置 overlay 需手動同步 movable + 旋轉（順序：先 movable 再 rotation）
    const s = Number(this._mvScale || 1);
    const x = Number(this._mvX || 0);
    const y = Number(this._mvY || 0);
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(s, s);
    this._applyMapRotation(ctx);

    // 在與 OCR 相同的座標系下，畫出最後一次命中的 region bbox（若有），用來驗證 region 是否對齊攤位格
    if (showDebug && this._lastTapDebug?.regionHit?.bbox) {
      const tf = this._getAspectFitTf();
      if (tf) {
        const bb = this._lastTapDebug.regionHit.bbox;
        const p1 = this._mapImgToView({ x: bb.x1, y: bb.y1 }, tf);
        const p2 = this._mapImgToView({ x: bb.x2, y: bb.y2 }, tf);
        const rx1 = Math.min(p1.x, p2.x);
        const ry1 = Math.min(p1.y, p2.y);
        const rw = Math.max(1, Math.abs(p2.x - p1.x));
        const rh = Math.max(1, Math.abs(p2.y - p1.y));
        ctx.save();
        ctx.strokeStyle = "rgba(255, 210, 0, 0.95)";
        ctx.lineWidth = 2;
        ctx.strokeRect(rx1, ry1, rw, rh);
        ctx.restore();
      }
    }

    // 命中 cell 後固定高亮（即使 labelId 為空）
    if (this.data.selectedCell?.bbox) {
      const tf = this._getAspectFitTf();
      if (tf) {
        const bb = this.data.selectedCell.bbox;
        const p1 = this._mapImgToView({ x: bb.x1, y: bb.y1 }, tf);
        const p2 = this._mapImgToView({ x: bb.x2, y: bb.y2 }, tf);
        const rx1 = Math.min(p1.x, p2.x);
        const ry1 = Math.min(p1.y, p2.y);
        const rw = Math.max(1, Math.abs(p2.x - p1.x));
        const rh = Math.max(1, Math.abs(p2.y - p1.y));
        ctx.save();
        ctx.strokeStyle = "rgba(0, 255, 220, 0.95)";
        ctx.lineWidth = 2;
        ctx.fillStyle = "rgba(0, 255, 220, 0.14)";
        ctx.fillRect(rx1, ry1, rw, rh);
        ctx.strokeRect(rx1, ry1, rw, rh);
        ctx.restore();
      }
    }

    if (showOcr && ocrItems?.length) {
      const debugOcr = !!this.data.showDebug;
      const lightMode = interacting || heavyZoom;
      drawOcrItems(ctx, {
        items: ocrItems,
        ...common,
        // 避免畫太多造成卡頓：只畫高信心、短字串（可依需求調整）
        // Debug 模式下放寬，避免誤判成「附近沒有任何文字框」
        minScore: lightMode ? (debugOcr ? 0.45 : 0.9) : debugOcr ? 0.3 : 0.85,
        maxTextLen: lightMode ? (debugOcr ? 12 : 8) : debugOcr ? 24 : 10,
        maxItems: lightMode ? (debugOcr ? 420 : 260) : debugOcr ? 2500 : 800,
        showText: !lightMode,
      });
    }

    if (path?.length) {
      drawPath(ctx, {
        pathCells: path,
        gridCellPx: this.data.gridCellPx,
        ...common,
      });
    }
    ctx.restore();

    // 起點/終點 marker：位置跟著地圖，但 marker 本身不旋轉（文字保持正向）
    const tfForMarker = this._getAspectFitTf();
    const startBooth = this._boothUiEntries?.[this.data.startIndex] || null;
    const endBooth = this._boothUiEntries?.[this.data.endIndex] || null;
    const centerOf = (b) => {
      const bb = b?.bbox;
      const c = b?.center;
      if (c) return { x: Number(c.x), y: Number(c.y) };
      if (bb) return { x: (Number(bb.x1) + Number(bb.x2)) / 2, y: (Number(bb.y1) + Number(bb.y2)) / 2 };
      return null;
    };
    if (tfForMarker) {
      const sp = centerOf(startBooth);
      const ep = centerOf(endBooth);
      this._drawMarkerOnScreen(ctx, sp ? this._mapImgToScreen(sp, tfForMarker) : null, "rgba(0, 200, 255, 0.95)", "起點");
      this._drawMarkerOnScreen(ctx, ep ? this._mapImgToScreen(ep, tfForMarker) : null, "rgba(255, 80, 80, 0.95)", "目的");
    }

    // Debug UI 不應跟著地圖變換，固定畫在螢幕座標
    if (showDebug) {
      const tf = this._getAspectFitTf();
      const mapDims = this._getImageDimsForMapping();
      ctx.save();
      ctx.fillStyle = "rgba(0,0,0,0.55)";
      ctx.fillRect(10, 10, 420, 170);
      ctx.fillStyle = "rgba(255, 0, 80, 0.98)";
      ctx.font = "12px monospace";
      const lines = [];
      lines.push(`mvScale=${Number(this._mvScale || 1).toFixed(3)} mvX=${Number(this._mvX || 0).toFixed(1)} mvY=${Number(this._mvY || 0).toFixed(1)}`);
      lines.push(`renderMode=${interacting || heavyZoom ? "light" : "full"} zoom=${currentScale.toFixed(2)}`);
      lines.push(`mapRot=${Number(this.data.mapRotationDeg || 0)} front=${this.data.frontDirOptions?.[this.data.frontDirIndex] || "上方是正前方"}`);
      lines.push(`imgMeta=${this.data.imageMeta?.width || "?"}x${this.data.imageMeta?.height || "?"} rot=${this.data.imageMeta?.rotation || "up"}`);
      lines.push(`mapDims=${mapDims.width || "?"}x${mapDims.height || "?"} src=${mapDims.source}`);
      lines.push(`aspectFit=${tf ? `s=${tf.scale.toFixed(4)} off=(${tf.offsetX.toFixed(1)},${tf.offsetY.toFixed(1)})` : "null"}`);
      lines.push(`grid=${this._lastGridSource || "unknown"} cellPx=${this.data.gridCellPx}`);
      lines.push(`cells=${this.data.boothCells?.length || this.data.boothRegions?.length || 0}`);
      if (this.data.cellStats) {
        lines.push(
          `cellStats total=${this.data.cellStats.total || 0} label=${this.data.cellStats.labeled || 0} unlabel=${this.data.cellStats.unlabeled || 0}`
        );
      }
      if (this.data.boothIndexStats) {
        lines.push(
          `boothIndex cfm=${this.data.boothIndexStats.confirmed || 0} inf=${this.data.boothIndexStats.inferred || 0} unres=${this.data.boothIndexStats.unresolved || 0}`
        );
      }
      if (this._anchorCoverage?.summary) lines.push(`anchorAK ${this._anchorCoverage.summary}`);
      if (this._anchorCoverage?.weakRows?.length) lines.push(`anchorWeak ${this._anchorCoverage.weakRows.join(",")}`);
      if (this.data.lookupDebug?.current?.query) {
        const lc = this.data.lookupDebug.current;
        lines.push(`lookup[current] q=${lc.query} path=${lc.path} id=${lc.matchedId || "-"}`);
        lines.push(`lookup[current] prefix=${lc.prefix || "-"} reason=${lc.reason || "-"}`);
      }
      if (this.data.lookupDebug?.dest?.query) {
        const ld = this.data.lookupDebug.dest;
        lines.push(`lookup[dest] q=${ld.query} path=${ld.path} id=${ld.matchedId || "-"}`);
        lines.push(`lookup[dest] prefix=${ld.prefix || "-"} reason=${ld.reason || "-"}`);
      }
      lines.push(`ocrItems=${this.data.ocrItems?.length || 0}`);
      const pd = this.data.parseDebug;
      if (pd?.coordSpace) lines.push(`cloud: rot=${pd.coordSpace.rotation} ocrSpace=${pd.coordSpace.ocrAssumedSpace}`);
      if (pd?.secondaryOcr) {
        lines.push(
          `secondaryOCR rows=${pd.secondaryOcr.rowsTried || 0} assigned=${pd.secondaryOcr.assigned || 0}`
        );
      }
      if (pd?.ocrDiagnostics) {
        lines.push(
          `ocrDiag d1=${pd.ocrDiagnostics.textDetectionsPass1 || 0} d2=${pd.ocrDiagnostics.textDetectionsPass2 || 0} merged=${pd.ocrDiagnostics.ocrItemsMerged || 0}`
        );
        const bso = pd.ocrDiagnostics.bandSecondaryOcr;
        if (bso?.enabled) {
          lines.push(`bandOCR added=${bso.added || 0} sel=${bso.selected?.length || 0}`);
        }
      }
      if (this.data.coordSpace?.version) {
        lines.push(`cis=${this.data.coordSpace.width || "?"}x${this.data.coordSpace.height || "?"} v=${this.data.coordSpace.version}`);
      }
      if (this._imgMetaMismatch) lines.push(`warn: bindload size != cis size`);
      if (pd?.ocrRange) lines.push(`ocrRange=(${pd.ocrRange.minX?.toFixed?.(0)},${pd.ocrRange.minY?.toFixed?.(0)})-(${pd.ocrRange.maxX?.toFixed?.(0)},${pd.ocrRange.maxY?.toFixed?.(0)})`);
      const td = this._lastTapDebug;
      if (td) {
        lines.push(
          `tap=(${td.viewX.toFixed(1)},${td.viewY.toFixed(1)}) src=${td.src || "?"} pick=${td.picked} ${td.reason || ""} ${td.pickedId || ""}`
        );
          if (td.rect) lines.push(`rect=(${td.rect.left.toFixed(1)},${td.rect.top.toFixed(1)}) ${td.rect.width.toFixed(0)}x${td.rect.height.toFixed(0)}`);
        if (td.tapImg) lines.push(`tapImg=(${td.tapImg.x.toFixed(0)},${td.tapImg.y.toFixed(0)}) imgPick=${td.imgPickIdx} regionPick=${td.regionIdx}`);
        if (td.regionHit?.labelId || td.regionHit?.key) lines.push(`cellHit=${td.regionHit.labelId || "-"} key=${td.regionHit.key || "-"}`);
        if (td.regionNear?.labelId || td.regionNear?.key) lines.push(`cellNear=${td.regionNear.labelId || "-"} key=${td.regionNear.key || "-"} d=${Number(td.regionNear.distPx || 0).toFixed(0)}`);
        if (td.distPx != null && td.thresholdPx != null) lines.push(`dist=${td.distPx.toFixed(1)} thr=${td.thresholdPx.toFixed(1)}`);
        if (td.pickedCenterView) lines.push(`pickView=(${td.pickedCenterView.x.toFixed(1)},${td.pickedCenterView.y.toFixed(1)})`);
        // 畫出點擊十字，直觀確認是否有整體偏移
        ctx.strokeStyle = "rgba(255,80,80,0.95)";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(td.viewX - 10, td.viewY);
        ctx.lineTo(td.viewX + 10, td.viewY);
        ctx.moveTo(td.viewX, td.viewY - 10);
        ctx.lineTo(td.viewX, td.viewY + 10);
        ctx.stroke();

        // 畫出「被選攤位中心」的位置（黃點），用來對照為何十字與起終點圖釘會不同
        if (td.pickedCenterView) {
          // 連線：十字 -> 黃點
          ctx.strokeStyle = "rgba(255, 210, 0, 0.7)";
          ctx.lineWidth = 2;
          ctx.beginPath();
          ctx.moveTo(td.viewX, td.viewY);
          ctx.lineTo(td.pickedCenterView.x, td.pickedCenterView.y);
          ctx.stroke();

          ctx.fillStyle = "rgba(255, 210, 0, 0.95)";
          ctx.beginPath();
          ctx.arc(td.pickedCenterView.x, td.pickedCenterView.y, 5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      for (let i = 0; i < lines.length; i++) ctx.fillText(lines[i], 18, 30 + i * 18);
      ctx.restore();
    }

    // 顯示「你點的起點/終點位置」：和攤位中心圖釘是不同概念，避免誤以為映射錯
    if (showDebug && this._lastTapSet) {
      ctx.save();
      const s = this._lastTapSet.start;
      const e = this._lastTapSet.end;
      const drawRing = (pt, color) => {
        if (!pt) return;
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 10, 0, Math.PI * 2);
        ctx.stroke();
      };
      drawRing(s, "rgba(0, 200, 255, 0.9)");
      drawRing(e, "rgba(255, 80, 80, 0.9)");
      ctx.restore();
    }
  },
});


