const { getTempFileUrl } = require("../../utils/cloud");
const { saveFloorplanState, loadFloorplanState } = require("../../utils/state");

Page({
  data: {
    fileID: "",
    previewUrl: "",
    uploadStatus: "尚未上傳",
    parsing: false,
    parseStatus: "尚未解析",
    booths: [],
    boothIndex: [],
    boothCells: null,
    // 相容舊命名（後續可移除）
    boothRegions: null,
    ocrItems: [],
    grid: null,
    imageMeta: null,
    coordSpace: null,
    cellStats: null,
    boothIndexStats: null,
    rowNumberMap: null,
    parseDebug: null,
    gridCellPx: 16,
  },

  onShow() {
    // 允許從底部導航回來時恢復狀態
    const st = loadFloorplanState();
    if (st?.fileID && !this.data.fileID) {
      this.setData({
        fileID: st.fileID,
        previewUrl: st.previewUrl || "",
        booths: st.booths || [],
        boothIndex: st.boothIndex || [],
        boothCells: st.boothCells || st.boothRegions || null,
        boothRegions: st.boothRegions || null,
        ocrItems: st.ocrItems || [],
        grid: st.grid || null,
        imageMeta: st.imageMeta || null,
        coordSpace: st.coordSpace || null,
        cellStats: st.cellStats || null,
        boothIndexStats: st.boothIndexStats || null,
        rowNumberMap: st.rowNumberMap || null,
        parseDebug: st.parseDebug || null,
        gridCellPx: st.gridCellPx || this.data.gridCellPx,
        uploadStatus: st.fileID ? "已載入上次平面圖" : this.data.uploadStatus,
      });
    }
  },

  onNav(e) {
    const to = e.detail?.to;
    if (to === "map") {
      // 走 storage 狀態，避免 query/eventChannel 依賴
      wx.redirectTo({ url: "/pages/map/map" });
    }
  },

  _resetForNewFloorplan() {
    this.setData({
      fileID: "",
      previewUrl: "",
      booths: [],
      boothIndex: [],
      boothCells: null,
      boothRegions: null,
      ocrItems: [],
      imageMeta: null,
      coordSpace: null,
      cellStats: null,
      boothIndexStats: null,
      rowNumberMap: null,
      parseDebug: null,
      parseStatus: "尚未解析",
    });
  },

  async _setPreviewByFileID(fileID) {
    const previewUrl = await getTempFileUrl(fileID);

    // 取圖片原始寬高（用於把 OCR 座標映射回 aspectFit 的顯示位置）
    let imageMeta = null;
    try {
      const info = await wx.getImageInfo({ src: previewUrl });
      imageMeta = {
        width: info.width,
        height: info.height,
        // 重要：JPEG 常含 EXIF 旋轉；雲端解碼（jpeg-js）不會自動旋轉，但前端顯示通常會套用
        // 把 orientation 傳給雲端以統一座標系
        orientation: info.orientation || "up",
        type: info.type || null,
      };
    } catch (e) {
      console.warn("getImageInfo 失敗", e);
    }

    this.setData({ fileID, previewUrl, imageMeta });
    saveFloorplanState({
      fileID,
      previewUrl,
      booths: this.data.booths || [],
      boothIndex: this.data.boothIndex || [],
      boothCells: this.data.boothCells || this.data.boothRegions || null,
      boothRegions: this.data.boothRegions || null,
      ocrItems: this.data.ocrItems || [],
      grid: this.data.grid || null,
      imageMeta,
      coordSpace: this.data.coordSpace || null,
      cellStats: this.data.cellStats || null,
      boothIndexStats: this.data.boothIndexStats || null,
      rowNumberMap: this.data.rowNumberMap || null,
      parseDebug: this.data.parseDebug || null,
      gridCellPx: this.data.gridCellPx,
    });
  },

  async _uploadTempImage(filePath) {
    this.setData({ uploadStatus: "上傳到雲儲存中…" });
    if (!wx.cloud?.uploadFile) {
      throw new Error("雲能力未初始化（請在開發者工具啟用雲開發並選擇環境）");
    }
    const cloudPath = `floorplans/${Date.now()}-${Math.random().toString(16).slice(2)}.png`;
    const up = await wx.cloud.uploadFile({ cloudPath, filePath });
    await this._setPreviewByFileID(up.fileID);
    this.setData({ uploadStatus: "上傳完成" });
  },

  async onChooseAndUpload() {
    try {
      this._resetForNewFloorplan();
      this.setData({ uploadStatus: "選擇圖片中…" });

      const res = await wx.chooseMedia({
        count: 1,
        mediaType: ["image"],
        sizeType: ["original"],
        sourceType: ["album", "camera"],
      });
      const filePath = res.tempFiles?.[0]?.tempFilePath;
      if (!filePath) throw new Error("未取得圖片路徑");

      await this._uploadTempImage(filePath);
    } catch (e) {
      console.error(e);
      const msg = String(e?.message || e || "");
      wx.showToast({ title: "上傳失敗", icon: "error" });
      this.setData({ uploadStatus: "上傳失敗（請重試）" });
      if (msg.includes("env") || msg.includes("環境") || msg.includes("init")) {
        wx.showModal({
          title: "雲環境未就緒",
          content: "請在微信開發者工具啟用「雲開發」並選擇環境後再重試上傳。",
          showCancel: false,
        });
      }
    }
  },

  async onCaptureAndUpload() {
    try {
      this._resetForNewFloorplan();
      this.setData({ uploadStatus: "開啟相機中…" });

      const res = await wx.chooseMedia({
        count: 1,
        mediaType: ["image"],
        sizeType: ["original"],
        sourceType: ["camera"],
      });
      const filePath = res.tempFiles?.[0]?.tempFilePath;
      if (!filePath) throw new Error("未取得圖片路徑");

      await this._uploadTempImage(filePath);
    } catch (e) {
      console.error(e);
      wx.showToast({ title: "拍攝/上傳失敗", icon: "error" });
      this.setData({ uploadStatus: "拍攝/上傳失敗（請重試）" });
    }
  },

  async onScanQr() {
    try {
      this._resetForNewFloorplan();
      this.setData({ uploadStatus: "掃描 QR 中…" });

      const scan = await wx.scanCode({
        scanType: ["qrCode"],
      });

      this.setData({ uploadStatus: "從 QR 匯入圖片中…" });
      wx.showLoading({ title: "匯入中" });

      const { result } = await wx.cloud.callFunction({
        name: "parseFloorplan",
        data: {
          qr: scan,
          importOnly: true,
        },
      });

      if (!result?.ok) throw new Error(result?.error || "QR 匯入失敗");
      const fileID = result.data?.fileID;
      if (!fileID) throw new Error("匯入未取得 fileID");

      await this._setPreviewByFileID(fileID);
      wx.hideLoading();
      this.setData({ uploadStatus: "匯入完成" });
      wx.showToast({ title: "匯入完成", icon: "success" });
    } catch (e) {
      console.error(e);
      wx.hideLoading();
      wx.showToast({ title: "QR 匯入失敗", icon: "error" });
      this.setData({ uploadStatus: "QR 匯入失敗（請重試）" });
    }
  },

  async onParse() {
    if (!this.data.fileID) return;
    try {
      this.setData({
        parsing: true,
        parseStatus: "雲端解析中…",
        booths: [],
        boothIndex: [],
        ocrItems: [],
        imageMeta: this.data.imageMeta || null,
      });
      wx.showLoading({ title: "解析中" });

      const { result } = await wx.cloud.callFunction({
        name: "parseFloorplan",
        data: {
          fileID: this.data.fileID,
          // MVP：可調整 gridCellPx 以控制網格粗細（越小越精細但計算更慢）
          gridCellPx: this.data.gridCellPx,
          // 讓雲端可依 EXIF 旋轉修正 OCR/走道 grid 座標系
          imageMeta: this.data.imageMeta || null,
          // 開啟雲端座標系 sanity check 回傳，方便快速定位偏移根因
          debug: true,
          coordSpaceVersion: 2,
          // 二次 OCR：對缺號列做小範圍補掃描，提升缺框展位召回
          secondaryOcr: true,
          secondaryOcrMaxRows: 5,
        },
      });

      if (!result?.ok) throw new Error(result?.error || "解析失敗");
      this.setData({
        parsing: false,
        parseStatus: "解析完成",
        booths: result.data.booths || [],
        boothIndex: result.data.boothIndex || [],
        boothCells: result.data.boothCells || result.data.boothRegions || null,
        boothRegions: result.data.boothRegions || null,
        ocrItems: result.data.ocrItems || [],
        imageMeta: result.data.imageMeta || this.data.imageMeta || null,
        gridCellPx: result.data.gridCellPx || this.data.gridCellPx,
        grid: result.data.grid || null,
        coordSpace: result.data.coordSpace || null,
        cellStats: result.data.cellStats || null,
        boothIndexStats: result.data.boothIndexStats || null,
        rowNumberMap: result.data.rowNumberMap || null,
        parseDebug: result.data.debug || null,
      });
      saveFloorplanState({
        fileID: this.data.fileID,
        previewUrl: this.data.previewUrl,
        booths: result.data.booths || [],
        boothIndex: result.data.boothIndex || [],
        boothCells: result.data.boothCells || result.data.boothRegions || null,
        boothRegions: result.data.boothRegions || null,
        ocrItems: result.data.ocrItems || [],
        grid: result.data.grid || null,
        imageMeta: result.data.imageMeta || this.data.imageMeta || null,
        coordSpace: result.data.coordSpace || null,
        cellStats: result.data.cellStats || null,
        boothIndexStats: result.data.boothIndexStats || null,
        rowNumberMap: result.data.rowNumberMap || null,
        gridCellPx: result.data.gridCellPx || this.data.gridCellPx,
        parseDebug: result.data.debug || null,
      });
      wx.hideLoading();
      wx.showToast({ title: "解析完成", icon: "success" });
    } catch (e) {
      console.error(e);
      wx.hideLoading();
      wx.showToast({ title: "解析失敗", icon: "error" });
      this.setData({ parsing: false, parseStatus: "解析失敗（請重試）" });
    }
  },

  onGoMap() {
    const { fileID, booths, boothIndex, boothCells, boothRegions, imageMeta, ocrItems, parseDebug, coordSpace, cellStats, boothIndexStats, rowNumberMap } = this.data;
    if (!fileID || !((boothIndex && boothIndex.length) || (booths && booths.length))) return;
    wx.navigateTo({
      url: `/pages/map/map?fileID=${encodeURIComponent(fileID)}`,
      success: (nav) => {
        nav.eventChannel.emit("floorplanData", {
          booths,
          boothIndex: boothIndex || [],
          boothCells: boothCells || boothRegions || null,
          boothRegions: boothRegions || null,
          imageMeta,
          ocrItems,
          parseDebug,
          coordSpace,
          cellStats,
          boothIndexStats,
          rowNumberMap,
          gridCellPx: this.data.gridCellPx,
          grid: this.data.grid || null,
        });
      },
    });
  },
});



