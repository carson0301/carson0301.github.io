Component({
  properties: {
    active: {
      type: String,
      value: "home", // "home" | "map"
    },
  },
  methods: {
    goHome() {
      this.triggerEvent("nav", { to: "home" });
    },
    goMap() {
      this.triggerEvent("nav", { to: "map" });
    },
  },
});




