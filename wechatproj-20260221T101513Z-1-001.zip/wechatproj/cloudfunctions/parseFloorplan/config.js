// 騰訊雲 OCR（GeneralAccurateOCR）設定
// 建議把 SecretId / SecretKey 放在「雲函數環境變數」：
//   SecretId, SecretKey
// 若你使用「API key 設置」注入 CloudBase API Key，會自動提供：
//   CLOUDBASE_APIKEY（此值不等於騰訊雲 SecretKey；OCR 仍需 SecretId/SecretKey）
// 這裡只放不敏感的預設區域。
exports.TENCENT_OCR_REGION = "ap-guangzhou";




