const cloud = require("wx-server-sdk");
const axios = require("axios");
const tencentcloud = require("tencentcloud-sdk-nodejs");
const dns = require("dns");
const https = require("https");
const { PNG } = require("pngjs");
const jpeg = require("jpeg-js");
const { TENCENT_OCR_REGION } = require("./config");

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV });

// 注意：雲函數環境下不建議依賴 native addon（例如 sharp），容易造成「code exit unexpected」
// 圖片壓縮/縮圖建議放在小程式端（chooseMedia 的 compressed）或外部服務。

function parseQrPayload(qr) {
  const text = typeof qr === "string" ? qr : qr?.result || "";
  const raw = String(text || "").trim();
  if (!raw) return { type: "empty" };

  if ((raw.startsWith("{") && raw.endsWith("}")) || (raw.startsWith("[") && raw.endsWith("]"))) {
    try {
      const obj = JSON.parse(raw);
      if (typeof obj?.fileID === "string") return { type: "fileID", value: obj.fileID };
      if (typeof obj?.url === "string") return { type: "url", value: obj.url };
    } catch (e) {
      // ignore
    }
  }

  if (raw.startsWith("cloud://")) return { type: "fileID", value: raw };
  if (raw.toLowerCase().startsWith("fileid:")) return { type: "fileID", value: raw.slice("fileid:".length).trim() };
  if (raw.toLowerCase().startsWith("https://") || raw.toLowerCase().startsWith("http://")) return { type: "url", value: raw };

  return { type: "unsupported", value: raw };
}

function extFromContentType(ct) {
  const c = String(ct || "").toLowerCase();
  if (c.includes("image/png")) return "png";
  if (c.includes("image/webp")) return "webp";
  if (c.includes("image/bmp")) return "bmp";
  if (c.includes("image/gif")) return "gif";
  if (c.includes("image/jpeg") || c.includes("image/jpg")) return "jpg";
  return "jpg";
}

async function importFromUrlToCloudStorage(url) {
  // 下載圖片（限制大小，避免雲函數記憶體爆）
  const resp = await axios.get(url, {
    responseType: "arraybuffer",
    timeout: 20000,
    maxContentLength: 8 * 1024 * 1024,
    maxBodyLength: 8 * 1024 * 1024,
    headers: {
      "User-Agent": "cloudfunctions-parseFloorplan/1.0",
    },
    validateStatus: (s) => s >= 200 && s < 300,
  });

  const ct = resp.headers?.["content-type"] || "";
  if (!String(ct).toLowerCase().startsWith("image/")) {
    const err = new Error("NOT_IMAGE");
    err.code = "NOT_IMAGE";
    err.contentType = ct;
    throw err;
  }

  const buf = Buffer.from(resp.data);
  const ext = extFromContentType(ct);
  const cloudPath = `floorplans/qr-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`;
  const up = await cloud.uploadFile({ cloudPath, fileContent: buf });
  return { fileID: up.fileID, buffer: buf, contentType: ct, bytes: buf.length };
}

async function networkPreflight(hostname, timeoutMs = 3000) {
  // DNS 預檢：快速判斷雲函數是否能解析外部域名
  await Promise.race([
    dns.promises.lookup(hostname),
    new Promise((_, reject) => setTimeout(() => reject(new Error("DNS_LOOKUP_TIMEOUT")), timeoutMs)),
  ]);

  // TLS 連線預檢：避免 DNS 通但 HTTPS 出不去
  await new Promise((resolve, reject) => {
    const req = https.request(
      {
        method: "HEAD",
        host: hostname,
        path: "/",
        timeout: timeoutMs,
      },
      () => resolve(true)
    );
    req.on("timeout", () => req.destroy(new Error("HTTPS_PREFLIGHT_TIMEOUT")));
    req.on("error", reject);
    req.end();
  });
}

function normalizePolygonToBbox(polygon) {
  if (!Array.isArray(polygon) || polygon.length < 4) return null;
  const xs = polygon.map((p) => Number(p.X ?? p.x ?? 0));
  const ys = polygon.map((p) => Number(p.Y ?? p.y ?? 0));
  const x1 = Math.min(...xs);
  const y1 = Math.min(...ys);
  const x2 = Math.max(...xs);
  const y2 = Math.max(...ys);
  return { x1, y1, x2, y2 };
}

function bboxCenter(bbox) {
  return { x: (bbox.x1 + bbox.x2) / 2, y: (bbox.y1 + bbox.y2) / 2 };
}

function detectImageFormat(buffer) {
  if (!buffer || buffer.length < 12) return "unknown";
  // PNG signature: 89 50 4E 47 0D 0A 1A 0A
  if (
    buffer[0] === 0x89 &&
    buffer[1] === 0x50 &&
    buffer[2] === 0x4e &&
    buffer[3] === 0x47 &&
    buffer[4] === 0x0d &&
    buffer[5] === 0x0a &&
    buffer[6] === 0x1a &&
    buffer[7] === 0x0a
  )
    return "png";
  // JPEG starts with FF D8 FF
  if (buffer[0] === 0xff && buffer[1] === 0xd8 && buffer[2] === 0xff) return "jpg";
  return "unknown";
}

function decodeToRgba(buffer) {
  const fmt = detectImageFormat(buffer);
  if (fmt === "png") {
    const png = PNG.sync.read(buffer);
    return { width: png.width, height: png.height, data: png.data }; // RGBA
  }
  if (fmt === "jpg") {
    const img = jpeg.decode(buffer, { useTArray: true });
    // jpeg-js 會輸出 RGBA
    return { width: img.width, height: img.height, data: img.data };
  }
  const err = new Error("UNSUPPORTED_IMAGE_FORMAT");
  err.code = "UNSUPPORTED_IMAGE_FORMAT";
  throw err;
}

function normalizeOrientation(ori) {
  const s = String(ori || "").trim().toLowerCase();
  if (!s) return "up";
  // wx.getImageInfo 常見：up/down/left/right；其他如 up-mirrored 暫不處理 mirror
  if (s.includes("right")) return "right";
  if (s.includes("left")) return "left";
  if (s.includes("down")) return "down";
  return "up";
}

function orientedSize(w, h, rot) {
  if (rot === "left" || rot === "right") return { width: h, height: w };
  return { width: w, height: h };
}

function computeOcrRange(ocrItems) {
  let minX = Infinity;
  let minY = Infinity;
  let maxX = -Infinity;
  let maxY = -Infinity;
  let n = 0;
  for (const it of ocrItems || []) {
    const bb = it?.bbox;
    if (!bb) continue;
    const x1 = Number(bb.x1);
    const y1 = Number(bb.y1);
    const x2 = Number(bb.x2);
    const y2 = Number(bb.y2);
    if ([x1, y1, x2, y2].some((v) => !isFinite(v))) continue;
    minX = Math.min(minX, x1, x2);
    minY = Math.min(minY, y1, y2);
    maxX = Math.max(maxX, x1, x2);
    maxY = Math.max(maxY, y1, y2);
    n++;
  }
  if (!n || !isFinite(minX) || !isFinite(minY) || !isFinite(maxX) || !isFinite(maxY)) return null;
  return { minX, minY, maxX, maxY, n };
}

function overflowScore(range, w, h) {
  if (!range || !(w > 0 && h > 0)) return Infinity;
  const left = Math.max(0, 0 - range.minX);
  const top = Math.max(0, 0 - range.minY);
  const right = Math.max(0, range.maxX - w);
  const bottom = Math.max(0, range.maxY - h);
  return left + top + right + bottom;
}

function rotatePointContinuous(pt, w, h, rot) {
  const x = Number(pt?.x);
  const y = Number(pt?.y);
  if (!isFinite(x) || !isFinite(y)) return null;
  if (rot === "right") return { x: h - y, y: x };
  if (rot === "left") return { x: y, y: w - x };
  if (rot === "down") return { x: w - x, y: h - y };
  return { x, y };
}

function transformBbox(bb, w, h, rot) {
  if (!bb) return null;
  const corners = [
    { x: Number(bb.x1), y: Number(bb.y1) },
    { x: Number(bb.x2), y: Number(bb.y1) },
    { x: Number(bb.x2), y: Number(bb.y2) },
    { x: Number(bb.x1), y: Number(bb.y2) },
  ];
  const pts = corners.map((p) => rotatePointContinuous(p, w, h, rot)).filter(Boolean);
  if (pts.length !== 4) return null;
  const xs = pts.map((p) => p.x);
  const ys = pts.map((p) => p.y);
  return { x1: Math.min(...xs), y1: Math.min(...ys), x2: Math.max(...xs), y2: Math.max(...ys) };
}

function transformPolygon(poly, w, h, rot) {
  if (!Array.isArray(poly) || poly.length < 4) return poly;
  const out = [];
  for (const p of poly) {
    const pt = rotatePointContinuous({ x: Number(p?.X ?? p?.x), y: Number(p?.Y ?? p?.y) }, w, h, rot);
    if (!pt) continue;
    out.push({ X: pt.x, Y: pt.y });
  }
  return out.length >= 4 ? out : poly;
}

function transformOcrItems(ocrItems, w, h, rot) {
  return (ocrItems || []).map((it) => {
    const bbox = transformBbox(it?.bbox, w, h, rot);
    const polygon = transformPolygon(it?.polygon, w, h, rot);
    return bbox
      ? {
          ...it,
          polygon,
          bbox,
        }
      : it;
  });
}

function transformBooths(booths, w, h, rot) {
  return (booths || []).map((b) => {
    const bbox = transformBbox(b?.bbox, w, h, rot);
    const center = bbox ? bboxCenter(bbox) : b?.center;
    return bbox
      ? {
          ...b,
          bbox,
          center,
        }
      : b;
  });
}

function rotateRgba({ data, width, height }, rot) {
  if (!data || !(width > 0 && height > 0) || rot === "up") return { data, width, height };
  if (rot === "down") {
    const out = new Uint8Array(width * height * 4);
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const src = (y * width + x) * 4;
        const dx = width - 1 - x;
        const dy = height - 1 - y;
        const dst = (dy * width + dx) * 4;
        out[dst] = data[src];
        out[dst + 1] = data[src + 1];
        out[dst + 2] = data[src + 2];
        out[dst + 3] = data[src + 3];
      }
    }
    return { data: out, width, height };
  }
  // left/right: swap w/h
  const outW = height;
  const outH = width;
  const out = new Uint8Array(outW * outH * 4);
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const src = (y * width + x) * 4;
      let dx, dy;
      if (rot === "right") {
        dx = outW - 1 - y;
        dy = x;
      } else {
        // left
        dx = y;
        dy = outH - 1 - x;
      }
      const dst = (dy * outW + dx) * 4;
      out[dst] = data[src];
      out[dst + 1] = data[src + 1];
      out[dst + 2] = data[src + 2];
      out[dst + 3] = data[src + 3];
    }
  }
  return { data: out, width: outW, height: outH };
}

function packBitsetToBase64(bits /* Uint8Array 0/1 */) {
  const n = bits.length;
  const bytes = Buffer.allocUnsafe(Math.ceil(n / 8));
  bytes.fill(0);
  for (let i = 0; i < n; i++) {
    if (bits[i]) bytes[i >> 3] |= 1 << (i & 7);
  }
  return bytes.toString("base64");
}

function clampInt(n, min, max) {
  const x = Math.trunc(Number(n));
  if (!isFinite(x)) return min;
  return Math.max(min, Math.min(max, x));
}

function rgbaAt(rgba, width, height, x, y) {
  const xi = clampInt(x, 0, width - 1);
  const yi = clampInt(y, 0, height - 1);
  const idx = (yi * width + xi) * 4;
  return [rgba[idx], rgba[idx + 1], rgba[idx + 2], rgba[idx + 3]];
}

function lumOf(r, g, b) {
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

function isBorderPixel(r, g, b, a) {
  if (a < 30) return false;
  const lum = lumOf(r, g, b);
  const maxRGB = Math.max(r, g, b);
  const minRGB = Math.min(r, g, b);
  const chroma = maxRGB - minRGB;
  const distToWhite = (255 - r) + (255 - g) + (255 - b);
  // 偏黑/灰的線條（常見框線/格線）
  if (lum <= 105) return true;
  // 偏灰且離白遠：避免彩色填充被當線
  if (lum <= 155 && chroma <= 26 && distToWhite >= 260) return true;
  // 淡灰格線（本圖常見）：亮度較高但彩度很低，且不是接近純白
  if (lum <= 220 && chroma <= 18 && distToWhite >= 90) return true;
  return false;
}

function edgeScoreAtX({ rgba, width, height, x, y, halfSpan = 4, step = 1, lumDiff = 18 }) {
  // 以「水平梯度」找垂直邊界：比較 x 與 x-step 的亮度差
  let hit = 0;
  let total = 0;
  const xx = clampInt(x, 1, width - 1);
  const x0 = clampInt(xx - step, 0, width - 2);
  for (let dy = -halfSpan; dy <= halfSpan; dy++) {
    const yy = clampInt(y + dy, 0, height - 1);
    const idx1 = (yy * width + xx) * 4;
    const idx0 = (yy * width + x0) * 4;
    const r1 = rgba[idx1], g1 = rgba[idx1 + 1], b1 = rgba[idx1 + 2], a1 = rgba[idx1 + 3];
    const r0 = rgba[idx0], g0 = rgba[idx0 + 1], b0 = rgba[idx0 + 2], a0 = rgba[idx0 + 3];
    total++;
    const l1 = lumOf(r1, g1, b1);
    const l0 = lumOf(r0, g0, b0);
    const d = Math.abs(l1 - l0);
    // 只在「低彩度」邊緣上計分，避免彩色塊邊緣造成誤判
    const chroma1 = Math.max(r1, g1, b1) - Math.min(r1, g1, b1);
    const chroma0 = Math.max(r0, g0, b0) - Math.min(r0, g0, b0);
    const lowChroma = chroma1 <= 26 && chroma0 <= 26;
    if (d >= lumDiff && lowChroma && a1 >= 30 && a0 >= 30) hit++;
    else if (isBorderPixel(r1, g1, b1, a1) && isBorderPixel(r0, g0, b0, a0)) hit++; // fallback
  }
  return { hit, total };
}

function edgeScoreAtY({ rgba, width, height, x, y, halfSpan = 4, step = 1, lumDiff = 18 }) {
  // 以「垂直梯度」找水平邊界：比較 y 與 y-step 的亮度差
  let hit = 0;
  let total = 0;
  const yy = clampInt(y, 1, height - 1);
  const y0 = clampInt(yy - step, 0, height - 2);
  for (let dx = -halfSpan; dx <= halfSpan; dx++) {
    const xx = clampInt(x + dx, 0, width - 1);
    const idx1 = (yy * width + xx) * 4;
    const idx0 = (y0 * width + xx) * 4;
    const r1 = rgba[idx1], g1 = rgba[idx1 + 1], b1 = rgba[idx1 + 2], a1 = rgba[idx1 + 3];
    const r0 = rgba[idx0], g0 = rgba[idx0 + 1], b0 = rgba[idx0 + 2], a0 = rgba[idx0 + 3];
    total++;
    const l1 = lumOf(r1, g1, b1);
    const l0 = lumOf(r0, g0, b0);
    const d = Math.abs(l1 - l0);
    const chroma1 = Math.max(r1, g1, b1) - Math.min(r1, g1, b1);
    const chroma0 = Math.max(r0, g0, b0) - Math.min(r0, g0, b0);
    const lowChroma = chroma1 <= 26 && chroma0 <= 26;
    if (d >= lumDiff && lowChroma && a1 >= 30 && a0 >= 30) hit++;
    else if (isBorderPixel(r1, g1, b1, a1) && isBorderPixel(r0, g0, b0, a0)) hit++; // fallback
  }
  return { hit, total };
}

function borderScoreAtX({ rgba, width, height, x, y, halfSpan = 4 }) {
  let hit = 0;
  let total = 0;
  for (let dy = -halfSpan; dy <= halfSpan; dy++) {
    const yy = clampInt(y + dy, 0, height - 1);
    const idx = (yy * width + clampInt(x, 0, width - 1)) * 4;
    const r = rgba[idx];
    const g = rgba[idx + 1];
    const b = rgba[idx + 2];
    const a = rgba[idx + 3];
    total++;
    if (isBorderPixel(r, g, b, a)) hit++;
  }
  return { hit, total };
}

function borderScoreAtY({ rgba, width, height, x, y, halfSpan = 4 }) {
  let hit = 0;
  let total = 0;
  const yy = clampInt(y, 0, height - 1);
  for (let dx = -halfSpan; dx <= halfSpan; dx++) {
    const xx = clampInt(x + dx, 0, width - 1);
    const idx = (yy * width + xx) * 4;
    const r = rgba[idx];
    const g = rgba[idx + 1];
    const b = rgba[idx + 2];
    const a = rgba[idx + 3];
    total++;
    if (isBorderPixel(r, g, b, a)) hit++;
  }
  return { hit, total };
}

function colorDelta(a, b) {
  return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]);
}

function findBoundary1D({ rgba, width, height, cx, cy, dir, maxD, baseColor }) {
  const hitNeed = 5; // 9 samples 中至少 5 個像線（避免文字筆劃誤判）
  for (let d = 2; d <= maxD; d++) {
    const x = dir === "left" ? cx - d : dir === "right" ? cx + d : cx;
    const y = dir === "up" ? cy - d : dir === "down" ? cy + d : cy;
    if (x < 1 || x >= width - 1 || y < 1 || y >= height - 1) break;
    const sc =
      dir === "left" || dir === "right"
        ? edgeScoreAtX({ rgba, width, height, x, y: cy, halfSpan: 4, step: 1, lumDiff: 16 })
        : edgeScoreAtY({ rgba, width, height, x: cx, y, halfSpan: 4, step: 1, lumDiff: 16 });
    if (sc.hit >= hitNeed) return { found: true, at: dir === "left" || dir === "right" ? x : y, reason: "border" };
    // fallback：顏色突變（例如框線不夠黑但仍是邊界）
    const col = rgbaAt(rgba, width, height, x, y);
    const dlt = colorDelta(col, baseColor);
    if (dlt >= 240 && lumOf(col[0], col[1], col[2]) <= 200) return { found: true, at: dir === "left" || dir === "right" ? x : y, reason: "delta" };
  }
  return { found: false, at: null, reason: "none" };
}

function estimateBoothRegionFromCenter({ rgba, width, height, center, maxSearchPx = 140 }) {
  const cx = clampInt(center?.x, 0, width - 1);
  const cy = clampInt(center?.y, 0, height - 1);
  const baseColor = rgbaAt(rgba, width, height, cx, cy);
  const left = findBoundary1D({ rgba, width, height, cx, cy, dir: "left", maxD: maxSearchPx, baseColor });
  const right = findBoundary1D({ rgba, width, height, cx, cy, dir: "right", maxD: maxSearchPx, baseColor });
  const up = findBoundary1D({ rgba, width, height, cx, cy, dir: "up", maxD: maxSearchPx, baseColor });
  const down = findBoundary1D({ rgba, width, height, cx, cy, dir: "down", maxD: maxSearchPx, baseColor });

  if (!(left.found && right.found && up.found && down.found)) return null;

  // 往內縮一點，避免把邊線吃進去；同時限制最小大小
  let x1 = clampInt(left.at + 1, 0, width - 1);
  let x2 = clampInt(right.at - 1, 0, width - 1);
  let y1 = clampInt(up.at + 1, 0, height - 1);
  let y2 = clampInt(down.at - 1, 0, height - 1);
  if (x2 <= x1 || y2 <= y1) return null;
  const w = x2 - x1;
  const h = y2 - y1;
  if (w < 10 || h < 10) return null;
  // 過大的框多半不是單一攤位格（例如整區塊）
  if (w > width * 0.35 || h > height * 0.35) return null;

  return { bbox: { x1, y1, x2, y2 }, center: { x: (x1 + x2) / 2, y: (y1 + y2) / 2 } };
}

function median(arr) {
  const a = (arr || []).filter((x) => isFinite(x)).slice().sort((x, y) => x - y);
  if (!a.length) return null;
  const mid = Math.floor(a.length / 2);
  return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
}

function clamp01(v) {
  const x = Number(v);
  if (!isFinite(x)) return 0;
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  return x;
}

function bboxArea(bb) {
  if (!bb) return 0;
  const w = Math.max(0, Number(bb.x2) - Number(bb.x1));
  const h = Math.max(0, Number(bb.y2) - Number(bb.y1));
  return w * h;
}

function intersectArea(a, b) {
  if (!a || !b) return 0;
  const x1 = Math.max(Number(a.x1), Number(b.x1));
  const y1 = Math.max(Number(a.y1), Number(b.y1));
  const x2 = Math.min(Number(a.x2), Number(b.x2));
  const y2 = Math.min(Number(a.y2), Number(b.y2));
  const w = Math.max(0, x2 - x1);
  const h = Math.max(0, y2 - y1);
  return w * h;
}

function iouOfBbox(a, b) {
  const ia = intersectArea(a, b);
  if (ia <= 0) return 0;
  const ua = bboxArea(a) + bboxArea(b) - ia;
  if (ua <= 0) return 0;
  return ia / ua;
}

function filterCloseLines(lines, minGap) {
  const arr = (lines || []).filter((v) => isFinite(v)).slice().sort((a, b) => a - b);
  if (arr.length <= 2) return arr;
  const out = [arr[0]];
  for (let i = 1; i < arr.length; i++) {
    const v = arr[i];
    if (v - out[out.length - 1] < minGap) {
      out[out.length - 1] = Math.round((out[out.length - 1] + v) / 2);
    } else {
      out.push(v);
    }
  }
  return out;
}

function sampleCellVisualScore({ rgba, width, height, x0, y0, x1, y1 }) {
  // 高分代表「像一個有邊框的攤位格」，低分代表走道/噪聲區
  const w = Math.max(1, x1 - x0);
  const h = Math.max(1, y1 - y0);
  const sx = Math.max(1, Math.floor(w / 10));
  const sy = Math.max(1, Math.floor(h / 10));

  let borderTotal = 0;
  let borderHits = 0;
  let innerTotal = 0;
  let innerWhiteLike = 0;
  let innerVarAcc = 0;
  let innerLumAcc = 0;
  let innerLumAcc2 = 0;

  const readPix = (x, y) => {
    const idx = (clampInt(y, 0, height - 1) * width + clampInt(x, 0, width - 1)) * 4;
    return [rgba[idx], rgba[idx + 1], rgba[idx + 2], rgba[idx + 3]];
  };

  for (let x = x0; x <= x1; x += sx) {
    const pTop = readPix(x, y0);
    const pBottom = readPix(x, y1);
    borderTotal += 2;
    if (isBorderPixel(pTop[0], pTop[1], pTop[2], pTop[3])) borderHits++;
    if (isBorderPixel(pBottom[0], pBottom[1], pBottom[2], pBottom[3])) borderHits++;
  }
  for (let y = y0; y <= y1; y += sy) {
    const pLeft = readPix(x0, y);
    const pRight = readPix(x1, y);
    borderTotal += 2;
    if (isBorderPixel(pLeft[0], pLeft[1], pLeft[2], pLeft[3])) borderHits++;
    if (isBorderPixel(pRight[0], pRight[1], pRight[2], pRight[3])) borderHits++;
  }

  const ix0 = x0 + Math.max(1, Math.floor(w * 0.2));
  const ix1 = x1 - Math.max(1, Math.floor(w * 0.2));
  const iy0 = y0 + Math.max(1, Math.floor(h * 0.2));
  const iy1 = y1 - Math.max(1, Math.floor(h * 0.2));
  for (let y = iy0; y <= iy1; y += sy) {
    for (let x = ix0; x <= ix1; x += sx) {
      const [r, g, b, a] = readPix(x, y);
      const lum = lumOf(r, g, b);
      const chroma = Math.max(r, g, b) - Math.min(r, g, b);
      innerTotal++;
      innerLumAcc += lum;
      innerLumAcc2 += lum * lum;
      if (a > 30 && lum >= 228 && chroma <= 18) innerWhiteLike++;
      innerVarAcc += chroma;
    }
  }
  const borderRate = borderTotal ? borderHits / borderTotal : 0;
  const whiteRatio = innerTotal ? innerWhiteLike / innerTotal : 1;
  const meanLum = innerTotal ? innerLumAcc / innerTotal : 255;
  const varLum = innerTotal ? Math.max(0, innerLumAcc2 / innerTotal - meanLum * meanLum) : 0;
  const meanChroma = innerTotal ? innerVarAcc / innerTotal : 0;
  const notWalkway = clamp01((220 - meanLum) / 120 + (meanChroma - 8) / 30 + (1 - whiteRatio) * 0.8);
  const texture = clamp01(Math.sqrt(varLum) / 40);
  return clamp01(borderRate * 0.62 + notWalkway * 0.28 + texture * 0.1);
}

function smooth1D(vals, win = 9) {
  const n = vals.length;
  const w = Math.max(1, Math.trunc(win));
  const half = Math.floor(w / 2);
  const out = new Float64Array(n);
  let sum = 0;
  let cnt = 0;
  for (let i = 0; i < n; i++) {
    const addIdx = i;
    sum += vals[addIdx];
    cnt++;
    const removeIdx = i - w;
    if (removeIdx >= 0) {
      sum -= vals[removeIdx];
      cnt--;
    }
    const center = i - half;
    if (center >= 0 && center < n) out[center] = sum / Math.max(1, cnt);
  }
  // 補尾端
  for (let i = n - half; i < n; i++) {
    if (i >= 0 && i < n) out[i] = out[n - half - 1] || 0;
  }
  return out;
}

function findPeaks(vals, { threshold, minDistance = 4, maxPeaks = 600 } = {}) {
  const n = vals.length;
  const peaks = [];
  const thr = Number(threshold || 0);
  for (let i = 1; i < n - 1; i++) {
    const v = vals[i];
    if (v < thr) continue;
    if (v >= vals[i - 1] && v >= vals[i + 1]) peaks.push({ idx: i, v });
  }
  peaks.sort((a, b) => b.v - a.v);
  const chosen = [];
  for (const p of peaks) {
    if (chosen.length >= maxPeaks) break;
    if (chosen.some((c) => Math.abs(c.idx - p.idx) <= minDistance)) continue;
    chosen.push(p);
  }
  chosen.sort((a, b) => a.idx - b.idx);
  // 合併太近的峰（取較大的那個）
  const merged = [];
  for (const p of chosen) {
    const last = merged[merged.length - 1];
    if (last && Math.abs(p.idx - last.idx) <= minDistance) {
      if (p.v > last.v) merged[merged.length - 1] = p;
    } else {
      merged.push(p);
    }
  }
  return merged;
}

function neighborLines(pos, lines) {
  if (!Array.isArray(lines) || lines.length < 2 || !isFinite(pos)) return null;
  let lo = 0;
  let hi = lines.length - 1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (lines[mid] < pos) lo = mid + 1;
    else hi = mid - 1;
  }
  const right = lines[lo];
  const left = lines[lo - 1];
  if (!isFinite(left) || !isFinite(right)) return null;
  return { left, right };
}

function buildBoothRegionsByScan({ rgba, width, height, booths, gridCellPx }) {
  const regions = [];
  const max = 1800;
  const maxSearchPx = Math.max(120, Math.min(380, Number(gridCellPx || 16) * 18));
  for (const b of booths || []) {
    if (regions.length >= max) break;
    const id = String(b?.id || "").trim();
    if (!id) continue;
    const c = b?.center || (b?.bbox ? bboxCenter(b.bbox) : null);
    if (!c) continue;
    const reg = estimateBoothRegionFromCenter({ rgba, width, height, center: c, maxSearchPx });
    if (!reg) continue;
    regions.push({ id, bbox: reg.bbox, center: reg.center });
  }
  return regions;
}

function buildBoothRegionsByGridlines({ rgba, width, height, booths, gridCellPx, ocrRange, ocrItems }) {
  const out = [];
  const max = 6000;
  const r = ocrRange || null;
  // ROI：聚焦在 OCR 主要分布區，避免上方標題/圖例干擾
  const pad = 60;
  let roiX1 = clampInt((r?.minX ?? 0) - pad, 0, width - 1);
  let roiY1 = clampInt((r?.minY ?? 0) - pad, 0, height - 1);
  let roiX2 = clampInt((r?.maxX ?? width - 1) + pad, 0, width - 1);
  let roiY2 = clampInt((r?.maxY ?? height - 1) + pad, 0, height - 1);

  // 若已有 OCR booth，拿其分布再收斂 ROI，可有效排除圖例/標題區
  if (Array.isArray(booths) && booths.length >= 30) {
    let bx1 = Infinity;
    let by1 = Infinity;
    let bx2 = -Infinity;
    let by2 = -Infinity;
    for (const b of booths) {
      const bb = b?.bbox;
      if (!bb) continue;
      bx1 = Math.min(bx1, bb.x1);
      by1 = Math.min(by1, bb.y1);
      bx2 = Math.max(bx2, bb.x2);
      by2 = Math.max(by2, bb.y2);
    }
    if (isFinite(bx1) && isFinite(by1) && isFinite(bx2) && isFinite(by2)) {
      roiX1 = Math.max(roiX1, clampInt(bx1 - pad, 0, width - 1));
      roiY1 = Math.max(roiY1, clampInt(by1 - pad, 0, height - 1));
      roiX2 = Math.min(roiX2, clampInt(bx2 + pad, 0, width - 1));
      roiY2 = Math.min(roiY2, clampInt(by2 + pad, 0, height - 1));
    }
  }
  if (roiX2 - roiX1 < 20 || roiY2 - roiY1 < 20) {
    roiX1 = 0;
    roiY1 = 0;
    roiX2 = width - 1;
    roiY2 = height - 1;
  }
  const roiW = Math.max(1, roiX2 - roiX1);
  const roiH = Math.max(1, roiY2 - roiY1);

  // 下採樣：控制計算量（~700px 寬）
  const targetW = 760;
  const scale = Math.min(1, targetW / roiW);
  const dsW = Math.max(60, Math.floor(roiW * scale));
  const dsH = Math.max(60, Math.floor(roiH * scale));

  const vx = new Uint32Array(dsW); // 垂直邊界強度（每個 x 累積）
  const hy = new Uint32Array(dsH); // 水平邊界強度（每個 y 累積）

  const thrEdge = 20;
  let prevGray = new Uint8Array(dsW);
  let curGray = new Uint8Array(dsW);

  for (let yy = 0; yy < dsH; yy++) {
    const y = roiY1 + (yy / scale);
    for (let xx = 0; xx < dsW; xx++) {
      const x = roiX1 + (xx / scale);
      const idx = (clampInt(y, 0, height - 1) * width + clampInt(x, 0, width - 1)) * 4;
      const r0 = rgba[idx];
      const g0 = rgba[idx + 1];
      const b0 = rgba[idx + 2];
      // 灰階即可（格線是淡灰低彩度）
      curGray[xx] = Math.max(0, Math.min(255, Math.round(lumOf(r0, g0, b0))));
    }
    // 垂直線：看 x 方向梯度（abs diff with left)
    for (let xx = 1; xx < dsW; xx++) {
      const d = Math.abs(curGray[xx] - curGray[xx - 1]);
      if (d >= thrEdge) vx[xx] += 1;
    }
    // 水平線：看 y 方向梯度（abs diff with prev row）
    if (yy > 0) {
      for (let xx = 0; xx < dsW; xx++) {
        const d = Math.abs(curGray[xx] - prevGray[xx]);
        if (d >= thrEdge) hy[yy] += 1;
      }
    }
    const tmp = prevGray;
    prevGray = curGray;
    curGray = tmp;
  }

  const vxS = smooth1D(vx, 9);
  const hyS = smooth1D(hy, 9);
  const maxV = vxS.reduce((m, v) => (v > m ? v : m), 0);
  const maxH = hyS.reduce((m, v) => (v > m ? v : m), 0);
  const thrV = Math.max(maxV * 0.42, dsH * 0.14);
  const thrH = Math.max(maxH * 0.42, dsW * 0.14);

  let vPeaks = findPeaks(vxS, { threshold: thrV, minDistance: 6, maxPeaks: 900 });
  let hPeaks = findPeaks(hyS, { threshold: thrH, minDistance: 6, maxPeaks: 1500 });
  if (vPeaks.length < 10 || hPeaks.length < 10) return out;

  const xs = vPeaks.map((p) => roiX1 + p.idx / scale);
  const ys = hPeaks.map((p) => roiY1 + p.idx / scale);

  // 加入 ROI 外框當邊界
  xs.unshift(roiX1);
  xs.push(roiX2);
  ys.unshift(roiY1);
  ys.push(roiY2);

  xs.sort((a, b) => a - b);
  ys.sort((a, b) => a - b);

  // 轉成整數線座標（像素），方便命中與枚舉 cell
  const uniq = (arr) => Array.from(new Set(arr.map((v) => clampInt(Math.round(v), 0, width - 1)))).sort((a, b) => a - b);
  let xLines = uniq(xs);
  let yLines = uniq(ys);
  if (xLines.length < 6 || yLines.length < 6) return out;

  // 估計典型格子尺寸
  const dxs = [];
  for (let i = 1; i < xLines.length; i++) {
    const d = xLines[i] - xLines[i - 1];
    if (d >= 8 && d <= width * 0.2) dxs.push(d);
  }
  const dys = [];
  for (let i = 1; i < yLines.length; i++) {
    const d = yLines[i] - yLines[i - 1];
    if (d >= 8 && d <= height * 0.2) dys.push(d);
  }
  let dxMed = median(dxs) || 60;
  let dyMed = median(dys) || 40;

  // 近距離平行線合併，抑制文字/噪聲帶來的「偽格線」
  xLines = filterCloseLines(xLines, Math.max(5, Math.round(dxMed * 0.38)));
  yLines = filterCloseLines(yLines, Math.max(5, Math.round(dyMed * 0.38)));
  if (xLines.length < 6 || yLines.length < 6) return out;
  const dxs2 = [];
  for (let i = 1; i < xLines.length; i++) {
    const d = xLines[i] - xLines[i - 1];
    if (d >= 8 && d <= width * 0.2) dxs2.push(d);
  }
  const dys2 = [];
  for (let i = 1; i < yLines.length; i++) {
    const d = yLines[i] - yLines[i - 1];
    if (d >= 8 && d <= height * 0.2) dys2.push(d);
  }
  dxMed = median(dxs2) || dxMed;
  dyMed = median(dys2) || dyMed;

  // 先枚舉所有 cell（攤位格），再把 OCR booth id 貼到 cell（labelId）
  const cells = [];
  const maxCells = 12000;
  const okW = (w) => w >= dxMed * 0.58 && w <= dxMed * 2.8;
  const okH = (h) => h >= dyMed * 0.58 && h <= dyMed * 2.8;
  for (let rr = 0; rr < yLines.length - 1; rr++) {
    const y0 = yLines[rr];
    const y1 = yLines[rr + 1];
    const h = y1 - y0;
    if (!okH(h)) continue;
    for (let cc = 0; cc < xLines.length - 1; cc++) {
      const x0 = xLines[cc];
      const x1 = xLines[cc + 1];
      const w = x1 - x0;
      if (!okW(w)) continue;
      // ROI 範圍內優先；完全在 ROI 外則略過
      const cx = (x0 + x1) / 2;
      const cy = (y0 + y1) / 2;
      if (cx < roiX1 || cx > roiX2 || cy < roiY1 || cy > roiY2) continue;
      const cellScore = sampleCellVisualScore({
        rgba,
        width,
        height,
        x0: x0 + 1,
        y0: y0 + 1,
        x1: x1 - 1,
        y1: y1 - 1,
      });
      if (cellScore < 0.3) continue;
      cells.push({
        key: `${rr},${cc}`,
        row: rr,
        col: cc,
        bbox: { x1: x0 + 1, y1: y0 + 1, x2: x1 - 1, y2: y1 - 1 },
        center: { x: cx, y: cy },
        labelId: null,
        cellScore,
        labelConfidence: 0,
      });
      if (cells.length >= maxCells) break;
    }
    if (cells.length >= maxCells) break;
  }
  if (!cells.length) return out;

  // 以鄰接一致性過濾孤立噪聲格
  const keySet = new Set(cells.map((c) => c.key));
  const survived = [];
  for (const c of cells) {
    let neighbors = 0;
    const nbs = [
      `${c.row - 1},${c.col}`,
      `${c.row + 1},${c.col}`,
      `${c.row},${c.col - 1}`,
      `${c.row},${c.col + 1}`,
    ];
    for (const k of nbs) if (keySet.has(k)) neighbors++;
    c.neighborCount = neighbors;
    if (neighbors >= 2 || c.cellScore >= 0.58) survived.push(c);
  }
  if (!survived.length) return out;

  // 依格子品質排序，避免超量時先進先出造成局部偏差
  survived.sort((a, b) => {
    const sa = a.cellScore * 0.82 + Math.min(3, a.neighborCount) * 0.06;
    const sb = b.cellScore * 0.82 + Math.min(3, b.neighborCount) * 0.06;
    return sb - sa;
  });
  const expected = booths?.length ? Math.round(Math.max(480, booths.length * 2.2)) : 1200;
  const keepLimit = Math.min(2200, Math.max(900, Math.round(expected * 1.55)));
  const kept = survived.slice(0, keepLimit);

  assignLabelsToCells({
    cells: kept,
    booths,
    ocrItems,
  });

  // 相容舊格式：id 欄位放 labelId（沒有就 null）
  for (const cell of kept) {
    out.push({
      id: cell.labelId,
      key: cell.key,
      labelId: cell.labelId,
      labelConfidence: Number(cell.labelConfidence || 0),
      cellScore: Number(cell.cellScore || 0),
      row: cell.row,
      col: cell.col,
      bbox: cell.bbox,
      center: cell.center,
    });
    if (out.length >= max) break;
  }
  return out;
}

function buildBoothRegions({ rgba, width, height, booths, gridCellPx, ocrRange, ocrItems }) {
  // 優先用「全局格線偵測」：對規整表格型攤位圖更穩、覆蓋率更高
  const byLines = buildBoothRegionsByGridlines({ rgba, width, height, booths, gridCellPx, ocrRange, ocrItems });
  if (byLines?.length >= Math.min(300, Math.floor((booths?.length || 0) * 0.6))) return byLines;
  // fallback：每個攤位中心向外掃描找邊界（較容易漏抓）
  return buildBoothRegionsByScan({ rgba, width, height, booths, gridCellPx });
}

function buildWalkableGridFromImage({ rgba, width, height, cellSizePx, booths = [] }) {
  // 1) 決定 grid 尺寸（避免過大）
  const maxCells = 220_000; // 約 470x470，A* 還能接受
  let cols = Math.max(1, Math.ceil(width / cellSizePx));
  let rows = Math.max(1, Math.ceil(height / cellSizePx));
  if (rows * cols > maxCells) {
    const scale = Math.sqrt((rows * cols) / maxCells);
    const newCell = Math.ceil(cellSizePx * scale);
    cellSizePx = newCell;
    cols = Math.max(1, Math.ceil(width / cellSizePx));
    rows = Math.max(1, Math.ceil(height / cellSizePx));
  }

  // 2) 建立「候選可走（light）」mask：近白/透明視為可走
  const light = new Uint8Array(rows * cols); // 1 = light/free candidate
  const stride = width * 4;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x0 = Math.min(width - 1, c * cellSizePx);
      const y0 = Math.min(height - 1, r * cellSizePx);
      const x1 = Math.min(width, x0 + cellSizePx);
      const y1 = Math.min(height, y0 + cellSizePx);
      // 抽樣：取 2x2（或 1x1）平均，降低成本
      const sx = x1 - x0;
      const sy = y1 - y0;
      const px1 = x0 + Math.floor(sx * 0.25);
      const px2 = x0 + Math.floor(sx * 0.75);
      const py1 = y0 + Math.floor(sy * 0.25);
      const py2 = y0 + Math.floor(sy * 0.75);
      const samples = [
        [px1, py1],
        [px2, py1],
        [px1, py2],
        [px2, py2],
      ];
      let sumR = 0;
      let sumG = 0;
      let sumB = 0;
      let sumA = 0;
      for (const [x, y] of samples) {
        const idx = y * stride + x * 4;
        sumR += rgba[idx];
        sumG += rgba[idx + 1];
        sumB += rgba[idx + 2];
        sumA += rgba[idx + 3];
      }
      const n = samples.length;
      const R = sumR / n;
      const G = sumG / n;
      const B = sumB / n;
      const A = sumA / n;

      // 透明當可走（避免 PNG 透明背景誤判）
      if (A < 30) {
        light[r * cols + c] = 1;
        continue;
      }
      const lum = 0.2126 * R + 0.7152 * G + 0.0722 * B;
      const distToWhite = (255 - R) + (255 - G) + (255 - B);
      const maxRGB = Math.max(R, G, B);
      const minRGB = Math.min(R, G, B);
      const chroma = maxRGB - minRGB; // 越大越「彩色」
      // 通用 heuristic：走道通常是亮/接近白；彩色 booth 塊與黑線通常較暗或離白遠
      // 另外加一個「低彩度」條件，避免淺色 booth 被誤判成白走道
      light[r * cols + c] = lum >= 205 && distToWhite <= 150 && chroma <= 28 ? 1 : 0;
    }
  }

  // 3) 形態學 closing：填掉文字造成的小洞（先膨脹再侵蝕）
  const dil = new Uint8Array(rows * cols);
  const ero = new Uint8Array(rows * cols);
  const idxOf = (rr, cc) => rr * cols + cc;
  const inb = (rr, cc) => rr >= 0 && rr < rows && cc >= 0 && cc < cols;
  const rad = 1;
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      let v = 0;
      for (let dr = -rad; dr <= rad && !v; dr++) {
        for (let dc = -rad; dc <= rad; dc++) {
          const rr = r + dr;
          const cc = c + dc;
          if (!inb(rr, cc)) continue;
          if (light[idxOf(rr, cc)]) {
            v = 1;
            break;
          }
        }
      }
      dil[idxOf(r, c)] = v;
    }
  }
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      let v = 1;
      for (let dr = -rad; dr <= rad && v; dr++) {
        for (let dc = -rad; dc <= rad; dc++) {
          const rr = r + dr;
          const cc = c + dc;
          if (!inb(rr, cc)) continue;
          if (!dil[idxOf(rr, cc)]) {
            v = 0;
            break;
          }
        }
      }
      ero[idxOf(r, c)] = v;
    }
  }

  // 4) flood fill：只取「從邊界可達」的 light 區域當 walkable（避免 booth 內部白底被視為走道）
  const walkable = new Uint8Array(rows * cols); // 1 = walkable
  const q = new Int32Array(rows * cols);
  let qh = 0;
  let qt = 0;
  function push(i) {
    walkable[i] = 1;
    q[qt++] = i;
  }
  // 從四邊界把 ero==1 的格子當種子
  for (let c = 0; c < cols; c++) {
    const i1 = idxOf(0, c);
    const i2 = idxOf(rows - 1, c);
    if (ero[i1] && !walkable[i1]) push(i1);
    if (ero[i2] && !walkable[i2]) push(i2);
  }
  for (let r = 0; r < rows; r++) {
    const i1 = idxOf(r, 0);
    const i2 = idxOf(r, cols - 1);
    if (ero[i1] && !walkable[i1]) push(i1);
    if (ero[i2] && !walkable[i2]) push(i2);
  }
  while (qh < qt) {
    const i = q[qh++];
    const r = Math.floor(i / cols);
    const c = i - r * cols;
    const nb = [
      [r - 1, c],
      [r + 1, c],
      [r, c - 1],
      [r, c + 1],
    ];
    for (const [rr, cc] of nb) {
      if (!inb(rr, cc)) continue;
      const j = idxOf(rr, cc);
      if (walkable[j]) continue;
      if (!ero[j]) continue;
      push(j);
    }
  }

  // 5) 把 booth bbox 額外標成障礙（即使走道 flood fill 也不會走進去）
  const obstacles = new Uint8Array(rows * cols); // 1 = obstacle
  for (let i = 0; i < obstacles.length; i++) obstacles[i] = walkable[i] ? 0 : 1;
  const marginCells = 2;
  for (const booth of booths || []) {
    const bb = booth?.bbox;
    if (!bb) continue;
    const r1 = Math.max(0, Math.floor(bb.y1 / cellSizePx) - marginCells);
    const r2 = Math.min(rows - 1, Math.floor(bb.y2 / cellSizePx) + marginCells);
    const c1 = Math.max(0, Math.floor(bb.x1 / cellSizePx) - marginCells);
    const c2 = Math.min(cols - 1, Math.floor(bb.x2 / cellSizePx) + marginCells);
    for (let r = r1; r <= r2; r++) {
      for (let c = c1; c <= c2; c++) {
        obstacles[idxOf(r, c)] = 1;
      }
    }
  }

  return {
    rows,
    cols,
    cellSizePx,
    obstacleBitsetB64: packBitsetToBase64(obstacles),
  };
}

function overlapRatio(a1, a2, b1, b2) {
  const left = Math.max(a1, b1);
  const right = Math.min(a2, b2);
  const ov = Math.max(0, right - left);
  const lenA = Math.max(1, a2 - a1);
  const lenB = Math.max(1, b2 - b1);
  return ov / Math.min(lenA, lenB);
}

function boothIdFromText(text) {
  if (!text) return null;
  const t = String(text).trim();
  const s = t.replace(/\s+/g, "");

  // 目標格式：
  // - 列字母+編號（編號最多 3 位）：A01 / B103
  // - 無列字母：001 / 12 / 999
  // 支援常見分隔：A-01 / A_01 / A 01
  const m1 = s.match(/^([A-Za-z])[-_ ]?(\d{1,3})$/);
  if (m1) return `${m1[1].toUpperCase()}${m1[2]}`;
  const m2 = s.match(/^(\d{1,3})$/);
  if (m2) return m2[1];
  return null;
}

function buildLabelCandidates({ booths, ocrItems }) {
  const candidates = [];
  for (const b of booths || []) {
    const id = String(b?.id || "").trim();
    const bb = b?.bbox;
    if (!id || !bb) continue;
    candidates.push({
      id,
      bbox: bb,
      center: b?.center || bboxCenter(bb),
      score: Number(b?.score ?? 0.7),
      source: "booth",
    });
  }
  for (const it of ocrItems || []) {
    const id = boothIdFromText(it?.text);
    const bb = it?.bbox;
    if (!id || !bb) continue;
    candidates.push({
      id,
      bbox: bb,
      center: bboxCenter(bb),
      score: Number(it?.score ?? 0.5),
      source: "ocr",
    });
  }
  return candidates;
}

function assignLabelsToCells({ cells, booths, ocrItems }) {
  if (!Array.isArray(cells) || !cells.length) return;
  const labelCandidates = buildLabelCandidates({ booths, ocrItems });
  if (!labelCandidates.length) return;

  const distNorm = (cell, c) => {
    const cc = cell.center || bboxCenter(cell.bbox);
    const cw = Math.max(1, cell.bbox.x2 - cell.bbox.x1);
    const ch = Math.max(1, cell.bbox.y2 - cell.bbox.y1);
    const diag = Math.max(1, Math.sqrt(cw * cw + ch * ch));
    const dx = Number(cc.x) - Number(c.center?.x);
    const dy = Number(cc.y) - Number(c.center?.y);
    return Math.sqrt(dx * dx + dy * dy) / diag;
  };

  for (const c of labelCandidates) {
    let bestCell = null;
    let bestScore = -Infinity;
    for (const cell of cells) {
      const iou = iouOfBbox(cell.bbox, c.bbox);
      const inter = intersectArea(cell.bbox, c.bbox);
      const cArea = Math.max(1, bboxArea(c.bbox));
      const cover = inter / cArea;
      const d = distNorm(cell, c);
      const centerInside =
        c.center &&
        c.center.x >= cell.bbox.x1 &&
        c.center.x <= cell.bbox.x2 &&
        c.center.y >= cell.bbox.y1 &&
        c.center.y <= cell.bbox.y2
          ? 1
          : 0;
      const score = iou * 0.46 + cover * 0.24 + clamp01(1 - d / 3.2) * 0.2 + clamp01(c.score) * 0.07 + centerInside * 0.03;
      if (score > bestScore) {
        bestScore = score;
        bestCell = cell;
      }
    }
    if (!bestCell || bestScore < 0.22) continue;
    if (!bestCell.labelId || Number(bestCell.labelConfidence || 0) < bestScore) {
      bestCell.labelId = c.id;
      bestCell.labelConfidence = bestScore;
    }
  }
}

function parseBoothIdParts(id) {
  const s = String(id || "")
    .trim()
    .toUpperCase()
    .replace(/[\s\-_]/g, "");
  if (!s) return null;
  const m = s.match(/^([A-Z]?)(\d{1,3})$/);
  if (!m) return null;
  return { prefix: m[1] || "", num: Number(m[2]), rawNum: m[2] };
}

function normalizeBoothIdLoose(id) {
  const p = parseBoothIdParts(id);
  if (!p) return null;
  return `${p.prefix}${p.rawNum}`;
}

function buildIdAliases(id) {
  const base = normalizeBoothIdLoose(id);
  if (!base) return [];
  const out = new Set([base, base.toLowerCase()]);
  const p = parseBoothIdParts(base);
  if (p) {
    const compact = `${p.prefix}${p.num}`;
    out.add(compact);
    out.add(compact.toLowerCase());
    out.add(`${p.prefix}-${p.rawNum}`);
    out.add(`${p.prefix}_${p.rawNum}`);
    out.add(`${p.prefix} ${p.rawNum}`);
    if (p.prefix === "I") {
      out.add(`1${p.rawNum}`);
      out.add(`1${p.num}`);
    } else if (!p.prefix && /^1\d{1,3}$/.test(base)) {
      out.add(`I${base.slice(1)}`);
      out.add(`I${String(Number(base.slice(1)))}`);
    }
  }
  return Array.from(out);
}

function buildBoothIndex({ boothCells, booths, rowLetterAnchors }) {
  const cells = Array.isArray(boothCells) ? boothCells : [];
  const rawBooths = Array.isArray(booths) ? booths : [];
  const anchors = Array.isArray(rowLetterAnchors) ? rowLetterAnchors : [];
  const indexMap = new Map();
  const usedIds = new Set();
  const cellMap = new Map();
  for (const c of cells) {
    if (c?.key) cellMap.set(c.key, c);
  }

  const upsert = (entry) => {
    const guarded = applyPrefixGuardByRowAnchors(entry?.idCanonical, entry?.center || entry?.bbox, anchors);
    const id = normalizeBoothIdLoose(guarded.id);
    if (!id) return;
    const prev = indexMap.get(id);
    const guardedFrom = normalizeBoothIdLoose(entry?.idCanonical);
    const extraAliases = [];
    if (guarded.guarded && guardedFrom && guardedFrom !== id) extraAliases.push(guardedFrom);
    if (!prev || Number(entry.confidence || 0) > Number(prev.confidence || 0)) {
      indexMap.set(id, {
        idCanonical: id,
        aliases: Array.from(new Set([...(prev?.aliases || []), ...(entry.aliases || buildIdAliases(id)), ...extraAliases])),
        status: entry.status || prev?.status || "confirmed",
        confidence: Number(entry.confidence || 0),
        evidence: guarded.guarded ? `${entry.evidence || prev?.evidence || "ocr"}+prefix_guard` : entry.evidence || prev?.evidence || "ocr",
        cellId: entry.cellId || prev?.cellId || null,
        bbox: entry.bbox || prev?.bbox || null,
        center: entry.center || prev?.center || null,
        row: isFinite(entry.row) ? Number(entry.row) : prev?.row ?? null,
        col: isFinite(entry.col) ? Number(entry.col) : prev?.col ?? null,
      });
    }
    usedIds.add(id);
  };

  // 1) 優先使用 cell 上已貼標結果（最接近可點擊/可導航幾何）
  for (const c of cells) {
    const id = normalizeBoothIdLoose(c?.labelId || c?.id);
    if (!id) continue;
    upsert({
      idCanonical: id,
      aliases: buildIdAliases(id),
      status: "confirmed",
      confidence: Number(c?.labelConfidence || c?.cellScore || 0.65),
      evidence: "cell_label",
      cellId: c?.key || null,
      bbox: c?.bbox || null,
      center: c?.center || null,
      row: c?.row,
      col: c?.col,
    });
  }

  // 2) 補上 OCR booth（若 cell 未貼到）
  for (const b of rawBooths) {
    const id = normalizeBoothIdLoose(b?.id);
    if (!id) continue;
    upsert({
      idCanonical: id,
      aliases: buildIdAliases(id),
      status: "confirmed",
      confidence: Number(b?.score ?? 0.6),
      evidence: "ocr_booth",
      bbox: b?.bbox || null,
      center: b?.center || null,
    });
  }

  // 3) 在同 row 依序列規則推斷缺失號碼（inferred）
  const byRow = new Map();
  for (const c of cells) {
    if (!isFinite(c?.row) || !isFinite(c?.col)) continue;
    const r = Number(c.row);
    const arr = byRow.get(r) || [];
    arr.push(c);
    byRow.set(r, arr);
  }

  // 3-b) row 內插推斷：當 gap 與 col 不完全對齊時，仍用左右錨點估算缺失編號
  for (const [r, rowCells] of byRow.entries()) {
    rowCells.sort((a, b) => Number(a.col) - Number(b.col));
    const anchorsByPrefix = new Map();
    for (const c of rowCells) {
      const id = normalizeBoothIdLoose(c?.labelId || c?.id);
      const p = parseBoothIdParts(id);
      if (!p) continue;
      const arr = anchorsByPrefix.get(p.prefix) || [];
      arr.push({
        col: Number(c.col),
        num: Number(p.num),
        digits: String(p.rawNum || "").length || 2,
        confidence: Number(c?.labelConfidence || 0.6),
      });
      anchorsByPrefix.set(p.prefix, arr);
    }
    for (const [prefix, anchorsRaw] of anchorsByPrefix.entries()) {
      const anchors = anchorsRaw
        .filter((x) => isFinite(x.col) && isFinite(x.num))
        .sort((a, b) => a.col - b.col);
      if (anchors.length < 2) continue;
      const digitLen = Math.max(2, Math.round(median(anchors.map((x) => x.digits)) || 2));
      const nums = anchors.map((x) => x.num).filter((n) => isFinite(n));
      const minNum = Math.min(...nums);
      const maxNum = Math.max(...nums);
      for (const c of rowCells) {
        if (c?.labelId || c?.id) continue;
        const col = Number(c.col);
        if (!isFinite(col)) continue;
        let left = null;
        let right = null;
        for (let i = 0; i < anchors.length; i++) {
          const a = anchors[i];
          if (a.col <= col) left = a;
          if (a.col > col) {
            right = a;
            break;
          }
        }
        if (!left || !right) continue;
        const dCol = right.col - left.col;
        const dNum = right.num - left.num;
        if (!(dCol >= 1 && dNum >= 1)) continue;
        if (dNum > 20) continue;
        const t = (col - left.col) / Math.max(1, dCol);
        const numF = left.num + dNum * t;
        const numR = Math.round(numF);
        if (numR < minNum || numR > maxNum) continue;
        if (Math.abs(numR - numF) > 0.42) continue;
        const inferredId = `${prefix}${String(numR).padStart(digitLen, "0")}`;
        if (usedIds.has(inferredId)) continue;
        upsert({
          idCanonical: inferredId,
          aliases: buildIdAliases(inferredId),
          status: "inferred",
          confidence: Math.min(left.confidence, right.confidence) * 0.62,
          evidence: "row_interp_infer",
          cellId: c?.key || null,
          bbox: c?.bbox || null,
          center: c?.center || null,
          row: c?.row,
          col: c?.col,
        });
      }
    }
  }
  for (const [r, rowCells] of byRow.entries()) {
    rowCells.sort((a, b) => Number(a.col) - Number(b.col));
    for (let i = 0; i < rowCells.length - 1; i++) {
      const a = rowCells[i];
      const b = rowCells[i + 1];
      const aid = normalizeBoothIdLoose(a?.labelId || a?.id);
      const bid = normalizeBoothIdLoose(b?.labelId || b?.id);
      if (!aid || !bid) continue;
      const ap = parseBoothIdParts(aid);
      const bp = parseBoothIdParts(bid);
      if (!ap || !bp) continue;
      if (ap.prefix !== bp.prefix) continue;
      if (!(bp.num > ap.num)) continue;
      const numGap = bp.num - ap.num - 1;
      const colGap = Number(b.col) - Number(a.col) - 1;
      if (numGap <= 0 || colGap <= 0) continue;
      if (numGap !== colGap) continue;
      if (numGap > 4) continue;
      const confBase = Math.min(Number(a?.labelConfidence || 0.6), Number(b?.labelConfidence || 0.6)) * 0.72;
      for (let k = 1; k <= numGap; k++) {
        const c = rowCells[i + k];
        if (!c || c?.labelId || c?.id) continue;
        const inferredId = `${ap.prefix}${String(ap.num + k).padStart(ap.rawNum.length, "0")}`;
        if (usedIds.has(inferredId)) continue;
        upsert({
          idCanonical: inferredId,
          aliases: buildIdAliases(inferredId),
          status: "inferred",
          confidence: confBase,
          evidence: "row_gap_infer",
          cellId: c?.key || null,
          bbox: c?.bbox || null,
          center: c?.center || null,
          row: c?.row,
          col: c?.col,
        });
      }
    }
  }

  // 4) 仍未貼標的格子，產生可回補的 unresolved 入口
  for (const c of cells) {
    const id = normalizeBoothIdLoose(c?.labelId || c?.id);
    if (id) continue;
    const rid = `R${Number(c?.row) || 0}C${Number(c?.col) || 0}`;
    if (indexMap.has(rid)) continue;
    indexMap.set(rid, {
      idCanonical: rid,
      aliases: [rid],
      status: "unresolved",
      confidence: Number(c?.cellScore || 0),
      evidence: "cell_only",
      cellId: c?.key || null,
      bbox: c?.bbox || null,
      center: c?.center || null,
      row: isFinite(c?.row) ? Number(c.row) : null,
      col: isFinite(c?.col) ? Number(c.col) : null,
    });
  }

  const boothIndex = Array.from(indexMap.values()).sort((a, b) => String(a.idCanonical).localeCompare(String(b.idCanonical)));
  const rowNumberMap = {};
  for (let i = 0; i < 26; i++) rowNumberMap[String.fromCharCode(65 + i)] = [];
  for (const it of boothIndex) {
    const p = parseBoothIdParts(it?.idCanonical);
    if (!p || !p.prefix || !rowNumberMap[p.prefix]) continue;
    if (it?.status === "unresolved") continue;
    rowNumberMap[p.prefix].push(String(p.rawNum || p.num));
  }
  for (const k of Object.keys(rowNumberMap)) {
    rowNumberMap[k] = Array.from(new Set(rowNumberMap[k])).sort((a, b) => Number(a) - Number(b));
  }
  const stats = {
    total: boothIndex.length,
    confirmed: boothIndex.filter((x) => x.status === "confirmed").length,
    inferred: boothIndex.filter((x) => x.status === "inferred").length,
    unresolved: boothIndex.filter((x) => x.status === "unresolved").length,
  };
  return { boothIndex, stats, rowNumberMap };
}

function cropRgbaToPngBase64({ rgba, width, height, bbox }) {
  const x1 = clampInt(Math.floor(Number(bbox?.x1 || 0)), 0, width - 1);
  const y1 = clampInt(Math.floor(Number(bbox?.y1 || 0)), 0, height - 1);
  const x2 = clampInt(Math.ceil(Number(bbox?.x2 || 0)), 0, width - 1);
  const y2 = clampInt(Math.ceil(Number(bbox?.y2 || 0)), 0, height - 1);
  const cw = Math.max(1, x2 - x1 + 1);
  const ch = Math.max(1, y2 - y1 + 1);
  const png = new PNG({ width: cw, height: ch });
  for (let y = 0; y < ch; y++) {
    for (let x = 0; x < cw; x++) {
      const sx = x1 + x;
      const sy = y1 + y;
      const sIdx = (sy * width + sx) * 4;
      const dIdx = (y * cw + x) * 4;
      png.data[dIdx] = rgba[sIdx];
      png.data[dIdx + 1] = rgba[sIdx + 1];
      png.data[dIdx + 2] = rgba[sIdx + 2];
      png.data[dIdx + 3] = rgba[sIdx + 3];
    }
  }
  const buf = PNG.sync.write(png);
  return { imageBase64: buf.toString("base64"), crop: { x1, y1, x2, y2, width: cw, height: ch } };
}

function chooseRowsForSecondaryOcr(cells, maxRows = 4) {
  const byRow = new Map();
  for (const c of cells || []) {
    if (!isFinite(c?.row)) continue;
    const r = Number(c.row);
    const arr = byRow.get(r) || [];
    arr.push(c);
    byRow.set(r, arr);
  }
  const ranked = [];
  for (const [row, arr] of byRow.entries()) {
    const total = arr.length;
    const labeled = arr.filter((c) => !!normalizeBoothIdLoose(c?.labelId || c?.id)).length;
    const unlabeled = total - labeled;
    if (unlabeled <= 0) continue;
    if (total < 3) continue;
    const knownPrefix = (() => {
      const cnt = new Map();
      for (const c of arr) {
        const p = parseBoothIdParts(normalizeBoothIdLoose(c?.labelId || c?.id));
        if (!p?.prefix) continue;
        cnt.set(p.prefix, (cnt.get(p.prefix) || 0) + 1);
      }
      let best = null;
      let n = 0;
      for (const [k, v] of cnt.entries()) {
        if (v > n) {
          n = v;
          best = k;
        }
      }
      return best;
    })();
    if (!knownPrefix) continue;
    const ratio = unlabeled / Math.max(1, total);
    const priority = unlabeled * 2 + ratio * 3 + (labeled >= 2 ? 1 : 0);
    ranked.push({ row, cells: arr, labeled, unlabeled, ratio, knownPrefix, priority });
  }
  ranked.sort((a, b) => b.priority - a.priority);
  return ranked.slice(0, Math.max(1, Math.min(8, Number(maxRows) || 4)));
}

async function enrichBoothCellsBySecondaryOcr({
  boothCells,
  rgba,
  width,
  height,
  secretId,
  secretKey,
  region,
  maxRows = 4,
}) {
  const cells = Array.isArray(boothCells) ? boothCells : [];
  if (!cells.length) return { boothCells: cells, debug: { enabled: false, reason: "no_cells" } };
  const rows = chooseRowsForSecondaryOcr(cells, maxRows);
  if (!rows.length) return { boothCells: cells, debug: { enabled: true, rowsTried: 0, assigned: 0 } };

  let assigned = 0;
  const debugRows = [];
  for (const r of rows) {
    const xs1 = r.cells.map((c) => Number(c?.bbox?.x1)).filter((v) => isFinite(v));
    const ys1 = r.cells.map((c) => Number(c?.bbox?.y1)).filter((v) => isFinite(v));
    const xs2 = r.cells.map((c) => Number(c?.bbox?.x2)).filter((v) => isFinite(v));
    const ys2 = r.cells.map((c) => Number(c?.bbox?.y2)).filter((v) => isFinite(v));
    if (!xs1.length || !ys1.length || !xs2.length || !ys2.length) continue;
    const padX = 18;
    const padY = 14;
    const roi = {
      x1: Math.max(0, Math.min(...xs1) - padX),
      y1: Math.max(0, Math.min(...ys1) - padY),
      x2: Math.min(width - 1, Math.max(...xs2) + padX),
      y2: Math.min(height - 1, Math.max(...ys2) + padY),
    };
    let rowItems = [];
    try {
      const crop = cropRgbaToPngBase64({ rgba, width, height, bbox: roi });
      const resp = await callTencentGeneralAccurateOCR({
        secretId,
        secretKey,
        region,
        imageBase64: crop.imageBase64,
      });
      rowItems = toOcrItemsFromTencent(resp);
    } catch (e) {
      debugRows.push({ row: r.row, prefix: r.knownPrefix, error: e?.code || e?.message || "SECONDARY_OCR_FAIL" });
      continue;
    }

    const rowCells = r.cells.slice().sort((a, b) => Number(a.col) - Number(b.col));
    const usedCellKey = new Set();
    const usedIds = new Set(
      rowCells
        .map((c) => normalizeBoothIdLoose(c?.labelId || c?.id))
        .filter(Boolean)
        .map((x) => String(x).toUpperCase())
    );
    const digitLen = (() => {
      const lens = rowCells
        .map((c) => parseBoothIdParts(normalizeBoothIdLoose(c?.labelId || c?.id)))
        .filter(Boolean)
        .map((p) => String(p.rawNum || "").length || 2);
      return Math.max(2, Math.round(median(lens) || 2));
    })();

    const tokens = [];
    for (const it of rowItems) {
      const bb = it?.bbox;
      if (!bb) continue;
      let parts = [];
      const direct = boothIdFromText(it.text);
      const p = parseBoothIdParts(direct);
      if (p && (!p.prefix || p.prefix === r.knownPrefix)) {
        parts = [String(p.rawNum)];
      } else {
        const d = isDigitsOnlyToken(it.text);
        if (d) parts = [d];
        else {
          const merged = splitMergedDigitsToken(it.text);
          if (merged) parts = merged;
        }
      }
      if (!parts.length) continue;
      const bbs = parts.length > 1 ? splitBboxHorizontally(bb, parts.length) : [bb];
      for (let i = 0; i < parts.length; i++) {
        const n = String(parts[i] || "").trim();
        if (!/^\d{1,3}$/.test(n)) continue;
        const b = bbs[i];
        const cx = roi.x1 + (Number(b.x1) + Number(b.x2)) / 2;
        const cy = roi.y1 + (Number(b.y1) + Number(b.y2)) / 2;
        tokens.push({
          digits: n,
          cx,
          cy,
          score: Number(it?.score ?? 0.5),
        });
      }
    }

    let rowAssigned = 0;
    for (const t of tokens) {
      let bestCell = null;
      let bestScore = -Infinity;
      for (const c of rowCells) {
        if (c?.labelId || c?.id) continue;
        if (usedCellKey.has(String(c?.key || ""))) continue;
        const cc = c?.center || bboxCenter(c?.bbox);
        const bb = c?.bbox;
        if (!cc || !bb) continue;
        const cw = Math.max(1, Number(bb.x2) - Number(bb.x1));
        const ch = Math.max(1, Number(bb.y2) - Number(bb.y1));
        const dx = Math.abs(Number(cc.x) - Number(t.cx));
        const dy = Math.abs(Number(cc.y) - Number(t.cy));
        if (dx > cw * 1.1 || dy > ch * 0.9) continue;
        const sc = clamp01(1 - dx / (cw * 1.15)) * 0.62 + clamp01(1 - dy / (ch * 0.95)) * 0.18 + clamp01(t.score) * 0.2;
        if (sc > bestScore) {
          bestScore = sc;
          bestCell = c;
        }
      }
      if (!bestCell || bestScore < 0.28) continue;
      const id = `${r.knownPrefix}${String(t.digits).padStart(digitLen, "0")}`;
      if (usedIds.has(String(id).toUpperCase())) continue;
      bestCell.labelId = id;
      bestCell.labelConfidence = Math.max(Number(bestCell.labelConfidence || 0), bestScore * 0.78);
      usedCellKey.add(String(bestCell.key || ""));
      usedIds.add(String(id).toUpperCase());
      rowAssigned++;
      assigned++;
    }
    debugRows.push({
      row: r.row,
      prefix: r.knownPrefix,
      unlabeledBefore: r.unlabeled,
      tokens: tokens.length,
      assigned: rowAssigned,
    });
  }
  return {
    boothCells: cells,
    debug: {
      enabled: true,
      rowsTried: rows.length,
      assigned,
      rows: debugRows,
    },
  };
}

function isLettersOnlyToken(text) {
  const s = String(text || "").trim().replace(/\s+/g, "");
  if (!s) return null;
  const m = s.match(/^([A-Za-z])$/);
  return m ? m[1].toUpperCase() : null;
}

function asLetterToken(text, bbox) {
  // 一般字母
  const letter = isLettersOnlyToken(text);
  if (letter) return letter;
  // 針對常見誤辨：列字母 I 被辨成 1
  // 只在「單字元=1」且 bbox 形狀像細長直條時，把它視為 I
  const s = String(text || "").trim().replace(/\s+/g, "");
  if (s !== "1") return null;
  if (!bbox) return null;
  const w = Math.max(1, bbox.x2 - bbox.x1);
  const h = Math.max(1, bbox.y2 - bbox.y1);
  const ratio = h / w;
  return ratio >= 2.2 ? "I" : null;
}

function isDigitsOnlyToken(text) {
  const s = String(text || "").trim().replace(/\s+/g, "");
  if (!s) return null;
  const m = s.match(/^(\d{1,3})$/);
  return m ? m[1] : null;
}

function splitMergedDigitsToken(text) {
  // 常見誤辨：兩個攤位號太近 → OCR 黏成 4~6 位數，例如 2322(=23,22)、3510(=35,10)、141212(=14,12,12)
  const s = String(text || "").trim().replace(/\s+/g, "");
  if (!s) return null;
  if (!/^\d{4,6}$/.test(s)) return null;

  // 優先切成 2+2（長度4）或 3+3（長度6）
  if (s.length === 4) return [s.slice(0, 2), s.slice(2, 4)];
  if (s.length === 6) return [s.slice(0, 3), s.slice(3, 6)];

  // 長度5：嘗試 2+3 或 3+2，挑「兩段都像合法攤位號」者
  const a = [s.slice(0, 2), s.slice(2, 5)];
  const b = [s.slice(0, 3), s.slice(3, 5)];
  const ok = (parts) => parts.every((p) => /^\d{1,3}$/.test(p));
  if (ok(a)) return a;
  if (ok(b)) return b;
  return null;
}

function splitBboxHorizontally(bbox, partsCount) {
  // 將一個寬 bbox 平均切成 N 段（MVP：等分；若日後拿到逐字座標可做更精準切割）
  const w = Math.max(1, bbox.x2 - bbox.x1);
  const seg = w / partsCount;
  const res = [];
  for (let i = 0; i < partsCount; i++) {
    const x1 = bbox.x1 + seg * i;
    const x2 = i === partsCount - 1 ? bbox.x2 : bbox.x1 + seg * (i + 1);
    res.push({ x1, y1: bbox.y1, x2, y2: bbox.y2 });
  }
  return res;
}

function findBestLetterForNumber(numItem, letterItems) {
  // numItem: {digits, bbox}
  const nb = numItem.bbox;
  const nC = bboxCenter(nb);
  const nW = Math.max(1, nb.x2 - nb.x1);
  const nH = Math.max(1, nb.y2 - nb.y1);
  const nArea = Math.max(1, nW * nH);

  let best = null;
  let bestScore = Infinity;

  for (const li of letterItems) {
    const lb = li.bbox;
    const lC = bboxCenter(lb);
    const lW = Math.max(1, lb.x2 - lb.x1);
    const lH = Math.max(1, lb.y2 - lb.y1);
    const lArea = Math.max(1, lW * lH);

    const dx = Math.abs(lC.x - nC.x);
    const dy = Math.abs(lC.y - nC.y);

    // 排除「列標籤」這種超大單字母框：它們不該拿來配對攤位號
    // - 面積遠大於數字框（常見 10x~100x）
    // - 高度遠大於數字框
    if (lArea >= nArea * 6 || lH >= nH * 3.2 || lW >= nW * 3.2) continue;

    // 以「數字框尺寸」來界定可接受距離，避免字母框越大就放寬越多的問題
    const maxDx = Math.max(18, 3.2 * nW + 12);
    const maxDy = Math.max(18, 1.8 * nH + 12);

    // 兩種常見佈局：
    // - 字母在數字左側（同一行）
    // - 字母在數字上方（同一列）
    const yOverlap = overlapRatio(lb.y1, lb.y2, nb.y1, nb.y2);
    const xOverlap = overlapRatio(lb.x1, lb.x2, nb.x1, nb.x2);

    let score = null;
    if (yOverlap >= 0.3 && lC.x < nC.x && dx <= maxDx && dy <= maxDy) {
      score = dx + 2 * dy; // 偏好水平對齊
    } else {
      // 次選：垂直對齊（上方），允許稍大 dy，但仍以數字框尺度限制
      const maxDx2 = Math.max(18, 1.8 * nW + 12);
      const maxDy2 = Math.max(18, 3.2 * nH + 12);
      if (xOverlap >= 0.3 && lC.y < nC.y && dx <= maxDx2 && dy <= maxDy2) {
        score = dy + 2 * dx;
      }
    }

    if (score != null && score < bestScore) {
      bestScore = score;
      best = li;
    }
  }

  return best ? best.letter : null;
}

function buildRowLetterAnchors({ letterItems, numItems }) {
  const letters = (letterItems || []).filter((li) => li?.bbox && li?.letter);
  if (!letters.length) return [];
  const numHeights = (numItems || [])
    .map((n) => Math.max(1, Number(n?.bbox?.y2) - Number(n?.bbox?.y1)))
    .filter((v) => isFinite(v) && v > 0);
  const nH = median(numHeights) || 16;

  // 過大單字母多半是裝飾/標題，不作為列錨點
  const candidates = letters
    .map((li) => {
      const bb = li.bbox;
      const h = Math.max(1, Number(bb.y2) - Number(bb.y1));
      const w = Math.max(1, Number(bb.x2) - Number(bb.x1));
      return {
        ...li,
        x: (Number(bb.x1) + Number(bb.x2)) / 2,
        y: (Number(bb.y1) + Number(bb.y2)) / 2,
        w,
        h,
      };
    })
    .filter((li) => li.h <= Math.max(28, nH * 4.6) && li.w <= Math.max(26, nH * 3.6));
  if (!candidates.length) return [];

  candidates.sort((a, b) => a.y - b.y);
  const groups = [];
  const gapThr = Math.max(24, nH * 2.2);
  for (const it of candidates) {
    const last = groups[groups.length - 1];
    if (!last || Math.abs(it.y - last.cy) > gapThr) {
      groups.push({ items: [it], cy: it.y });
    } else {
      last.items.push(it);
      last.cy = last.items.reduce((acc, x) => acc + x.y, 0) / last.items.length;
    }
  }

  // 每個 y-band 內，依 x 去重（同欄重覆 OCR 只保留分數較高者）
  const out = [];
  const rankOf = (ch) => {
    const s = String(ch || "").toUpperCase();
    if (!/^[A-Z]$/.test(s)) return null;
    return s.charCodeAt(0) - 65;
  };
  for (const g of groups) {
    const sorted = g.items.slice().sort((a, b) => a.x - b.x);
    const dedup = [];
    for (const it of sorted) {
      const last = dedup[dedup.length - 1];
      if (!last || Math.abs(it.x - last.x) > Math.max(10, nH * 1.2)) {
        dedup.push(it);
      } else if (Number(it.score || 0) > Number(last.score || 0)) {
        dedup[dedup.length - 1] = it;
      }
    }
    const dxs = [];
    for (let i = 1; i < dedup.length; i++) dxs.push(dedup[i].x - dedup[i - 1].x);
    const spacing = median(dxs.filter((v) => isFinite(v) && v > 4)) || 36;
    let model = null;
    if (dedup.length >= 3) {
      const pts = dedup
        .map((it) => ({ x: Number(it.x), r: rankOf(it.letter) }))
        .filter((p) => isFinite(p.x) && isFinite(p.r));
      if (pts.length >= 3) {
        const n = pts.length;
        let sumX = 0, sumR = 0, sumXX = 0, sumXR = 0;
        for (const p of pts) {
          sumX += p.x;
          sumR += p.r;
          sumXX += p.x * p.x;
          sumXR += p.x * p.r;
        }
        const den = n * sumXX - sumX * sumX;
        if (Math.abs(den) > 1e-6) {
          const a = (n * sumXR - sumX * sumR) / den;
          const b = (sumR - a * sumX) / n;
          model = { a, b };
        }
      }
    }
    out.push({
      cy: g.cy,
      spacing,
      itemH: median(dedup.map((x) => x.h)) || nH,
      model,
      items: dedup,
    });
  }
  return out;
}

function pickLetterByRowAnchors(numItem, rowAnchors) {
  if (!numItem?.bbox || !Array.isArray(rowAnchors) || !rowAnchors.length) return null;
  const nb = numItem.bbox;
  const ny = (Number(nb.y1) + Number(nb.y2)) / 2;
  const nx = (Number(nb.x1) + Number(nb.x2)) / 2;

  // 優先挑絕對最近 row band，且要求 y 距離在可接受範圍
  let bestBand = null;
  let bestDy = Infinity;
  for (const b of rowAnchors) {
    const dy = Math.abs(ny - Number(b.cy || 0));
    if (dy < bestDy) {
      bestDy = dy;
      bestBand = b;
    }
  }
  if (!bestBand?.items?.length) return null;
  const maxBandDy = Math.max(36, Number(bestBand.itemH || 16) * 7.5);
  if (bestDy > maxBandDy) return null;

  let best = null;
  let bestDx = Infinity;
  for (const it of bestBand.items) {
    const dx = Math.abs(nx - Number(it.x || 0));
    if (dx < bestDx) {
      bestDx = dx;
      best = it;
    }
  }
  if (!best) return null;
  const maxDx = Math.max(18, Number(bestBand.spacing || 36) * 0.78);
  if (bestDx <= maxDx && best?.letter) return best.letter;

  // 若最近字母太遠，改用 band 內 x->字母序線性模型估測（處理 OCR 漏掉部份列字母）
  const m = bestBand.model;
  if (m && isFinite(m.a) && isFinite(m.b)) {
    const pred = Math.round(m.a * nx + m.b);
    if (pred >= 0 && pred <= 25) return String.fromCharCode(65 + pred);
  }
  return null;
}

function applyPrefixGuardByRowAnchors(id, bboxOrCenter, rowAnchors) {
  const norm = normalizeBoothIdLoose(id);
  if (!norm || !Array.isArray(rowAnchors) || !rowAnchors.length) {
    return { id: norm || null, guarded: false, anchorPrefix: null };
  }
  const p = parseBoothIdParts(norm);
  if (!p) return { id: norm, guarded: false, anchorPrefix: null };

  let probe = null;
  if (bboxOrCenter?.x1 != null && bboxOrCenter?.y1 != null && bboxOrCenter?.x2 != null && bboxOrCenter?.y2 != null) {
    probe = { bbox: bboxOrCenter };
  } else if (bboxOrCenter?.x != null && bboxOrCenter?.y != null) {
    const cx = Number(bboxOrCenter.x);
    const cy = Number(bboxOrCenter.y);
    if (isFinite(cx) && isFinite(cy)) {
      // 用極小 bbox 讓既有 row-anchor 選帶邏輯重用
      probe = { bbox: { x1: cx - 0.5, y1: cy - 0.5, x2: cx + 0.5, y2: cy + 0.5 } };
    }
  }
  if (!probe?.bbox) return { id: norm, guarded: false, anchorPrefix: null };
  const anchorPrefix = pickLetterByRowAnchors(probe, rowAnchors);
  if (!anchorPrefix) return { id: norm, guarded: false, anchorPrefix: null };

  const guardedId = `${anchorPrefix}${p.rawNum}`;
  return {
    id: guardedId,
    guarded: guardedId !== norm,
    anchorPrefix,
  };
}

async function maybeDownscale(buffer) {
  // 已停用雲函數端縮圖：避免 native 依賴造成崩潰
  return { buffer, meta: null, transformed: false, originalBytes: Buffer.byteLength(buffer) };
}

async function callTencentGeneralAccurateOCR({ secretId, secretKey, region, imageBase64 }) {
  const OcrClient = tencentcloud.ocr.v20181119.Client;
  const client = new OcrClient({
    credential: { secretId, secretKey },
    region,
    profile: {
      httpProfile: {
        endpoint: "ocr.tencentcloudapi.com",
        // SDK 內部通常使用秒級超時；此值越大越不容易在大圖下被打斷，但也要考量雲函數超時
        reqTimeout: 60,
      },
    },
  });

  // 依官方文檔：Action=GeneralAccurateOCR, Version=2018-11-19
  // https://cloud.tencent.com/document/product/866/34937
  const params = {
    ImageBase64: imageBase64,
  };

  return await client.GeneralAccurateOCR(params);
}

function toOcrItemsFromTencent(resp) {
  const detections = resp?.TextDetections || [];
  const items = [];
  for (const det of detections) {
    const text = det?.DetectedText ?? "";
    const conf = Number(det?.Confidence ?? 0);
    let polygon = det?.Polygon;
    if (!Array.isArray(polygon) || polygon.length < 4) {
      const ip = det?.ItemPolygon;
      if (ip) {
        const x = Number(ip.X ?? 0);
        const y = Number(ip.Y ?? 0);
        const w = Number(ip.Width ?? 0);
        const h = Number(ip.Height ?? 0);
        polygon = [
          { X: x, Y: y },
          { X: x + w, Y: y },
          { X: x + w, Y: y + h },
          { X: x, Y: y + h },
        ];
      } else {
        polygon = null;
      }
    }
    const bbox = normalizePolygonToBbox(polygon);
    if (!bbox) continue;
    items.push({
      text: String(text),
      score: isFinite(conf) ? conf / 100 : null,
      polygon,
      bbox,
    });
  }
  return items;
}

function enhanceRgbaForText(rgba, width, height) {
  const out = new Uint8Array(width * height * 4);
  const n = width * height;
  let sum = 0;
  for (let i = 0; i < n; i++) {
    const idx = i * 4;
    const r = rgba[idx];
    const g = rgba[idx + 1];
    const b = rgba[idx + 2];
    const y = Math.round(lumOf(r, g, b));
    sum += y;
  }
  const mean = sum / Math.max(1, n);
  const t1 = Math.max(95, mean - 22);
  const t2 = Math.min(210, mean + 18);
  for (let i = 0; i < n; i++) {
    const idx = i * 4;
    const r = rgba[idx];
    const g = rgba[idx + 1];
    const b = rgba[idx + 2];
    const a = rgba[idx + 3];
    let y = lumOf(r, g, b);
    // 拉高文字邊界對比，讓小字更容易被 OCR 擷取
    if (y <= t1) y = 0;
    else if (y >= t2) y = 255;
    else y = ((y - t1) / Math.max(1, t2 - t1)) * 255;
    const yy = clampInt(Math.round(y), 0, 255);
    out[idx] = yy;
    out[idx + 1] = yy;
    out[idx + 2] = yy;
    out[idx + 3] = a;
  }
  return out;
}

function rgbaToPngBase64(rgba, width, height) {
  const png = new PNG({ width, height });
  png.data = Buffer.from(rgba);
  return PNG.sync.write(png).toString("base64");
}

function isSameText(a, b) {
  const x = String(a || "").trim().replace(/\s+/g, "").toUpperCase();
  const y = String(b || "").trim().replace(/\s+/g, "").toUpperCase();
  return !!x && x === y;
}

function mergeOcrItems(primary, secondary) {
  const out = (primary || []).slice();
  for (const s of secondary || []) {
    const bb = s?.bbox;
    if (!bb) continue;
    let dup = false;
    for (const p of out) {
      if (!p?.bbox) continue;
      const iou = iouOfBbox(p.bbox, bb);
      const ia = intersectArea(p.bbox, bb);
      const sa = Math.max(1, bboxArea(bb));
      const cover = ia / sa;
      if (iou >= 0.7 || (cover >= 0.82 && isSameText(p.text, s.text))) {
        dup = true;
        // 保留較高分數版本
        if (Number(s.score || 0) > Number(p.score || 0)) {
          p.text = s.text;
          p.score = s.score;
          p.bbox = s.bbox;
          p.polygon = s.polygon;
        }
        break;
      }
    }
    if (!dup) out.push(s);
  }
  return out;
}

function offsetOcrItems(items, dx, dy) {
  const ox = Number(dx || 0);
  const oy = Number(dy || 0);
  return (items || []).map((it) => {
    const bb = it?.bbox;
    if (!bb) return it;
    const poly = Array.isArray(it?.polygon)
      ? it.polygon.map((p) => ({
          X: Number(p?.X ?? p?.x ?? 0) + ox,
          Y: Number(p?.Y ?? p?.y ?? 0) + oy,
        }))
      : it?.polygon;
    return {
      ...it,
      polygon: poly,
      bbox: {
        x1: Number(bb.x1) + ox,
        y1: Number(bb.y1) + oy,
        x2: Number(bb.x2) + ox,
        y2: Number(bb.y2) + oy,
      },
    };
  });
}

function computeVerticalBandStats(ocrItems, imageHeight, bands = 6) {
  const h = Number(imageHeight || 0);
  const n = Math.max(3, Math.min(12, Number(bands || 6)));
  if (!(h > 0)) return [];
  const stats = Array.from({ length: n }, (_, i) => ({
    band: i,
    y1: Math.floor((i * h) / n),
    y2: Math.min(h - 1, Math.ceil(((i + 1) * h) / n) - 1),
    count: 0,
  }));
  for (const it of ocrItems || []) {
    const bb = it?.bbox;
    if (!bb) continue;
    const cy = (Number(bb.y1) + Number(bb.y2)) / 2;
    if (!isFinite(cy)) continue;
    let bi = Math.floor((cy / h) * n);
    bi = Math.max(0, Math.min(n - 1, bi));
    stats[bi].count += 1;
  }
  return stats;
}

function pickWeakVerticalBands(stats, { maxBands = 2, ratio = 0.42, minCount = 14 } = {}) {
  const arr = Array.isArray(stats) ? stats : [];
  if (!arr.length) return [];
  const counts = arr.map((x) => Number(x.count || 0));
  const avg = counts.reduce((a, b) => a + b, 0) / Math.max(1, counts.length);
  const weak = arr
    .filter((x) => Number(x.count || 0) <= Math.max(minCount, avg * ratio))
    // 先補下半部（你目前問題集中在下半區）
    .sort((a, b) => {
      if (b.band !== a.band) return b.band - a.band;
      return Number(a.count || 0) - Number(b.count || 0);
    });
  return weak.slice(0, Math.max(1, Math.min(4, Number(maxBands || 2))));
}

async function runBandSecondaryOcr({
  rgba,
  width,
  height,
  ocrItems,
  secretId,
  secretKey,
  region,
  bandCount = 6,
  maxBands = 2,
  tileCols = 2,
}) {
  if (!rgba || !(width > 0 && height > 0)) {
    return { items: [], debug: { enabled: false, reason: "invalid_image" } };
  }
  const stats = computeVerticalBandStats(ocrItems, height, bandCount);
  const weakBands = pickWeakVerticalBands(stats, { maxBands, ratio: 0.42, minCount: 14 });
  if (!weakBands.length) {
    return { items: [], debug: { enabled: true, reason: "no_weak_band", bands: stats, selected: [] } };
  }
  const enhanced = enhanceRgbaForText(rgba, width, height);
  const out = [];
  const selected = [];
  for (const b of weakBands) {
    const padY = 22;
    const y1 = Math.max(0, Number(b.y1) - padY);
    const y2 = Math.min(height - 1, Number(b.y2) + padY);
    const cols = Math.max(1, Math.min(4, Number(tileCols || 2)));
    const tileW = width / cols;
    for (let ci = 0; ci < cols; ci++) {
      const padX = 14;
      const roi = {
        x1: Math.max(0, Math.floor(ci * tileW) - padX),
        y1,
        x2: Math.min(width - 1, Math.ceil((ci + 1) * tileW) + padX),
        y2,
      };
      try {
        const crop = cropRgbaToPngBase64({ rgba: enhanced, width, height, bbox: roi });
        const resp = await callTencentGeneralAccurateOCR({
          secretId,
          secretKey,
          region,
          imageBase64: crop.imageBase64,
        });
        const localItems = toOcrItemsFromTencent(resp);
        const shifted = offsetOcrItems(localItems, roi.x1, roi.y1);
        out.push(...shifted);
        selected.push({
          band: b.band,
          tile: ci,
          before: b.count,
          x1: roi.x1,
          x2: roi.x2,
          y1: roi.y1,
          y2: roi.y2,
          detections: Number(resp?.TextDetections?.length || 0),
          items: shifted.length,
        });
      } catch (e) {
        selected.push({
          band: b.band,
          tile: ci,
          before: b.count,
          x1: roi.x1,
          x2: roi.x2,
          y1: roi.y1,
          y2: roi.y2,
          error: e?.code || e?.message || "BAND_SECONDARY_OCR_FAIL",
        });
      }
    }
  }
  return {
    items: out,
    debug: {
      enabled: true,
      bands: stats,
      selected,
      added: out.length,
    },
  };
}

exports.main = async (event) => {
  try {
    let fileID = event?.fileID;
    const gridCellPx = Number(event?.gridCellPx || 16);
    // 依使用者要求：環境變數改用 SecretId / SecretKey
    // 同時保留舊鍵名作為相容備援（避免既有環境尚未調整）
    const secretId = process.env.SecretId || process.env.TENCENT_SECRET_ID;
    const secretKey = process.env.SecretKey || process.env.TENCENT_SECRET_KEY;
    const region = process.env.TENCENT_OCR_REGION || TENCENT_OCR_REGION || "ap-guangzhou";
    if (!secretId || !secretKey) {
      return {
        ok: false,
        error: "缺少騰訊雲金鑰（請在雲函數環境變數設定 SecretId / SecretKey）",
        code: "MISSING_TENCENT_SECRET",
        // CloudBase API Key（CLOUDBASE_APIKEY）不等於騰訊雲 SecretKey，僅作提示
        hasCloudbaseApiKey: !!process.env.CLOUDBASE_APIKEY,
      };
    }

    // 若未提供 fileID，允許用 QR/URL 匯入
    let imported = null;
    if (!fileID && (event?.qr || event?.qrText || event?.url)) {
      const parsed = event?.url ? { type: "url", value: event.url } : parseQrPayload(event.qr || event.qrText);
      if (parsed.type === "fileID") {
        fileID = parsed.value;
      } else if (parsed.type === "url") {
        imported = await importFromUrlToCloudStorage(parsed.value);
        fileID = imported.fileID;
      } else if (parsed.type === "empty") {
        return { ok: false, error: "QR 內容為空", code: "EMPTY_QR" };
      } else {
        return { ok: false, error: "不支援的 QR 內容（請提供圖片 URL 或 fileID）", code: "UNSUPPORTED_QR", raw: parsed.value };
      }
    }

    if (!fileID) return { ok: false, error: "缺少 fileID（或提供 qr/url 以匯入）", code: "MISSING_FILEID" };

    // 若只想匯入不解析（例如掃碼後先預覽），可傳 importOnly=true
    if (event?.importOnly) {
      return {
        ok: true,
        data: {
          fileID,
          source: imported ? "url" : "fileID",
          imported: imported ? { bytes: imported.bytes, contentType: imported.contentType } : null,
        },
      };
    }

    // 出網預檢（可用 event.skipPreflight=true 略過）
    if (!event?.skipPreflight) {
      try {
        await networkPreflight("ocr.tencentcloudapi.com", 3500);
      } catch (e) {
        return {
          ok: false,
          error: "雲函數可能無法出網或無法解析 ocr.tencentcloudapi.com（請檢查網路策略/安全設置）",
          code: e?.message || "NETWORK_PREFLIGHT_FAILED",
        };
      }
    }

    // 下載圖片到 Buffer（若剛從 URL 匯入，優先用 imported.buffer 省一次下載）
    let buffer = imported?.buffer;
    if (!buffer) {
      const dl = await cloud.downloadFile({ fileID });
      buffer = dl.fileContent;
    }

    // 雲函數端縮圖已停用（請在小程式端選 compressed 圖或先縮小）
    const ds = await maybeDownscale(buffer);
    buffer = ds.buffer;

    // 呼叫騰訊雲 GeneralAccurateOCR（用 base64）
    const imageBase64 = buffer.toString("base64");
    const tencentResp = await callTencentGeneralAccurateOCR({
      secretId,
      secretKey,
      region,
      imageBase64,
    });
    let ocrItems = toOcrItemsFromTencent(tencentResp);
    let tencentRespSecondary = null;
    let ocrItemsSecondary = [];
    let bandSecondaryDebug = null;
    // 若首次 OCR 偵測偏少，追加一輪高對比二次 OCR（全圖）提升小字召回
    const firstDetections = Number(tencentResp?.TextDetections?.length || 0);
    const needSecondaryGlobalOcr = event?.globalSecondaryOcr !== false && firstDetections < Number(event?.globalSecondaryOcrThreshold || 850);
    if (needSecondaryGlobalOcr) {
      try {
        const dec = decodeToRgba(buffer);
        const enhanced = enhanceRgbaForText(dec.data, dec.width, dec.height);
        const enhancedB64 = rgbaToPngBase64(enhanced, dec.width, dec.height);
        tencentRespSecondary = await callTencentGeneralAccurateOCR({
          secretId,
          secretKey,
          region,
          imageBase64: enhancedB64,
        });
        ocrItemsSecondary = toOcrItemsFromTencent(tencentRespSecondary);
        ocrItems = mergeOcrItems(ocrItems, ocrItemsSecondary);
      } catch (e) {
        console.warn("globalSecondaryOcr 失敗，將略過", e?.code || e?.message || e);
      }
    }
    // 再做「弱帶分塊二次 OCR」：優先補下半部缺框區域，避免整圖重跑成本過高
    if (event?.bandSecondaryOcr !== false) {
      try {
        const decBand = decodeToRgba(buffer);
        const bandRes = await runBandSecondaryOcr({
          rgba: decBand.data,
          width: decBand.width,
          height: decBand.height,
          ocrItems,
          secretId,
          secretKey,
          region,
          bandCount: Number(event?.bandSecondaryBandCount || 8),
          maxBands: Number(event?.bandSecondaryMaxBands || 3),
          tileCols: Number(event?.bandSecondaryTileCols || 2),
        });
        bandSecondaryDebug = bandRes?.debug || null;
        if (Array.isArray(bandRes?.items) && bandRes.items.length) {
          ocrItems = mergeOcrItems(ocrItems, bandRes.items);
        }
      } catch (e) {
        console.warn("bandSecondaryOcr 失敗，將略過", e?.code || e?.message || e);
      }
    }
    // 由前端（wx.getImageInfo）提供的 orientation 只用於「對齊顯示座標系」；不直接信任其寬高
    const clientOrientation = normalizeOrientation(event?.imageMeta?.orientation);

    // 轉成 booths：{id, bbox, center}
    // 規則：
    // - 若 OCR 已讀到 A01 / B103：直接採用
    // - 若字母與數字分開：用 bbox 就近配對成 A01
    // - 若找不到字母：只輸出數字（最多 3 位）
    const letterItems = [];
    const numItems = [];
    const directBooths = [];

    for (const it of ocrItems) {
      const bbox = it.bbox;
      if (!bbox) continue;

      const direct = boothIdFromText(it.text);
      if (direct) {
        // 直接命中（包含純數字或字母+數字）
        directBooths.push({
          id: direct,
          bbox,
          score: it.score ?? null,
        });
        continue;
      }

      const letter = asLetterToken(it.text, bbox);
      if (letter) {
        letterItems.push({ letter, bbox, score: it.score ?? null });
        continue;
      }
      const digits = isDigitsOnlyToken(it.text);
      if (digits) {
        numItems.push({ digits, bbox, score: it.score ?? null });
        continue;
      }

      const merged = splitMergedDigitsToken(it.text);
      if (merged) {
        // 把黏在一起的數字拆成多個 numItem，並把 bbox 水平切開以回貼原位
        const bbs = splitBboxHorizontally(bbox, merged.length);
        for (let i = 0; i < merged.length; i++) {
          numItems.push({ digits: merged[i], bbox: bbs[i], score: it.score ?? null, mergedFrom: it.text });
        }
      }
    }

    const rowLetterAnchors = buildRowLetterAnchors({ letterItems, numItems });

    // 將純數字 booth 嘗試加上列字母
    const booths = [];
    const seen = new Set();

    // 先放入已有字母+數字的 directBooths（避免後面重覆）
    for (const b of directBooths) {
      const guardedDirect = applyPrefixGuardByRowAnchors(b.id, b.bbox, rowLetterAnchors);
      const guardedId = guardedDirect.id || b.id;
      const key = `${guardedId}:${Math.round(b.bbox.x1)}:${Math.round(b.bbox.y1)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      booths.push({
        id: guardedId,
        bbox: b.bbox,
        center: bboxCenter(b.bbox),
        score: b.score,
      });
    }

    for (const n of numItems) {
      let id = n.digits;
      const letterFromRows = pickLetterByRowAnchors(n, rowLetterAnchors);
      // 一旦有 row anchors，就不要回退到舊的就近字母配對（避免被上方 W/N 等列吸走）
      const letter = letterFromRows || (rowLetterAnchors.length ? null : findBestLetterForNumber(n, letterItems));
      if (letter) id = `${letter}${n.digits}`;

      const key = `${id}:${Math.round(n.bbox.x1)}:${Math.round(n.bbox.y1)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      booths.push({
        id,
        bbox: n.bbox,
        center: bboxCenter(n.bbox),
        score: n.score ?? null,
      });
    }

    // 依可信度/位置排序（MVP）
    booths.sort((a, b) => (b.score ?? 0) - (a.score ?? 0));

    // 走道/障礙物 occupancy grid（通用版）：純影像抽取 + flood fill
    let grid = null;
    let decodedMeta = null;
    let coordSpace = { name: "CIS", rotation: "up", ocrAssumedSpace: "decoded", version: Number(event?.coordSpaceVersion || 2) };
    let boothRegions = null;
    let secondaryOcrDebug = null;
    let ocrRangeFinal = computeOcrRange(ocrItems);
    try {
      // 盡量使用原圖 buffer（不重編碼），並回傳 imageMeta 供前端對齊
      const decodedRaw = decodeToRgba(buffer);
      const rawW = decodedRaw.width;
      const rawH = decodedRaw.height;

      // 若前端回報有旋轉（多半來自 JPEG EXIF），判斷 OCR 座標是落在哪個座標系，再把影像/座標統一到「顯示（upright）」座標系
      const rot = clientOrientation;
      let range = computeOcrRange(ocrItems);
      const oriSize = orientedSize(rawW, rawH, rot);
      const scoreRaw = overflowScore(range, rawW, rawH);
      const scoreOri = overflowScore(range, oriSize.width, oriSize.height);
      const ocrAlreadyOriented = rot !== "up" && scoreOri + 0.5 < scoreRaw; // 0.5: 抗浮點雜訊

      let decoded = decodedRaw;
      if (rot !== "up") decoded = rotateRgba(decodedRaw, rot);
      decodedMeta = { width: decoded.width, height: decoded.height, rotation: rot };
      coordSpace = {
        name: "CIS",
        width: decoded.width,
        height: decoded.height,
        rotation: rot,
        ocrAssumedSpace: ocrAlreadyOriented ? "oriented" : "decoded",
        version: Number(event?.coordSpaceVersion || 2),
      };

      if (rot !== "up" && !ocrAlreadyOriented) {
        // OCR 座標看起來仍是「未旋轉」空間：把 OCR/booth 轉到 oriented（與顯示一致）
        ocrItems = transformOcrItems(ocrItems, rawW, rawH, rot);
        booths.splice(0, booths.length, ...transformBooths(booths, rawW, rawH, rot));
        // 重要：座標轉換後要重算 OCR 主要分布範圍，否則 ROI 會使用舊座標系
        range = computeOcrRange(ocrItems);
      }

      const imgW = decoded.width;
      const imgH = decoded.height;
      const cellSizePx = Number(event?.gridCellPx || gridCellPx || 16);
      // 以影像結構估計「攤位格子」的可點選區域（取代 OCR 文字框近似）
      boothRegions = buildBoothRegions({
        rgba: decoded.data,
        width: imgW,
        height: imgH,
        booths,
        gridCellPx: cellSizePx,
        ocrRange: range,
        ocrItems,
      });

      if (event?.secondaryOcr !== false && boothRegions?.length) {
        const sec = await enrichBoothCellsBySecondaryOcr({
          boothCells: boothRegions,
          rgba: decoded.data,
          width: imgW,
          height: imgH,
          secretId,
          secretKey,
          region,
          maxRows: Number(event?.secondaryOcrMaxRows || 4),
        });
        boothRegions = sec?.boothCells || boothRegions;
        secondaryOcrDebug = sec?.debug || null;
      }
      ocrRangeFinal = computeOcrRange(ocrItems);

      // 用 boothRegions（若有）來標障礙，讓 A* 不穿越攤位格；沒有就退回 OCR booths
      grid = buildWalkableGridFromImage({
        rgba: decoded.data,
        width: imgW,
        height: imgH,
        cellSizePx,
        booths: boothRegions?.length ? boothRegions : booths,
      });
    } catch (e) {
      console.warn("buildWalkableGridFromImage 失敗，將退回 booth-only grid", e?.code || e?.message || e);
    }

    const cellStats = boothRegions?.length
      ? {
          total: boothRegions.length,
          labeled: boothRegions.filter((c) => !!(c?.labelId || c?.id)).length,
          unlabeled: boothRegions.filter((c) => !(c?.labelId || c?.id)).length,
          avgCellScore:
            boothRegions.reduce((acc, c) => acc + Number(c?.cellScore || 0), 0) / Math.max(1, boothRegions.length),
          avgLabelConfidence:
            boothRegions.reduce((acc, c) => acc + Number(c?.labelConfidence || 0), 0) / Math.max(1, boothRegions.length),
        }
      : null;
    const boothIndexPayload = buildBoothIndex({
      boothCells: boothRegions || [],
      booths,
      rowLetterAnchors,
    });

    return {
      ok: true,
      data: {
        fileID,
        booths,
        boothIndex: boothIndexPayload.boothIndex,
        boothIndexStats: boothIndexPayload.stats,
        rowNumberMap: boothIndexPayload.rowNumberMap,
        boothCells: boothRegions || null,
        // 相容舊前端命名（後續可移除）
        boothRegions: boothRegions || null,
        imageMeta: decodedMeta || null,
        ocrItems,
        coordSpace,
        cellStats,
        gridCellPx: grid?.cellSizePx || gridCellPx,
        grid,
        requestId: tencentResp?.RequestId || null,
        debug: event?.debug
          ? {
              clientOrientation,
              coordSpace,
              ocrRange: ocrRangeFinal,
              cellStats,
              ocrDiagnostics: {
                textDetectionsPass1: Number(tencentResp?.TextDetections?.length || 0),
                textDetectionsPass2: Number(tencentRespSecondary?.TextDetections?.length || 0),
                ocrItemsPass1: Number(toOcrItemsFromTencent(tencentResp)?.length || 0),
                ocrItemsPass2: Number(ocrItemsSecondary?.length || 0),
                ocrItemsMerged: Number(ocrItems?.length || 0),
                needSecondaryGlobalOcr,
                bandSecondaryOcr: bandSecondaryDebug,
                samplePass1: (tencentResp?.TextDetections || []).slice(0, 10).map((x) => x?.DetectedText || ""),
                samplePass2: (tencentRespSecondary?.TextDetections || []).slice(0, 10).map((x) => x?.DetectedText || ""),
              },
              rowLetterAnchors: (() => {
                const arr = buildRowLetterAnchors({
                  letterItems: letterItems || [],
                  numItems: numItems || [],
                });
                return arr.map((b) => ({
                  cy: b.cy,
                  spacing: b.spacing,
                  count: b.items?.length || 0,
                  letters: (b.items || []).map((x) => x.letter),
                }));
              })(),
              secondaryOcr: secondaryOcrDebug,
            }
          : undefined,
        imageTransform: ds.transformed
          ? { transformed: true, originalBytes: ds.originalBytes, resizedBytes: ds.resizedBytes }
          : { transformed: false },
        imported: imported ? { bytes: imported.bytes, contentType: imported.contentType } : null,
      },
    };
  } catch (e) {
    console.error(e);
    // SDK 錯誤通常含 code/requestId，回傳給前端方便對照錯誤碼與工單查詢
    return {
      ok: false,
      error:
        e?.code === "IMAGE_TOO_LARGE_FOR_CLOUDFN"
          ? "圖片過大：建議在小程式端先用壓縮圖/縮小尺寸再上傳（雲函數 256MB 不適合處理超大圖）"
          : e?.message || "未知錯誤",
      code: e?.code || e?.Code || null,
      requestId: e?.requestId || e?.RequestId || null,
    };
  }
};



