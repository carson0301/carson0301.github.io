## 微信小程式：平面圖數位化 + 室內導航（Grid Map + A*）

本專案提供可落地的端到端流程：

- 小程式端：上傳平面圖 -> 雲端解析 -> 輸入/掃碼設定起終點 -> 在原圖疊加路徑
- 雲端：呼叫騰訊雲 OCR + 影像格線/格子後處理，輸出 booth 索引與可走網格

### 目前定位策略（2026-02）

- 已停用地圖點擊設點（避免密集小格誤觸）
- 起點/終點僅保留：
  - 手動輸入展位號
  - 掃 QR 取得展位號
- 以 `boothIndex` 作為查詢主索引，不再只依賴 OCR bbox
- `boothIndex` 支援：
  - `confirmed`（直接 OCR/貼標）
  - `inferred`（規則推斷）
  - `unresolved`（僅有格子，待補標）
- 針對 `I/1` 混淆提供 alias 與查詢優先序（先 exact，再 alias）
- 含字母前綴輸入（如 `R34`）採 **prefix 鎖定**：僅允許同 prefix 命中（避免跨列 alias 吸附）
- 查詢 debug 會顯示匹配路徑：`exact / alias / inferred / fallback`

### 近期修正（2026-02 最新）

- 雲端 `parseFloorplan`：
  - 新增 row-anchor prefix guard，避免 `R34 -> W34` 類型錯列寫入索引
  - 新增全圖二次 OCR 與弱帶分塊補掃（band secondary OCR + tile），提升下半部小字召回
  - `boothIndex` 建立時加入 prefix guard 防線，降低跨列誤配
- 前端 `map` 查找：
  - 新增 prefix 鎖定查找與匹配路徑 debug（current/dest）
  - 強化 runtime infer（row/col 估計、弱列補救、候選去重）
  - 新增 low-trust exact 重定位（exact 命中但幾何可疑時改走推斷重選）
- OCR overlay：
  - `drawOcrItems` 改為垂直分帶均衡渲染，避免上半部吃掉 `maxItems` 造成下半部「看起來無框」

### 雲端解析輸出重點

- `ocrItems`：OCR 文字框/分數
- `booths`：OCR 直接抽取之攤位候選
- `boothCells`：格線枚舉後的格子（含 `row/col/cellScore/labelId`）
- `boothIndex`：可查詢索引（`idCanonical/aliases/status/confidence/cellId`）
- `grid`：occupancy bitset（A* 走道約束）
- `coordSpace`：統一座標空間 metadata（CIS）

### 目錄結構

- `miniprogram/`：微信小程式前端
- `cloudfunctions/`：雲函數（Node.js）
- `docs/`：開發對話與決策紀錄

### 啟動步驟（概要）

1. 用微信開發者工具打開專案根目錄
2. 啟用雲開發並選擇環境
3. 設定 `miniprogram/app.js` 內 cloud env（或沿用工具當前環境）
4. 設定雲函數環境變數（雲函數控制台）：
   - `SecretId`（或相容舊鍵 `TENCENT_SECRET_ID`）
   - `SecretKey`（或相容舊鍵 `TENCENT_SECRET_KEY`）
   - `TENCENT_OCR_REGION`（可選，預設 `ap-guangzhou`）
5. 部署雲函數：
   - `cloudfunctions/parseFloorplan` 上傳並部署（所有檔案）

### 已知限制

- 在列字母與號碼分離且 OCR 缺框嚴重的圖（特別是最底部 40-44、1-5 區段）仍可能出現錯列或同行錯位
- `W` 列等弱錨點列在無足夠 cell 幾何時，`inferred` 仍可能不穩，需持續以 row model/人工校正入口修正
- 極端情況下 `ocr_booth` 幾何可能污染 exact 定位；目前已降低影響但仍建議保留人工校正流程



