const AbstractModel = require("../../common/abstract_model");

/**
 * ModifySiteAttribute请求参数结构体
 * @class
 */
class ModifySiteAttributeRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点ID
         * @type {number || null}
         */
        this.SiteId = null;

        /**
         * 站点名称
         * @type {string || null}
         */
        this.Name = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SiteId = params.SiteId || null;
        this.Name = params.Name || null;

    }
}

/**
 * 监控任务详细数据
 * @class
 */
class MonitorsDetail extends  AbstractModel {
    constructor(){
        super();

        /**
         * 监控任务基础信息。
         * @type {Monitor || null}
         */
        this.Basic = null;

        /**
         * 监控任务包含的站点列表。
         * @type {Array.<MonitorMiniSite> || null}
         */
        this.Sites = null;

        /**
         * 监控任务包含的站点列表数量。
         * @type {number || null}
         */
        this.SiteNumber = null;

        /**
         * 监控任务包含的受漏洞威胁的站点列表。
         * @type {Array.<MonitorMiniSite> || null}
         */
        this.ImpactSites = null;

        /**
         * 监控任务包含的受漏洞威胁的站点列表数量。
         * @type {number || null}
         */
        this.ImpactSiteNumber = null;

        /**
         * 高风险漏洞数量。
         * @type {number || null}
         */
        this.VulsHighNumber = null;

        /**
         * 中风险漏洞数量。
         * @type {number || null}
         */
        this.VulsMiddleNumber = null;

        /**
         * 低风险漏洞数量。
         * @type {number || null}
         */
        this.VulsLowNumber = null;

        /**
         * 提示数量。
         * @type {number || null}
         */
        this.VulsNoticeNumber = null;

        /**
         * 监控任务包含的站点列表的平均扫描进度。
         * @type {number || null}
         */
        this.Progress = null;

        /**
         * 扫描页面总数。
         * @type {number || null}
         */
        this.PageCount = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }

        if (params.Basic) {
            let obj = new Monitor();
            obj.deserialize(params.Basic)
            this.Basic = obj;
        }

        if (params.Sites) {
            this.Sites = new Array();
            for (let z in params.Sites) {
                let obj = new MonitorMiniSite();
                obj.deserialize(params.Sites[z]);
                this.Sites.push(obj);
            }
        }
        this.SiteNumber = params.SiteNumber || null;

        if (params.ImpactSites) {
            this.ImpactSites = new Array();
            for (let z in params.ImpactSites) {
                let obj = new MonitorMiniSite();
                obj.deserialize(params.ImpactSites[z]);
                this.ImpactSites.push(obj);
            }
        }
        this.ImpactSiteNumber = params.ImpactSiteNumber || null;
        this.VulsHighNumber = params.VulsHighNumber || null;
        this.VulsMiddleNumber = params.VulsMiddleNumber || null;
        this.VulsLowNumber = params.VulsLowNumber || null;
        this.VulsNoticeNumber = params.VulsNoticeNumber || null;
        this.Progress = params.Progress || null;
        this.PageCount = params.PageCount || null;

    }
}

/**
 * DescribeSites返回参数结构体
 * @class
 */
class DescribeSitesResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点数量。
         * @type {number || null}
         */
        this.TotalCount = null;

        /**
         * 站点信息列表。
         * @type {Array.<Site> || null}
         */
        this.Sites = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.TotalCount = params.TotalCount || null;

        if (params.Sites) {
            this.Sites = new Array();
            for (let z in params.Sites) {
                let obj = new Site();
                obj.deserialize(params.Sites[z]);
                this.Sites.push(obj);
            }
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * DescribeMonitors返回参数结构体
 * @class
 */
class DescribeMonitorsResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 监控任务列表。
         * @type {Array.<MonitorsDetail> || null}
         */
        this.Monitors = null;

        /**
         * 监控任务数量。
         * @type {number || null}
         */
        this.TotalCount = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }

        if (params.Monitors) {
            this.Monitors = new Array();
            for (let z in params.Monitors) {
                let obj = new MonitorsDetail();
                obj.deserialize(params.Monitors[z]);
                this.Monitors.push(obj);
            }
        }
        this.TotalCount = params.TotalCount || null;
        this.RequestId = params.RequestId || null;

    }
}

/**
 * DeleteSites请求参数结构体
 * @class
 */
class DeleteSitesRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点ID列表
         * @type {Array.<number> || null}
         */
        this.SiteIds = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SiteIds = params.SiteIds || null;

    }
}

/**
 * DescribeConfig请求参数结构体
 * @class
 */
class DescribeConfigRequest extends  AbstractModel {
    constructor(){
        super();

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }

    }
}

/**
 * ModifyConfigAttribute返回参数结构体
 * @class
 */
class ModifyConfigAttributeResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * CreateSites返回参数结构体
 * @class
 */
class CreateSitesResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 新增站点数。
         * @type {number || null}
         */
        this.Number = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Number = params.Number || null;
        this.RequestId = params.RequestId || null;

    }
}

/**
 * ModifyMonitorAttribute返回参数结构体
 * @class
 */
class ModifyMonitorAttributeResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * CreateMonitors返回参数结构体
 * @class
 */
class CreateMonitorsResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * CreateSitesScans返回参数结构体
 * @class
 */
class CreateSitesScansResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * 站点验证数据
 * @class
 */
class SitesVerification extends  AbstractModel {
    constructor(){
        super();

        /**
         * 根域名。
         * @type {string || null}
         */
        this.Domain = null;

        /**
         * txt解析域名验证的name。
         * @type {string || null}
         */
        this.TxtName = null;

        /**
         * txt解析域名验证的text。
         * @type {string || null}
         */
        this.TxtText = null;

        /**
         * 验证有效期，在此之前有效。
         * @type {string || null}
         */
        this.ValidTo = null;

        /**
         * 验证状态：0-未验证；1-已验证；2-验证失效，待重新验证。
         * @type {number || null}
         */
        this.VerifyStatus = null;

        /**
         * CreatedAt。
         * @type {string || null}
         */
        this.CreatedAt = null;

        /**
         * UpdatedAt。
         * @type {string || null}
         */
        this.UpdatedAt = null;

        /**
         * ID。
         * @type {number || null}
         */
        this.Id = null;

        /**
         * 云用户appid
         * @type {number || null}
         */
        this.Appid = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Domain = params.Domain || null;
        this.TxtName = params.TxtName || null;
        this.TxtText = params.TxtText || null;
        this.ValidTo = params.ValidTo || null;
        this.VerifyStatus = params.VerifyStatus || null;
        this.CreatedAt = params.CreatedAt || null;
        this.UpdatedAt = params.UpdatedAt || null;
        this.Id = params.Id || null;
        this.Appid = params.Appid || null;

    }
}

/**
 * DescribeSiteQuota返回参数结构体
 * @class
 */
class DescribeSiteQuotaResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 已购买的站点数。
         * @type {number || null}
         */
        this.Total = null;

        /**
         * 已使用的站点数。
         * @type {number || null}
         */
        this.Used = null;

        /**
         * 剩余可用的站点数。
         * @type {number || null}
         */
        this.Available = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Total = params.Total || null;
        this.Used = params.Used || null;
        this.Available = params.Available || null;
        this.RequestId = params.RequestId || null;

    }
}

/**
 * CreateVulsMisinformation请求参数结构体
 * @class
 */
class CreateVulsMisinformationRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 漏洞ID列表
         * @type {Array.<number> || null}
         */
        this.VulIds = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.VulIds = params.VulIds || null;

    }
}

/**
 * DescribeVuls请求参数结构体
 * @class
 */
class DescribeVulsRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点ID
         * @type {number || null}
         */
        this.SiteId = null;

        /**
         * 监控任务ID
         * @type {number || null}
         */
        this.MonitorId = null;

        /**
         * 过滤条件
         * @type {Array.<Filter> || null}
         */
        this.Filters = null;

        /**
         * 偏移量，默认为0
         * @type {number || null}
         */
        this.Offset = null;

        /**
         * 返回数量，默认为10，最大值为100
         * @type {number || null}
         */
        this.Limit = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SiteId = params.SiteId || null;
        this.MonitorId = params.MonitorId || null;

        if (params.Filters) {
            this.Filters = new Array();
            for (let z in params.Filters) {
                let obj = new Filter();
                obj.deserialize(params.Filters[z]);
                this.Filters.push(obj);
            }
        }
        this.Offset = params.Offset || null;
        this.Limit = params.Limit || null;

    }
}

/**
 * 监控任务中的站点信息。
 * @class
 */
class MonitorMiniSite extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点ID。
         * @type {number || null}
         */
        this.SiteId = null;

        /**
         * 站点Url。
         * @type {string || null}
         */
        this.Url = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SiteId = params.SiteId || null;
        this.Url = params.Url || null;

    }
}

/**
 * CreateSitesScans请求参数结构体
 * @class
 */
class CreateSitesScansRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点的ID列表
         * @type {Array.<number> || null}
         */
        this.SiteIds = null;

        /**
         * 扫描模式，normal-正常扫描；deep-深度扫描
         * @type {string || null}
         */
        this.ScannerType = null;

        /**
         * 扫描速率限制，每秒发送X个HTTP请求
         * @type {number || null}
         */
        this.RateLimit = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SiteIds = params.SiteIds || null;
        this.ScannerType = params.ScannerType || null;
        this.RateLimit = params.RateLimit || null;

    }
}

/**
 * DescribeVuls返回参数结构体
 * @class
 */
class DescribeVulsResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 漏洞数量。
         * @type {number || null}
         */
        this.TotalCount = null;

        /**
         * 漏洞信息列表。
         * @type {Array.<Vul> || null}
         */
        this.Vuls = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.TotalCount = params.TotalCount || null;

        if (params.Vuls) {
            this.Vuls = new Array();
            for (let z in params.Vuls) {
                let obj = new Vul();
                obj.deserialize(params.Vuls[z]);
                this.Vuls.push(obj);
            }
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * VerifySites返回参数结构体
 * @class
 */
class VerifySitesResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 验证成功的根域名数量。
         * @type {number || null}
         */
        this.SuccessNumber = null;

        /**
         * 验证失败的根域名数量。
         * @type {number || null}
         */
        this.FailNumber = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SuccessNumber = params.SuccessNumber || null;
        this.FailNumber = params.FailNumber || null;
        this.RequestId = params.RequestId || null;

    }
}

/**
 * CreateMonitors请求参数结构体
 * @class
 */
class CreateMonitorsRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点的url列表
         * @type {Array.<string> || null}
         */
        this.Urls = null;

        /**
         * 任务名称
         * @type {string || null}
         */
        this.Name = null;

        /**
         * 扫描模式，normal-正常扫描；deep-深度扫描
         * @type {string || null}
         */
        this.ScannerType = null;

        /**
         * 扫描周期，单位小时，每X小时执行一次
         * @type {number || null}
         */
        this.Crontab = null;

        /**
         * 扫描速率限制，每秒发送X个HTTP请求
         * @type {number || null}
         */
        this.RateLimit = null;

        /**
         * 首次扫描开始时间
         * @type {string || null}
         */
        this.FirstScanStartTime = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Urls = params.Urls || null;
        this.Name = params.Name || null;
        this.ScannerType = params.ScannerType || null;
        this.Crontab = params.Crontab || null;
        this.RateLimit = params.RateLimit || null;
        this.FirstScanStartTime = params.FirstScanStartTime || null;

    }
}

/**
 * DeleteMonitors返回参数结构体
 * @class
 */
class DeleteMonitorsResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * 监控任务基础数据
 * @class
 */
class Monitor extends  AbstractModel {
    constructor(){
        super();

        /**
         * 监控任务ID。
         * @type {number || null}
         */
        this.Id = null;

        /**
         * 监控名称。
         * @type {string || null}
         */
        this.Name = null;

        /**
         * 监测状态：1-监测中；2-暂停监测。
         * @type {number || null}
         */
        this.MonitorStatus = null;

        /**
         * 监测模式，normal-正常扫描；deep-深度扫描。
         * @type {string || null}
         */
        this.ScannerType = null;

        /**
         * 扫描周期，单位小时，每X小时执行一次。
         * @type {number || null}
         */
        this.Crontab = null;

        /**
         * 指定扫描类型，3位数每位依次表示：扫描Web漏洞、扫描系统漏洞、扫描系统端口。
         * @type {string || null}
         */
        this.IncludedVulsTypes = null;

        /**
         * 速率限制，每秒发送X个HTTP请求。
         * @type {number || null}
         */
        this.RateLimit = null;

        /**
         * 首次扫描开始时间。
         * @type {string || null}
         */
        this.FirstScanStartTime = null;

        /**
         * 扫描状态：0-待扫描（无任何扫描结果）；1-扫描中（正在进行扫描）；2-已扫描（有扫描结果且不正在扫描）；3-扫描完成待同步结果。
         * @type {number || null}
         */
        this.ScanStatus = null;

        /**
         * 上一次扫描完成时间。
         * @type {string || null}
         */
        this.LastScanFinishTime = null;

        /**
         * 当前扫描开始时间，如扫描完成则为上一次扫描的开始时间。
         * @type {string || null}
         */
        this.CurrentScanStartTime = null;

        /**
         * CreatedAt。
         * @type {string || null}
         */
        this.CreatedAt = null;

        /**
         * UpdatedAt。
         * @type {string || null}
         */
        this.UpdatedAt = null;

        /**
         * 云用户appid。
         * @type {number || null}
         */
        this.Appid = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Id = params.Id || null;
        this.Name = params.Name || null;
        this.MonitorStatus = params.MonitorStatus || null;
        this.ScannerType = params.ScannerType || null;
        this.Crontab = params.Crontab || null;
        this.IncludedVulsTypes = params.IncludedVulsTypes || null;
        this.RateLimit = params.RateLimit || null;
        this.FirstScanStartTime = params.FirstScanStartTime || null;
        this.ScanStatus = params.ScanStatus || null;
        this.LastScanFinishTime = params.LastScanFinishTime || null;
        this.CurrentScanStartTime = params.CurrentScanStartTime || null;
        this.CreatedAt = params.CreatedAt || null;
        this.UpdatedAt = params.UpdatedAt || null;
        this.Appid = params.Appid || null;

    }
}

/**
 * CreateVulsMisinformation返回参数结构体
 * @class
 */
class CreateVulsMisinformationResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * VerifySites请求参数结构体
 * @class
 */
class VerifySitesRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点的url列表
         * @type {Array.<string> || null}
         */
        this.Urls = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Urls = params.Urls || null;

    }
}

/**
 * ModifyMonitorAttribute请求参数结构体
 * @class
 */
class ModifyMonitorAttributeRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 监测任务ID
         * @type {number || null}
         */
        this.MonitorId = null;

        /**
         * 站点的url列表
         * @type {Array.<string> || null}
         */
        this.Urls = null;

        /**
         * 任务名称
         * @type {string || null}
         */
        this.Name = null;

        /**
         * 扫描模式，normal-正常扫描；deep-深度扫描
         * @type {string || null}
         */
        this.ScannerType = null;

        /**
         * 扫描周期，单位小时，每X小时执行一次
         * @type {number || null}
         */
        this.Crontab = null;

        /**
         * 扫描速率限制，每秒发送X个HTTP请求
         * @type {number || null}
         */
        this.RateLimit = null;

        /**
         * 首次扫描开始时间
         * @type {string || null}
         */
        this.FirstScanStartTime = null;

        /**
         * 监测状态：1-监测中；2-暂停监测
         * @type {number || null}
         */
        this.MonitorStatus = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.MonitorId = params.MonitorId || null;
        this.Urls = params.Urls || null;
        this.Name = params.Name || null;
        this.ScannerType = params.ScannerType || null;
        this.Crontab = params.Crontab || null;
        this.RateLimit = params.RateLimit || null;
        this.FirstScanStartTime = params.FirstScanStartTime || null;
        this.MonitorStatus = params.MonitorStatus || null;

    }
}

/**
 * 漏洞数据
 * @class
 */
class Vul extends  AbstractModel {
    constructor(){
        super();

        /**
         * 漏洞ID。
         * @type {number || null}
         */
        this.Id = null;

        /**
         * 站点ID。
         * @type {number || null}
         */
        this.SiteId = null;

        /**
         * 扫描引擎的扫描任务ID。
         * @type {number || null}
         */
        this.TaskId = null;

        /**
         * 漏洞级别：high、middle、low、notice。
         * @type {string || null}
         */
        this.Level = null;

        /**
         * 漏洞名称。
         * @type {string || null}
         */
        this.Name = null;

        /**
         * 出现漏洞的url。
         * @type {string || null}
         */
        this.Url = null;

        /**
         * 网址/细节。
         * @type {string || null}
         */
        this.Html = null;

        /**
         * 漏洞类型。
         * @type {string || null}
         */
        this.Nickname = null;

        /**
         * 危害说明。
         * @type {string || null}
         */
        this.Harm = null;

        /**
         * 漏洞描述。
         * @type {string || null}
         */
        this.Describe = null;

        /**
         * 解决方案。
         * @type {string || null}
         */
        this.Solution = null;

        /**
         * 漏洞参考。
         * @type {string || null}
         */
        this.From = null;

        /**
         * 漏洞通过该参数攻击。
         * @type {string || null}
         */
        this.Parameter = null;

        /**
         * CreatedAt。
         * @type {string || null}
         */
        this.CreatedAt = null;

        /**
         * UpdatedAt。
         * @type {string || null}
         */
        this.UpdatedAt = null;

        /**
         * 是否已经添加误报，0-否，1-是。
         * @type {number || null}
         */
        this.IsReported = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Id = params.Id || null;
        this.SiteId = params.SiteId || null;
        this.TaskId = params.TaskId || null;
        this.Level = params.Level || null;
        this.Name = params.Name || null;
        this.Url = params.Url || null;
        this.Html = params.Html || null;
        this.Nickname = params.Nickname || null;
        this.Harm = params.Harm || null;
        this.Describe = params.Describe || null;
        this.Solution = params.Solution || null;
        this.From = params.From || null;
        this.Parameter = params.Parameter || null;
        this.CreatedAt = params.CreatedAt || null;
        this.UpdatedAt = params.UpdatedAt || null;
        this.IsReported = params.IsReported || null;

    }
}

/**
 * ModifySiteAttribute返回参数结构体
 * @class
 */
class ModifySiteAttributeResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * CreateSites请求参数结构体
 * @class
 */
class CreateSitesRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点的url列表
         * @type {Array.<string> || null}
         */
        this.Urls = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Urls = params.Urls || null;

    }
}

/**
 * ModifyConfigAttribute请求参数结构体
 * @class
 */
class ModifyConfigAttributeRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 漏洞告警通知等级，4位分别代表：高危、中危、低危、提示
         * @type {string || null}
         */
        this.NoticeLevel = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.NoticeLevel = params.NoticeLevel || null;

    }
}

/**
 * 描述键值对过滤器，用于条件过滤查询。例如过滤ID、名称、状态等

若存在多个Filter时，Filter间的关系为逻辑与（AND）关系。
若同一个Filter存在多个Values，同一Filter下Values间的关系为逻辑或（OR）关系。
 * @class
 */
class Filter extends  AbstractModel {
    constructor(){
        super();

        /**
         * 过滤键的名称。
         * @type {string || null}
         */
        this.Name = null;

        /**
         * 一个或者多个过滤值。
         * @type {Array.<string> || null}
         */
        this.Values = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Name = params.Name || null;
        this.Values = params.Values || null;

    }
}

/**
 * DescribeMonitors请求参数结构体
 * @class
 */
class DescribeMonitorsRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 监控任务ID列表
         * @type {Array.<number> || null}
         */
        this.MonitorIds = null;

        /**
         * 过滤条件
         * @type {Array.<Filter> || null}
         */
        this.Filters = null;

        /**
         * 偏移量，默认为0
         * @type {number || null}
         */
        this.Offset = null;

        /**
         * 返回数量，默认为10，最大值为100
         * @type {number || null}
         */
        this.Limit = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.MonitorIds = params.MonitorIds || null;

        if (params.Filters) {
            this.Filters = new Array();
            for (let z in params.Filters) {
                let obj = new Filter();
                obj.deserialize(params.Filters[z]);
                this.Filters.push(obj);
            }
        }
        this.Offset = params.Offset || null;
        this.Limit = params.Limit || null;

    }
}

/**
 * DeleteSites返回参数结构体
 * @class
 */
class DeleteSitesResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * DeleteMonitors请求参数结构体
 * @class
 */
class DeleteMonitorsRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 监控任务ID列表
         * @type {Array.<number> || null}
         */
        this.MonitorIds = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.MonitorIds = params.MonitorIds || null;

    }
}

/**
 * DescribeSitesVerification返回参数结构体
 * @class
 */
class DescribeSitesVerificationResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 验证信息数量。
         * @type {number || null}
         */
        this.TotalCount = null;

        /**
         * 验证信息列表。
         * @type {SitesVerification || null}
         */
        this.SitesVerification = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.TotalCount = params.TotalCount || null;

        if (params.SitesVerification) {
            let obj = new SitesVerification();
            obj.deserialize(params.SitesVerification)
            this.SitesVerification = obj;
        }
        this.RequestId = params.RequestId || null;

    }
}

/**
 * 站点数据
 * @class
 */
class Site extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点ID。
         * @type {number || null}
         */
        this.Id = null;

        /**
         * 监控任务ID，为0时表示未加入监控任务。
         * @type {number || null}
         */
        this.MonitorId = null;

        /**
         * 站点url。
         * @type {string || null}
         */
        this.Url = null;

        /**
         * 站点名称。
         * @type {string || null}
         */
        this.Name = null;

        /**
         * 验证状态：0-未验证；1-已验证；2-验证失效，待重新验证。
         * @type {number || null}
         */
        this.VerifyStatus = null;

        /**
         * 监测状态：0-未监测；1-监测中；2-暂停监测。
         * @type {number || null}
         */
        this.MonitorStatus = null;

        /**
         * 扫描状态：0-待扫描（无任何扫描结果）；1-扫描中（正在进行扫描）；2-已扫描（有扫描结果且不正在扫描）；3-扫描完成待同步结果。
         * @type {number || null}
         */
        this.ScanStatus = null;

        /**
         * 最近一次的AIScanner的扫描任务id，注意取消的情况。
         * @type {number || null}
         */
        this.LastScanTaskId = null;

        /**
         * 最近一次扫描开始时间。
         * @type {string || null}
         */
        this.LastScanStartTime = null;

        /**
         * 最近一次扫描完成时间。
         * @type {string || null}
         */
        this.LastScanFinishTime = null;

        /**
         * 最近一次取消时间，取消即使用上一次扫描结果。
         * @type {string || null}
         */
        this.LastScanCancelTime = null;

        /**
         * 最近一次扫描扫描的页面数。
         * @type {number || null}
         */
        this.LastScanPageCount = null;

        /**
         * normal-正常扫描；deep-深度扫描。
         * @type {string || null}
         */
        this.LastScanScannerType = null;

        /**
         * 最近一次扫描高风险漏洞数量。
         * @type {number || null}
         */
        this.LastScanVulsHighNum = null;

        /**
         * 最近一次扫描中风险漏洞数量。
         * @type {number || null}
         */
        this.LastScanVulsMiddleNum = null;

        /**
         * 最近一次扫描低风险漏洞数量。
         * @type {number || null}
         */
        this.LastScanVulsLowNum = null;

        /**
         * 最近一次扫描提示信息数量。
         * @type {number || null}
         */
        this.LastScanVulsNoticeNum = null;

        /**
         * 记录添加时间。
         * @type {string || null}
         */
        this.CreatedAt = null;

        /**
         * 记录最近修改时间。
         * @type {string || null}
         */
        this.UpdatedAt = null;

        /**
         * 速率限制，每秒发送X个HTTP请求。
         * @type {number || null}
         */
        this.LastScanRateLimit = null;

        /**
         * 最近一次扫描漏洞总数量。
         * @type {number || null}
         */
        this.LastScanVulsNum = null;

        /**
         * 最近一次扫描提示总数量
         * @type {number || null}
         */
        this.LastScanNoticeNum = null;

        /**
         * 扫描进度，百分比整数
         * @type {number || null}
         */
        this.Progress = null;

        /**
         * 最近一次扫描各个类型风险漏洞数量，存储的是json对象
         * @type {string || null}
         */
        this.LastScanExtsCount = null;

        /**
         * 云用户appid。
         * @type {number || null}
         */
        this.Appid = null;

        /**
         * 云用户标识。
         * @type {string || null}
         */
        this.Uin = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Id = params.Id || null;
        this.MonitorId = params.MonitorId || null;
        this.Url = params.Url || null;
        this.Name = params.Name || null;
        this.VerifyStatus = params.VerifyStatus || null;
        this.MonitorStatus = params.MonitorStatus || null;
        this.ScanStatus = params.ScanStatus || null;
        this.LastScanTaskId = params.LastScanTaskId || null;
        this.LastScanStartTime = params.LastScanStartTime || null;
        this.LastScanFinishTime = params.LastScanFinishTime || null;
        this.LastScanCancelTime = params.LastScanCancelTime || null;
        this.LastScanPageCount = params.LastScanPageCount || null;
        this.LastScanScannerType = params.LastScanScannerType || null;
        this.LastScanVulsHighNum = params.LastScanVulsHighNum || null;
        this.LastScanVulsMiddleNum = params.LastScanVulsMiddleNum || null;
        this.LastScanVulsLowNum = params.LastScanVulsLowNum || null;
        this.LastScanVulsNoticeNum = params.LastScanVulsNoticeNum || null;
        this.CreatedAt = params.CreatedAt || null;
        this.UpdatedAt = params.UpdatedAt || null;
        this.LastScanRateLimit = params.LastScanRateLimit || null;
        this.LastScanVulsNum = params.LastScanVulsNum || null;
        this.LastScanNoticeNum = params.LastScanNoticeNum || null;
        this.Progress = params.Progress || null;
        this.LastScanExtsCount = params.LastScanExtsCount || null;
        this.Appid = params.Appid || null;
        this.Uin = params.Uin || null;

    }
}

/**
 * DescribeConfig返回参数结构体
 * @class
 */
class DescribeConfigResponse extends  AbstractModel {
    constructor(){
        super();

        /**
         * 漏洞告警通知等级，4位分别代表：高危、中危、低危、提示。
         * @type {string || null}
         */
        this.NoticeLevel = null;

        /**
         * 配置ID。
         * @type {number || null}
         */
        this.Id = null;

        /**
         * 记录创建时间。
         * @type {string || null}
         */
        this.CreatedAt = null;

        /**
         * 记录更新新建。
         * @type {string || null}
         */
        this.UpdatedAt = null;

        /**
         * 唯一请求ID，每次请求都会返回。定位问题时需要提供该次请求的RequestId。
         * @type {string || null}
         */
        this.RequestId = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.NoticeLevel = params.NoticeLevel || null;
        this.Id = params.Id || null;
        this.CreatedAt = params.CreatedAt || null;
        this.UpdatedAt = params.UpdatedAt || null;
        this.RequestId = params.RequestId || null;

    }
}

/**
 * DescribeSites请求参数结构体
 * @class
 */
class DescribeSitesRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点ID列表
         * @type {Array.<number> || null}
         */
        this.SiteIds = null;

        /**
         * 过滤条件
         * @type {Array.<Filter> || null}
         */
        this.Filters = null;

        /**
         * 偏移量，默认为0
         * @type {number || null}
         */
        this.Offset = null;

        /**
         * 返回数量，默认为10，最大值为100
         * @type {number || null}
         */
        this.Limit = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.SiteIds = params.SiteIds || null;

        if (params.Filters) {
            this.Filters = new Array();
            for (let z in params.Filters) {
                let obj = new Filter();
                obj.deserialize(params.Filters[z]);
                this.Filters.push(obj);
            }
        }
        this.Offset = params.Offset || null;
        this.Limit = params.Limit || null;

    }
}

/**
 * DescribeSiteQuota请求参数结构体
 * @class
 */
class DescribeSiteQuotaRequest extends  AbstractModel {
    constructor(){
        super();

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }

    }
}

/**
 * DescribeSitesVerification请求参数结构体
 * @class
 */
class DescribeSitesVerificationRequest extends  AbstractModel {
    constructor(){
        super();

        /**
         * 站点的url列表
         * @type {Array.<string> || null}
         */
        this.Urls = null;

    }

    /**
     * @private
     */
    deserialize(params) {
        if (!params) {
            return;
        }
        this.Urls = params.Urls || null;

    }
}

module.exports = {
    ModifySiteAttributeRequest: ModifySiteAttributeRequest,
    MonitorsDetail: MonitorsDetail,
    DescribeSitesResponse: DescribeSitesResponse,
    DescribeMonitorsResponse: DescribeMonitorsResponse,
    DeleteSitesRequest: DeleteSitesRequest,
    DescribeConfigRequest: DescribeConfigRequest,
    ModifyConfigAttributeResponse: ModifyConfigAttributeResponse,
    CreateSitesResponse: CreateSitesResponse,
    ModifyMonitorAttributeResponse: ModifyMonitorAttributeResponse,
    CreateMonitorsResponse: CreateMonitorsResponse,
    CreateSitesScansResponse: CreateSitesScansResponse,
    SitesVerification: SitesVerification,
    DescribeSiteQuotaResponse: DescribeSiteQuotaResponse,
    CreateVulsMisinformationRequest: CreateVulsMisinformationRequest,
    DescribeVulsRequest: DescribeVulsRequest,
    MonitorMiniSite: MonitorMiniSite,
    CreateSitesScansRequest: CreateSitesScansRequest,
    DescribeVulsResponse: DescribeVulsResponse,
    VerifySitesResponse: VerifySitesResponse,
    CreateMonitorsRequest: CreateMonitorsRequest,
    DeleteMonitorsResponse: DeleteMonitorsResponse,
    Monitor: Monitor,
    CreateVulsMisinformationResponse: CreateVulsMisinformationResponse,
    VerifySitesRequest: VerifySitesRequest,
    ModifyMonitorAttributeRequest: ModifyMonitorAttributeRequest,
    Vul: Vul,
    ModifySiteAttributeResponse: ModifySiteAttributeResponse,
    CreateSitesRequest: CreateSitesRequest,
    ModifyConfigAttributeRequest: ModifyConfigAttributeRequest,
    Filter: Filter,
    DescribeMonitorsRequest: DescribeMonitorsRequest,
    DeleteSitesResponse: DeleteSitesResponse,
    DeleteMonitorsRequest: DeleteMonitorsRequest,
    DescribeSitesVerificationResponse: DescribeSitesVerificationResponse,
    Site: Site,
    DescribeConfigResponse: DescribeConfigResponse,
    DescribeSitesRequest: DescribeSitesRequest,
    DescribeSiteQuotaRequest: DescribeSiteQuotaRequest,
    DescribeSitesVerificationRequest: DescribeSitesVerificationRequest,

}
