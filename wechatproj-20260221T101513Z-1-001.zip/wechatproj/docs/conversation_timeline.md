## 對話整理（按時間順序分段）

> 說明：本檔為「迄今為止」的開發對話摘要，按時間先後分段整理。已刻意避免收錄任何帳號金鑰等敏感資訊。

---

### 0) 需求提出（平面圖數位化 + 室內導航）
- **目標**：上傳平面圖（JPG/PNG）→ 自動辨識攤位位置與編號 → 生成與原圖佈局一致的 Grid Map → 最短路徑規劃（A* / Dijkstra）→ 在原圖上疊加路徑（可縮放/平移）。
- **技術棧**：
  - 前端：微信小程式（WXML/WXSS/JS）
  - 後端：微信雲開發（CloudBase）
  - OCR：後續改為騰訊雲 `GeneralAccurateOCR`
- **限制**：後端僅能使用 Node.js 雲函數。

---

### 1) 專案骨架建立（從空資料夾開始）
- 新增 `project.config.json`、`miniprogram/app.*`、`miniprogram/pages/*`、`cloudfunctions/*` 的基本結構。
- 前端兩頁：
  - `pages/index`：上傳 → 呼叫雲函數解析 → 顯示攤位清單 → 進入地圖
  - `pages/map`：選起終點 → A* 規劃 → canvas 疊加顯示路徑

---

### 2) OCR 方案討論：雲函數是否能跑 OCR？
- 結論：Node.js 雲函數不適合直接跑大型 OCR 引擎（依賴重/冷啟動/資源限制）。
- 決策：改用 **騰訊雲 OCR API**（GeneralAccurateOCR）由雲函數呼叫，雲函數負責整合與後處理。

參考文檔：
- [通用文字識別（高精度版）GeneralAccurateOCR](https://cloud.tencent.com/document/product/866/34937#.E8.85.BE.E8.AE.AF.E4.BA.91-API-.E5.B9.B3.E5.8F.B0)

---

### 3) OCR 改為騰訊雲 GeneralAccurateOCR（並支援 OCR 回貼原位）
- 雲函數 `parseFloorplan`：
  - 下載雲儲存圖片 → 呼叫 GeneralAccurateOCR → 解析 `TextDetections` → 輸出 `ocrItems`（含 bbox/polygon/score）
  - 從 OCR 結果抽取攤位號（MVP 規則）→ 輸出 `booths`
- 小程式端：
  - 新增 OCR 疊加顯示開關（在原圖上畫 OCR 框/文字）
  - 影像座標映射處理 `aspectFit` 偏移與縮放

---

### 4) 改用 `tencentcloud-sdk-nodejs`（取代手寫 TC3 簽名）
- 將雲函數改為用 `tencentcloud-sdk-nodejs` 呼叫 API。
- 討論重點：SDK 必須作為雲函數資料夾內的依賴（`cloudfunctions/parseFloorplan/package.json`），不能只放在專案母資料夾。

---

### 5) 清理不再使用內容
- 移除所有不再使用的字眼與範例（例如先前的 OCR 引擎相關資料夾/文案）。
- 刪除不需要的檔案與部署產物（例如雲函數 `node_modules` 等）。

---

### 6) 雲函數部署/調用常見錯誤排查
- **FUNCTION_NOT_FOUND (-501000)**：小程式連到的雲環境中找不到同名雲函數（常見原因：環境選錯/函數未部署/建立成 http 函數）。
- **ResourceNotFound.Function**：部署時更新不到，表示雲端同名 Function 不存在（需先建立普通函數再部署）。
- **code exit unexpected (145)**：雲函數進程崩潰（常見原因：原生依賴不相容）；因此移除 `sharp`，改用「端上壓縮/原圖上傳」策略。

---

### 7) 雲函數資源調整後的畫質策略
- 需求：避免任何壓縮導致 OCR 準確度降低。
- 調整：小程式端 `chooseMedia` 強制 `sizeType: ["original"]`，避免上傳壓縮圖。

---

### 8) UI 重寫：底邊導航欄 + 狀態保存
- 新增 `components/bottom-nav`，以底部導航欄重寫頁面佈局。
- 新增 `utils/state.js`：將 `fileID/booths/ocrItems/grid/imageMeta` 存入 storage，避免切頁丟狀態。
- `app.js` 調整：`wx.cloud.init()` 不綁死 envId（使用開發者工具當前選擇的雲環境）。

---

### 9) 定位/互動：輸入攤位號或掃描 QR 更新「目前位置」
- 地圖頁新增：
  - 目前位置（起點）：輸入/掃 QR
  - 目的地（終點）：輸入/掃 QR（並保留 picker）
  - 起點/終點標記即時重繪

---

### 10) 地圖縮放/平移疊加層穩定性修正
- 症狀：縮放後 OCR 框/路徑漂移、縮放鍵跟著地圖跑、縮小失效。
- 調整：
  - canvas 疊加層移到 `movable-view` 外並固定覆蓋
  - 用 `bindchange/bindscale` 同步平移/縮放 transform 到 canvas context
  - zoom 控制改固定在 `movable-area` 角落（不隨地圖縮放移動）
  - 修正縮放回彈（加短暫 programmatic scale lock）
  - `movable-area` 設定 `position: relative`，避免 absolute overlay 定位基準錯誤

---

### 11) 點擊選起點/終點（Tap 模式）
- 新增點選模式（起點/終點），在地圖上點擊可設定並立即顯示位置。
- 後續因誤判集中在列字母區（N/L/K...），改為「正向映射」命中：先把 booth bbox 映射到螢幕座標後再做命中/最近距離判斷。

---

### 12) 攤位號抽取規則強化
- 需求：輸出格式為「列字母+編號」（列字母可選），編號最多 3 位；且處理「兩個攤位號黏在一起」的誤辨（例如 4~6 位純數字）。
- 實作：
  - 若直接命中 `A01`/`B103`/`101`：直接採用
  - 若字母與數字分開：就近配對
  - 若數字黏連（4~6 位）：切開並把 bbox 水平分段
  - `I` 被辨成 `1`：以 bbox 形狀做保守修正（細長才視為 I）

---

### 13) 「路徑只能走走道」與「更通用」的方向
- 現況問題：僅靠 OCR 文字框無法可靠區分走道/攤位/牆；導致路徑仍可能穿攤位。
- 決策：走向更通用的 occupancy grid。
- 先行實作（純 Node.js，無原生依賴）：
  - 雲函數用 `pngjs`/`jpeg-js` 解碼 → 亮度/接近白候選 → closing → 從邊界 flood fill 取外部走道 → booth bbox 加 margin 當障礙
  - 回傳 bitset（base64）→ 小程式解碼成 grid.cells → A* 僅走走道
- 後續建議：若要更通用（不同風格/深色走道/複雜線框），需要進一步加入：
  - **線段偵測 + 向量化 + 區域填充**（可控、可解釋）
  - 或 **語意分割**（模型輸出 walkable/obstacle mask）

---

### 14) 使用者回報的未解決/待持續優化項目（最近）
- **點擊選點仍易誤判列字母區**（輸入攤位號正確，但點擊不穩）
- **路徑仍可能穿攤位**
- **OCR 框仍可能偏移**（需以「雲端解碼尺寸 + 顯示映射一致」為主線繼續校正與 debug）

---

### 15) 座標系收斂 + boothCells 主導（近期完成）
- 完成座標系統 debug 與統一輸出：
  - 雲端回傳 `coordSpace`（CIS）與 `cellStats`
  - 前端避免用 `bindload` 尺寸覆寫雲端座標空間
- 點擊命中改為 cell 主導（正向映射），並可高亮無 label 的格子。
- 雲端修正關鍵 bug：旋轉後會重算 `ocrRange`，避免 ROI 使用舊座標。

---

### 16) 攤位索引升級：`boothIndex`（近期完成）
- 雲端新增 `boothIndex`，整合 `boothCells + booths`：
  - `idCanonical`
  - `aliases`
  - `status = confirmed | inferred | unresolved`
  - `confidence / evidence / cellId`
- 新增 `boothIndexStats` 供前端 debug（confirmed/inferred/unresolved 計數）。
- 查詢策略改為「先 exact，再 alias」，降低 `I/1` 混淆帶來的誤配。

---

### 17) 互動策略調整：停用地圖點擊設點（近期完成）
- 使用者確認密集小格圖上點擊誤觸高，故改為：
  - 僅保留「手動輸入起終點」與「掃碼設定起終點」
- 地圖頁已停用 `tap` 設點流程，避免誤選造成錯誤導航。

---

### 18) 缺框補救：runtime 內插與跨列回退（近期完成）
- 當輸入展位查無 `confirmed` 時：
  - 先嘗試同列內插
  - 同列錨點不足時，回退用鄰列（A-K）同號/近號估算欄位
  - 在 `unresolved` cells 中選最接近候選，動態產生 `inferred`
- 已加入 A-K 錨點覆蓋 debug：
  - `anchorAK A:x ... K:y`
  - `anchorWeak ...`（<2 錨點列）

---

### 19) 最新驗證狀態（本輪）
- 整體定位已大致準確。
- `M33` 已可推斷且位置接近。
- `H24` 仍有個別偏移，已追加「同列 + 鄰列同號融合」與跨大段號碼防呆。
- `I` 行輸入不再被 UI 強制顯示成 `1` 開頭（保留原輸入 canonical）。

---

### 20) 列字母+數字分離圖（FF46）專項修復（本輪）
- 問題聚焦：
  - `R34` 曾被錯配為 `W34`
  - `W20`、`R42` 在缺框時查無結果
  - `A`/`W` 等弱列發生「同列錯位或集中到同一點」
- 已完成改動（雲端）：
  - `parseFloorplan` 新增 row-anchor prefix guard（direct OCR 與 `buildBoothIndex` 兩層）
  - 新增全圖高對比二次 OCR + 弱帶分塊補掃（band secondary OCR，支援 tile）
  - debug 新增 `bandSecondaryOcr` 指標（added/selected/bands）
- 已完成改動（前端）：
  - 查找層 prefix 鎖定：有前綴輸入時禁止跨 prefix alias 命中
  - 新增 lookup debug（`exact/alias/inferred/fallback` + `idCanonical/prefix/reason`）
  - runtime infer 強化：
    - 鄰列同號估計 + 全域號碼趨勢
    - parse row-anchor 映射 cell row
    - low-trust exact 自動重定位
    - 已占用 cell 排除，避免多查詢吸附同一 unresolved cell
  - `_normalizeBoothIndex` 改為「幾何品質優先」而非純 confidence，降低 `ocr_booth` 污染 canonical 幾何
- 當前狀態（使用者最新驗證）：
  - `R34` 已可正確定位
  - 但 `A` 行仍有集中錯位、`W` 行仍有同行錯位
  - 底部區段（40-44、1-5）仍有錯列或查無
- 下一步建議：
  - 在雲端 `boothIndex` 端加入硬規則：弱列且無 cell 幾何的 `ocr_booth` 不可作 exact 幾何來源
  - 增加「prefix row-band -> cell row」的雲端映射輸出，前端僅做消費不再猜測
  - 補人工校正入口（最少可先支援 row/col 偏移校正表）



